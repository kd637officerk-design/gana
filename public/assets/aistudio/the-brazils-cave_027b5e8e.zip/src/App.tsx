import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowUpDown, ChevronLeft, ChevronRight, Hand, Search, X } from 'lucide-react';
import {
  AppState,
  Book,
  PdfEntry,
  RoomTab,
  SheetOption,
  ThemeConfig,
} from './types';
import {
  APP_ICON_COVER,
  defaultTheme,
  FONT_MAP,
  HYPER_BACKGROUNDS,
  LOGOS,
  VOCAB,
} from './data/themes';
import {
  createInitialState,
  createSampleAudiobook,
  hashStr,
  idbDel,
  idbGet,
  idbPut,
  makeWallpaperThumb,
  persistState,
  wlGetAllMeta,
  wlTx,
} from './utils/storage';
import { WeatherCanvas } from './components/WeatherCanvas';
import { PlayerDock } from './components/PlayerDock';
import { NowPlayingStage } from './components/NowPlayingStage';
import { AudiobooksView } from './components/AudiobooksView';
import { PdfView } from './components/PdfView';
import { OpenLinksView } from './components/OpenLinksView';
import {
  SharpSettingsWheelModal,
  SharpWheelButton,
} from './components/SharpSettingsWheel';
import { ActionSheet, InputModal, ToastBanner } from './components/ToastAndSheet';

const ROOMS: { id: RoomTab; label: string }[] = [
  { id: 'lib', label: 'Audiobooks' },
  { id: 'pdf', label: 'PDF' },
  { id: 'links', label: 'Open Links' },
];

export default function App() {
  const [state, setState] = useState<AppState>(() => createInitialState());
  const stateRef = useRef(state);
  stateRef.current = state;

  const [roomIndex, setRoomIndex] = useState(0);
  const [dragOffset, setDragOffset] = useState(0);
  const [genreFilter, setGenreFilter] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [listFilter, setListFilter] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'title' | 'progress'>('recent');
  const [isReadingPdf, setIsReadingPdf] = useState(false);
  const [fullPlayerOpen, setFullPlayerOpen] = useState(false);
  const [wheelOpen, setWheelOpen] = useState(false);
  const [wheelSection, setWheelSection] = useState<'themes' | 'wallpapers' | 'weather' | 'archive'>('themes');

  // Audio playback state
  const audioRef = useRef<HTMLAudioElement>(null);
  const [curTrack, setCurTrack] = useState<{ id: string; i: number } | null>(null);
  const curTrackRef = useRef(curTrack);
  curTrackRef.current = curTrack;
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const readyRef = useRef(false);
  const audioUrlRef = useRef<string | null>(null);
  const sessionRef = useRef<{ id: string; i: number; from: number; start: number } | null>(null);
  const lastSaveRef = useRef(0);
  const sleepTimerRef = useRef<number | null>(null);

  // Wallpaper state
  const [wallUrl, setWallUrl] = useState<string | null>(null);
  const [wallIsVideo, setWallIsVideo] = useState(false);
  const [wallName, setWallName] = useState<string | undefined>(undefined);
  const wallUrlRef = useRef<string | null>(null);

  // Ambient sound refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const brownBufRef = useRef<AudioBuffer | null>(null);
  const rainSynthRef = useRef<{ src: AudioBufferSourceNode; gain: GainNode } | null>(null);
  const rainAudioRef = useRef<HTMLAudioElement | null>(null);
  const rainUrlRef = useRef<string | null>(null);
  const thunderUrlRef = useRef<string | null>(null);
  const [rainLoaded, setRainLoaded] = useState(false);
  const [thunderLoaded, setThunderLoaded] = useState(false);

  // UI Overlays (Sheet, Prompt, Toast)
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const [sheetData, setSheetData] = useState<{
    open: boolean;
    title: string;
    options: SheetOption[];
  }>({ open: false, title: '', options: [] });
  const [inputModal, setInputModal] = useState<{
    open: boolean;
    title: string;
    placeholder?: string;
    initialValue?: string;
    onConfirm: (val: string) => void;
  }>({ open: false, title: '', onConfirm: () => {} });

  // Gesture tracking refs
  const swipeGestureRef = useRef<{
    x0: number;
    y0: number;
    locked: 'h' | 'v' | null;
    startTime: number;
  } | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToastMsg(null), 3000);
  }, []);

  const commitState = useCallback((updater: (prev: AppState) => AppState, force = false) => {
    setState((prev) => {
      const next = updater(prev);
      persistState(next, force);
      return next;
    });
  }, []);

  // Apply CSS custom properties whenever theme changes
  useEffect(() => {
    const T = state.theme;
    const r = document.documentElement.style;
    r.setProperty('--bg', T.bg);
    r.setProperty('--am', T.am);
    r.setProperty('--fg', T.fg);
    r.setProperty('--ff', FONT_MAP[T.ft] || FONT_MAP.serif);
    r.setProperty('--dim', String(T.dim));
    r.setProperty('--blur', `${T.blur}px`);
    r.setProperty('--sheen', String(T.sheen ?? 0.75));
    r.setProperty('--depth3d', String(T.depth3d ?? 0.75));
    document.title = T.nm || 'THE BRAZILS CAVE';
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', T.bg);
  }, [state.theme]);

  // Apply audio volume & mute
  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    el.volume = state.muted ? 0 : Math.max(0, Math.min(1, state.vol ?? 0.85));
    el.muted = !!state.muted;
  }, [state.vol, state.muted]);

  // Load wallpaper blob from IndexedDB
  const refreshWallpaper = useCallback(async () => {
    try {
      const blob = await idbGet<Blob>('f', 'wall');
      if (wallUrlRef.current) {
        URL.revokeObjectURL(wallUrlRef.current);
        wallUrlRef.current = null;
      }
      if (!blob) {
        setWallUrl(null);
        setWallIsVideo(false);
        setWallName(undefined);
        return;
      }
      const u = URL.createObjectURL(blob);
      wallUrlRef.current = u;
      setWallUrl(u);
      setWallIsVideo((blob.type || '').startsWith('video'));
      setWallName((blob as File).name || 'Active Wallpaper');
    } catch {
      // ignore
    }
  }, []);

  // Ambient Rain & Thunder loader + Web Audio soft rain fallback
  const ensureAudioContext = useCallback(() => {
    if (!audioCtxRef.current) {
      try {
        const AC =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AC();
        audioCtxRef.current = ctx;
        const buf = ctx.createBuffer(1, ctx.sampleRate * 4, ctx.sampleRate);
        const data = buf.getChannelData(0);
        let last = 0;
        for (let i = 0; i < data.length; i++) {
          last = (last + 0.025 * (Math.random() * 2 - 1)) / 1.025;
          data[i] = last * 3.2;
        }
        brownBufRef.current = buf;
      } catch {
        return null;
      }
    }
    return audioCtxRef.current;
  }, []);

  const syncAmbiencePlayback = useCallback(
    (theme: ThemeConfig, readingActive = false) => {
      const readingRain = readingActive && theme.rainOnRead !== false;
      const shouldPlay = !!(
        theme.snd &&
        (theme.vol ?? 0) > 0.005 &&
        (theme.fx === 'rain' || theme.fx === 'storm' || theme.fx === 'snow' || readingRain)
      );
      const targetVol = Math.max(0, Math.min(1, (theme.vol ?? 0.5) * 0.9));
      const rEl = rainAudioRef.current;

      if (rEl) {
        if (rainSynthRef.current) {
          try {
            rainSynthRef.current.src.stop();
          } catch {
            // ignore
          }
          rainSynthRef.current = null;
        }
        rEl.volume = targetVol;
        if (shouldPlay) {
          rEl.play().catch(() => {});
        } else {
          rEl.pause();
        }
        return;
      }

      // Synthesized gentle ambient rain/wind loop fallback when no custom recording is loaded
      if (!shouldPlay) {
        if (rainSynthRef.current && audioCtxRef.current) {
          rainSynthRef.current.gain.gain.setTargetAtTime(0, audioCtxRef.current.currentTime, 0.08);
        }
        return;
      }
      const ctx = ensureAudioContext();
      const buf = brownBufRef.current;
      if (!ctx || !buf) return;
      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
      if (!rainSynthRef.current) {
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.loop = true;
        const hp = ctx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 280;
        const lp = ctx.createBiquadFilter();
        lp.type = 'lowpass';
        lp.frequency.value = theme.fx === 'snow' ? 750 : 2200;
        const gain = ctx.createGain();
        gain.gain.value = 0;
        src.connect(hp);
        hp.connect(lp);
        lp.connect(gain);
        gain.connect(ctx.destination);
        src.start();
        rainSynthRef.current = { src, gain };
      }
      rainSynthRef.current.gain.gain.setTargetAtTime(
        targetVol * (theme.fx === 'storm' ? 0.38 : 0.28),
        ctx.currentTime,
        0.08
      );
    },
    [ensureAudioContext]
  );

  const loadAmbienceFiles = useCallback(async () => {
    const rb = await idbGet<Blob>('f', 'ambience:rain').catch(() => undefined);
    const tb = await idbGet<Blob>('f', 'ambience:thunder').catch(() => undefined);
    if (rainUrlRef.current) URL.revokeObjectURL(rainUrlRef.current);
    if (thunderUrlRef.current) URL.revokeObjectURL(thunderUrlRef.current);
    rainUrlRef.current = rb ? URL.createObjectURL(rb) : null;
    thunderUrlRef.current = tb ? URL.createObjectURL(tb) : null;
    setRainLoaded(!!rb);
    setThunderLoaded(!!tb);

    if (rainAudioRef.current) {
      rainAudioRef.current.pause();
      rainAudioRef.current.src = '';
      rainAudioRef.current = null;
    }
    if (rainUrlRef.current) {
      const a = new Audio(rainUrlRef.current);
      a.loop = true;
      a.preload = 'auto';
      rainAudioRef.current = a;
    }
    syncAmbiencePlayback(stateRef.current.theme);
  }, [syncAmbiencePlayback]);

  useEffect(() => {
    syncAmbiencePlayback(state.theme, isReadingPdf);
  }, [state.theme.snd, state.theme.fx, state.theme.vol, state.theme.rainOnRead, isReadingPdf, syncAmbiencePlayback]);

  const playThunder = useCallback(() => {
    const T = stateRef.current.theme;
    if (!T.snd || T.fx !== 'storm') return;
    if (thunderUrlRef.current) {
      const a = new Audio(thunderUrlRef.current);
      a.volume = Math.max(0, Math.min(1, (T.vol ?? 0.5) * 0.95));
      a.play().catch(() => {});
      return;
    }
    if (!audioCtxRef.current) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AC();
        audioCtxRef.current = ctx;
        const buf = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate);
        const data = buf.getChannelData(0);
        let last = 0;
        for (let i = 0; i < data.length; i++) {
          last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02;
          data[i] = last * 3.5;
        }
        brownBufRef.current = buf;
      } catch {
        return;
      }
    }
    const ctx = audioCtxRef.current;
    const buf = brownBufRef.current;
    if (!ctx || !buf || ctx.state !== 'running') return;
    window.setTimeout(() => {
      const src = ctx.createBufferSource();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      const now = ctx.currentTime;
      src.buffer = buf;
      filter.type = 'lowpass';
      filter.frequency.value = 185;
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime((T.vol ?? 0.5) * 1.15, now + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 3.6);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      src.start();
      src.stop(now + 3.7);
    }, 250 + Math.random() * 1100);
  }, []);

  // Unlock AudioContext on first user pointer interaction
  useEffect(() => {
    const unlock = () => {
      if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume().catch(() => {});
      }
      if (stateRef.current.theme.snd) {
        syncAmbiencePlayback(stateRef.current.theme);
      }
    };
    window.addEventListener('pointerdown', unlock, { passive: true });
    return () => window.removeEventListener('pointerdown', unlock);
  }, [syncAmbiencePlayback]);

  // End listening session & log history
  const endSession = useCallback(() => {
    const sess = sessionRef.current;
    const cur = curTrackRef.current;
    const el = audioRef.current;
    if (sess && cur && sess.id === cur.id && sess.i === cur.i && readyRef.current && el) {
      const to = el.currentTime;
      if (to - sess.from >= 3) {
        commitState((prev) => {
          const book = prev.books[cur.id];
          if (!book) return prev;
          const hist = [...prev.hist];
          const last = hist[hist.length - 1];
          if (
            last &&
            last.id === sess.id &&
            last.i === sess.i &&
            Math.abs(last.to - sess.from) < 2 &&
            sess.start - last.ts < 1800000
          ) {
            hist[hist.length - 1] = { ...last, to };
          } else {
            hist.push({
              id: sess.id,
              title: book.title,
              ts: sess.start,
              i: sess.i,
              n: book.tracks.length,
              from: sess.from,
              to,
            });
          }
          return { ...prev, hist };
        }, true);
      }
    }
    sessionRef.current = null;
  }, [commitState]);

  const savePosition = useCallback(
    (force = false) => {
      const cur = curTrackRef.current;
      const el = audioRef.current;
      if (!cur || !readyRef.current || !el) return;
      const t = el.currentTime;
      commitState((prev) => {
        const b = prev.books[cur.id];
        if (!b) return prev;
        return {
          ...prev,
          last: cur.id,
          books: {
            ...prev.books,
            [cur.id]: { ...b, pos: { i: cur.i, t }, u: Date.now() },
          },
        };
      }, force);
    },
    [commitState]
  );

  const loadTrack = useCallback(
    async (id: string, trackIdx: number, seekSec: number, autoPlay: boolean) => {
      const book = stateRef.current.books[id];
      if (!book) return;
      endSession();
      readyRef.current = false;
      setCurTrack({ id, i: trackIdx });

      const blob = await idbGet<Blob>('f', `${id}:${trackIdx}`);
      const el = audioRef.current;
      if (!el) return;

      if (!blob) {
        el.removeAttribute('src');
        setIsPlaying(false);
        showToast(`Audio file missing — re-add to resume at ${Math.floor(seekSec)}s`);
        return;
      }

      if (audioUrlRef.current) URL.revokeObjectURL(audioUrlRef.current);
      const u = URL.createObjectURL(blob);
      audioUrlRef.current = u;
      el.src = u;
      el.playbackRate = stateRef.current.rate || 1;
      el.volume = stateRef.current.muted ? 0 : stateRef.current.vol ?? 0.85;
      el.muted = !!stateRef.current.muted;

      const onLoaded = () => {
        const dur = Number.isFinite(el.duration) ? el.duration : 0;
        const clamped = Math.max(0, Math.min(seekSec, Math.max(0, dur - 0.1)));
        el.currentTime = clamped;
        setDuration(dur);
        setCurrentTime(clamped);
        readyRef.current = true;
        commitState((prev) => {
          const b = prev.books[id];
          if (!b) return prev;
          const tracks = b.tracks.map((tr, idx) =>
            idx === trackIdx ? { ...tr, d: dur } : tr
          );
          return {
            ...prev,
            last: id,
            books: {
              ...prev.books,
              [id]: { ...b, gone: false, tracks, pos: { i: trackIdx, t: clamped }, u: Date.now() },
            },
          };
        }, true);
        if (autoPlay) {
          el.play().catch(() => {});
        }
      };

      el.addEventListener('loadedmetadata', onLoaded, { once: true });
    },
    [commitState, endSession, showToast]
  );

  const handleTogglePlay = useCallback(() => {
    const el = audioRef.current;
    if (!el || !el.src) return;
    if (el.paused) el.play().catch(() => {});
    else el.pause();
  }, []);

  const handlePrev = useCallback(() => {
    const el = audioRef.current;
    const cur = curTrackRef.current;
    if (!el || !cur) return;
    if (el.currentTime > 5 || cur.i === 0) {
      el.currentTime = 0;
      setCurrentTime(0);
    } else {
      loadTrack(cur.id, cur.i - 1, 0, true);
    }
  }, [loadTrack]);

  const handleNext = useCallback(() => {
    const cur = curTrackRef.current;
    if (!cur) return;
    const book = stateRef.current.books[cur.id];
    if (book && cur.i + 1 < book.tracks.length) {
      loadTrack(cur.id, cur.i + 1, 0, true);
    }
  }, [loadTrack]);

  // Media Session integration
  useEffect(() => {
    if (!('mediaSession' in navigator) || !curTrack) return;
    const book = state.books[curTrack.id];
    if (!book) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: book.title,
        artist: state.theme.nm,
      });
      navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
      navigator.mediaSession.setActionHandler('play', () => audioRef.current?.play().catch(() => {}));
      navigator.mediaSession.setActionHandler('pause', () => audioRef.current?.pause());
      navigator.mediaSession.setActionHandler('previoustrack', handlePrev);
      navigator.mediaSession.setActionHandler('nexttrack', handleNext);
      navigator.mediaSession.setActionHandler('seekto', (d) => {
        if (audioRef.current && Number.isFinite(d.seekTime)) {
          audioRef.current.currentTime = d.seekTime!;
        }
      });
    } catch {
      // ignore unsupported mediaSession actions
    }
  }, [curTrack, isPlaying, state.books, state.theme.nm, handlePrev, handleNext]);

  // Boot: restore mirror from IDB + restore last book + wallpaper
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const mirrored = await idbGet<AppState>('m', 'S');
        if (mounted && mirrored && (mirrored.u || 0) > (stateRef.current.u || 0)) {
          const merged: AppState = {
            ...stateRef.current,
            ...mirrored,
            theme: { ...defaultTheme(), ...(mirrored.theme || {}) },
          };
          if (merged.theme.nm === 'THE BRAZILS CAVE') {
            merged.theme.nm = 'BILLS CAVE';
          }
          setState(merged);
          persistState(merged, true);
        }
      } catch {
        // ignore
      }

      if (stateRef.current.wshuf) {
        const metas = await wlGetAllMeta();
        if (metas.length) {
          const pick = metas[Math.floor(Math.random() * metas.length)];
          const blob = await wlTx<Blob | undefined>('w', 'readonly', (t) =>
            t.objectStore('w').get(pick.id)
          ).catch(() => undefined);
          if (blob) {
            await idbPut('f', 'wall', blob);
            commitState((prev) => ({ ...prev, wcur: pick.id }), true);
          }
        }
      }
      if (mounted) {
        await refreshWallpaper();
        await loadAmbienceFiles();
        const lastId = stateRef.current.last;
        if (lastId && stateRef.current.books[lastId] && !stateRef.current.books[lastId].gone) {
          const b = stateRef.current.books[lastId];
          loadTrack(lastId, b.pos.i, b.pos.t, false);
        }
      }
    })();

    const onHide = () => {
      savePosition(true);
      endSession();
    };
    window.addEventListener('pagehide', onHide);
    return () => {
      mounted = false;
      window.removeEventListener('pagehide', onHide);
    };
  }, []);

  // Keyboard shortcuts for desktop room switching & wheel
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.key === 'ArrowRight') setRoomIndex((i) => Math.min(ROOMS.length - 1, i + 1));
      if (e.key === 'ArrowLeft') setRoomIndex((i) => Math.max(0, i - 1));
      if (e.key === ' ') {
        e.preventDefault();
        handleTogglePlay();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleTogglePlay]);

  // Finger Gesture Handlers on Main Stage (Swipe Left/Right between Audiobooks, PDF, Open Links + 2-finger tap for Settings Wheel)
  const handleStageTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      swipeGestureRef.current = null;
      setWheelOpen(true);
      return;
    }
    if (e.touches.length !== 1) return;
    const target = e.target as HTMLElement;
    if (target.closest('input, select, textarea, .no-scrollbar')) return;
    swipeGestureRef.current = {
      x0: e.touches[0].clientX,
      y0: e.touches[0].clientY,
      locked: null,
      startTime: performance.now(),
    };
  };

  const handleStageTouchMove = (e: React.TouchEvent) => {
    const g = swipeGestureRef.current;
    if (!g || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - g.x0;
    const dy = e.touches[0].clientY - g.y0;
    if (!g.locked) {
      if (Math.abs(dx) > 14 && Math.abs(dx) > Math.abs(dy) * 1.25) {
        g.locked = 'h';
      } else if (Math.abs(dy) > 14) {
        g.locked = 'v';
      }
    }
    if (g.locked === 'h') {
      // Elastic resistance at outer edges
      const atStartEdge = roomIndex === 0 && dx > 0;
      const atEndEdge = roomIndex === ROOMS.length - 1 && dx < 0;
      setDragOffset(atStartEdge || atEndEdge ? dx * 0.28 : dx);
    }
  };

  const handleStageTouchEnd = (e: React.TouchEvent) => {
    const g = swipeGestureRef.current;
    swipeGestureRef.current = null;
    if (!g || g.locked !== 'h') {
      setDragOffset(0);
      return;
    }
    const dx = e.changedTouches[0].clientX - g.x0;
    const dt = Math.max(1, performance.now() - g.startTime);
    const velocity = Math.abs(dx) / dt;
    if (dx < -55 || (dx < -25 && velocity > 0.45)) {
      setRoomIndex((i) => Math.min(ROOMS.length - 1, i + 1));
    } else if (dx > 55 || (dx > 25 && velocity > 0.45)) {
      setRoomIndex((i) => Math.max(0, i - 1));
    }
    setDragOffset(0);
  };

  // Wallpaper handlers
  const handlePickSingleWallpaper = async (file: File) => {
    showToast('Loading 4K / 8K media…');
    await idbPut('f', 'wall', file);
    const id = `${file.name}|${file.size}|${file.lastModified || 0}`;
    try {
      const th = await makeWallpaperThumb(file);
      await wlTx(['w', 'wt', 'wm'], 'readwrite', (t) => {
        t.objectStore('w').put(file, id);
        if (th) t.objectStore('wt').put(th, id);
        t.objectStore('wm').put(
          { id, name: file.name, type: file.type || '', size: file.size, ts: Date.now() },
          id
        );
      });
      commitState((prev) => ({ ...prev, wcur: id }), true);
    } catch {
      // Still keep active wall even if vault thumbnailing failed
    }
    await refreshWallpaper();
    showToast('Wallpaper loaded into player');
  };

  const handleRandomWallpaper = async () => {
    const metas = await wlGetAllMeta();
    if (!metas.length) {
      setWheelSection('wallpapers');
      setWheelOpen(true);
      showToast('Add wallpapers to your 4K/8K vault first');
      return;
    }
    let pick = metas[Math.floor(Math.random() * metas.length)];
    if (metas.length > 1 && pick.id === state.wcur) {
      pick = metas[(metas.indexOf(pick) + 1) % metas.length];
    }
    const blob = await wlTx<Blob | undefined>('w', 'readonly', (t) =>
      t.objectStore('w').get(pick.id)
    ).catch(() => undefined);
    if (!blob) return showToast('Wallpaper missing');
    await idbPut('f', 'wall', blob);
    commitState((prev) => ({ ...prev, wcur: pick.id }), true);
    await refreshWallpaper();
    showToast(`Wallpaper: ${pick.name}`);
  };

  const handleApplyWallpaperById = async (id: string) => {
    const blob = await wlTx<Blob | undefined>('w', 'readonly', (t) =>
      t.objectStore('w').get(id)
    ).catch(() => undefined);
    if (!blob) return showToast('Wallpaper missing');
    await idbPut('f', 'wall', blob);
    commitState((prev) => ({ ...prev, wcur: id }), true);
    await refreshWallpaper();
    showToast('Wallpaper applied');
  };

  const handleRemoveWallpaper = async () => {
    await idbDel('f', 'wall');
    commitState((prev) => ({ ...prev, wcur: null }), true);
    await refreshWallpaper();
    showToast('Wallpaper removed');
  };

  // Audiobook import
  const handleAddAudiobooks = async (fileList: FileList) => {
    const files = Array.from(fileList).sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { numeric: true })
    );
    if (!files.length) return;

    const importGroups = async (groups: File[][]) => {
      showToast('Storing audiobooks in cave…');
      const addedIds: string[] = [];
      const newBooks: Record<string, Book> = {};
      for (const grp of groups) {
        const id = hashStr(grp.map((f) => f.name + f.size).join('|'));
        addedIds.push(id);
        for (let i = 0; i < grp.length; i++) {
          await idbPut('f', `${id}:${i}`, grp[i]);
        }
        const existing = stateRef.current.books[id];
        if (existing) {
          newBooks[id] = { ...existing, gone: false, u: Date.now() };
        } else {
          const cleanTitle =
            grp[0].name
              .replace(/\.[^.]+$/, '')
              .replace(/[_\-\s]*(part|chapter|ch|cd|disc)?[_\-\s]*\d+$/i, '') || grp[0].name;
          newBooks[id] = {
            id,
            title: cleanTitle,
            genres: genreFilter && genreFilter !== 'Unsorted' ? [genreFilter] : [],
            tracks: grp.map((f) => ({ n: f.name, d: 0 })),
            pos: { i: 0, t: 0 },
            u: Date.now(),
            added: Date.now(),
          };
        }
      }
      commitState(
        (prev) => ({ ...prev, books: { ...prev.books, ...newBooks } }),
        true
      );
      showToast(`Added ${addedIds.length} audiobook${addedIds.length > 1 ? 's' : ''}`);
      if (addedIds.length === 1) {
        const b = newBooks[addedIds[0]];
        loadTrack(b.id, b.pos.i, b.pos.t, false);
      }
    };

    if (files.length > 1) {
      setSheetData({
        open: true,
        title: `${files.length} audio files selected`,
        options: [
          {
            label: 'Combine as ONE multi-chapter audiobook',
            onClick: () => importGroups([files]),
          },
          {
            label: 'Add each file as a separate audiobook',
            onClick: () => importGroups(files.map((f) => [f])),
          },
        ],
      });
    } else {
      await importGroups([files]);
    }
  };

  const handleLoadSampleBook = async () => {
    showToast('Generating 3-chapter sample audiobook…');
    const sample = await createSampleAudiobook();
    commitState(
      (prev) => ({
        ...prev,
        books: { ...prev.books, [sample.id]: sample },
      }),
      true
    );
    loadTrack(sample.id, 0, 0, true);
    showToast('Sample audiobook ready — try scrubbing, next/prev & volume!');
  };

  const currentBook = curTrack ? state.books[curTrack.id] || null : null;
  const vocab = VOCAB[state.theme.sk] || VOCAB.cave;
  const logoPath = state.theme.lg ? LOGOS[state.theme.lg] : '';
  const showBackdropWall =
    !!wallUrl && state.theme.wallSpotMode !== 'player';
  const showPlayerWall =
    !!wallUrl && state.theme.wallSpotMode !== 'backdrop';

  const effectiveWeatherFx =
    isReadingPdf && state.theme.rainOnRead !== false
      ? state.theme.fx === 'storm'
        ? 'storm'
        : 'rain'
      : state.theme.fx;
  const hyperBg = HYPER_BACKGROUNDS[state.theme.sk] || HYPER_BACKGROUNDS.cave;

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden select-none sm:select-auto">
      {/* Full-Screen Atmospheric Wallpaper Backdrop */}
      {showBackdropWall && (
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-30 overflow-hidden">
          {wallIsVideo ? (
            <video
              src={wallUrl!}
              autoPlay
              loop
              muted
              playsInline
              className="h-full w-full object-cover scale-105 hq-media"
              style={{ filter: `blur(${state.theme.blur}px)` }}
            />
          ) : (
            <img
              src={wallUrl!}
              alt=""
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover scale-105 hq-media"
              style={{ filter: `blur(${state.theme.blur}px)` }}
            />
          )}
          <div
            className="absolute inset-0"
            style={{ background: 'var(--bg)', opacity: state.theme.dim }}
          />
        </div>
      )}

      {/* Hyper-Realistic Atmospheric Theme Background Layer */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 -z-40 anim-universe-breath"
        style={{ backgroundColor: 'var(--bg)', backgroundImage: hyperBg }}
      />

      {/* 3D Depth Weather & Universe-Specific Animated Effects (Includes Rain when reading PDFs) */}
      <WeatherCanvas
        fx={effectiveWeatherFx}
        intensity={state.theme.fxI}
        silhouette={state.theme.sc}
        universe={state.theme.sk}
        onThunder={playThunder}
      />

      {/* TOP BAR: BILLS CAVE App Icon Cover + Title + Search + Sort + Sharp Settings Wheel */}
      <header className="relative z-20 mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 pt-[calc(env(safe-area-inset-top)+10px)] pb-1.5">
        <div className="flex min-w-0 items-center gap-3">
          <img
            src={APP_ICON_COVER}
            alt="BILLS CAVE app cover"
            referrerPolicy="no-referrer"
            className="h-10 w-10 shrink-0 rounded-xl object-cover border shadow-md"
            style={{ borderColor: 'color-mix(in srgb, var(--am) 55%, transparent)' }}
          />
          {logoPath && (
            <svg
              viewBox="0 0 48 48"
              className="hidden sm:block h-7 w-7 shrink-0"
              style={{
                color: 'var(--am)',
                filter: 'drop-shadow(0 0 10px color-mix(in srgb, var(--am) 55%, transparent))',
              }}
              dangerouslySetInnerHTML={{ __html: logoPath }}
              aria-hidden="true"
            />
          )}
          <h1
            className="truncate text-lg sm:text-xl font-bold tracking-[0.14em] uppercase"
            style={{
              color: 'var(--am)',
              textShadow: '0 0 16px color-mix(in srgb, var(--am) 45%, transparent)',
            }}
          >
            {state.theme.nm || 'BILLS CAVE'}
          </h1>
        </div>

        {/* PC Lark-Ordered Action Cluster: Search + Sort + Sharp Settings Wheel */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {searchOpen ? (
            <div className="flex items-center gap-1 rounded-full bg-black/55 border border-white/15 px-3 py-1 backdrop-blur-md">
              <Search className="h-4 w-4 opacity-70" style={{ color: 'var(--am)' }} />
              <input
                autoFocus
                type="text"
                value={listFilter}
                onChange={(e) => setListFilter(e.target.value)}
                placeholder="Search…"
                className="w-28 sm:w-48 bg-transparent text-xs outline-none"
              />
              <button
                type="button"
                aria-label="Clear search"
                onClick={() => {
                  setListFilter('');
                  setSearchOpen(false);
                }}
                className="p-0.5 opacity-70 hover:opacity-100"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              aria-label="Search library"
              title="Search"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-black/30 hover:bg-white/10 transition"
            >
              <Search className="h-4 w-4" />
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              const order: ('recent' | 'title' | 'progress')[] = ['recent', 'title', 'progress'];
              const next = order[(order.indexOf(sortBy) + 1) % order.length];
              setSortBy(next);
              showToast(`Sorted by: ${next === 'recent' ? 'Recent' : next === 'title' ? 'A–Z' : 'Progress'}`);
            }}
            aria-label="Sort items"
            title={`Sort: ${sortBy}`}
            className="flex h-10 items-center gap-1.5 rounded-full border border-white/10 bg-black/30 hover:bg-white/10 px-3 transition text-xs font-semibold"
          >
            <ArrowUpDown className="h-4 w-4" style={{ color: 'var(--am)' }} />
            <span className="hidden md:inline capitalize">{sortBy}</span>
          </button>

          {/* ALL SETTINGS LIVE INSIDE THE SHARP SETTINGS WHEEL */}
          <SharpWheelButton open={wheelOpen} onClick={() => setWheelOpen(true)} />
        </div>
      </header>

      {/* ORDERED ROOM STRIP + GESTURE INDICATOR (Audiobooks | PDF | Open Links) */}
      <div className="relative z-20 mx-auto flex w-full max-w-6xl items-center justify-between gap-2 px-4 py-1.5">
        <div className="flex items-center gap-1.5">
          {ROOMS.map((r, idx) => {
            const active = roomIndex === idx;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => setRoomIndex(idx)}
                className="rounded-full px-4 py-1.5 text-xs font-bold transition border"
                style={{
                  color: active ? 'var(--bg)' : 'var(--fg)',
                  background: active ? 'var(--am)' : 'rgba(255,255,255,0.06)',
                  borderColor: active ? 'var(--am)' : 'rgba(255,255,255,0.1)',
                }}
              >
                {r.label}
              </button>
            );
          })}
        </div>

        <div className="hidden sm:flex items-center gap-1.5 text-[11px] opacity-60">
          <Hand className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
          <span>Swipe or ←/→ keys</span>
          <button
            type="button"
            aria-label="Previous room"
            onClick={() => setRoomIndex((i) => Math.max(0, i - 1))}
            disabled={roomIndex === 0}
            className="p-0.5 hover:opacity-100 disabled:opacity-25"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Next room"
            onClick={() => setRoomIndex((i) => Math.min(ROOMS.length - 1, i + 1))}
            disabled={roomIndex === ROOMS.length - 1}
            className="p-0.5 hover:opacity-100 disabled:opacity-25"
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* MAIN GESTURE CAROUSEL STAGE: Audiobooks ↔ PDF ↔ Open Links */}
      <main
        className="relative z-10 flex-1 min-h-0 overflow-hidden"
        style={{ perspective: '1400px' }}
        onTouchStart={handleStageTouchStart}
        onTouchMove={handleStageTouchMove}
        onTouchEnd={handleStageTouchEnd}
      >
        <div
          className={`flex h-full w-[300%] ${
            dragOffset === 0 ? 'transition-transform duration-300 ease-out' : ''
          }`}
          style={{
            transform: `translateX(calc(-${(roomIndex * 100) / 3}% + ${dragOffset}px))`,
          }}
        >
          {/* ROOM 0: AUDIOBOOKS */}
          <div
            className="h-full w-1/3 overflow-y-auto px-4 pt-2 pb-40"
            style={{
              transform:
                state.theme.anim3d && dragOffset !== 0
                  ? `rotateY(${Math.max(-8, Math.min(8, dragOffset * 0.025))}deg)`
                  : undefined,
            }}
          >
            <div className="mx-auto max-w-6xl">
              <AudiobooksView
                state={state}
                currentBookId={curTrack?.id || null}
                isPlaying={isPlaying}
                wallUrl={showPlayerWall ? wallUrl : null}
                wallIsVideo={wallIsVideo}
                listFilter={listFilter}
                onListFilterChange={setListFilter}
                sortBy={sortBy}
                onAddAudiobooks={handleAddAudiobooks}
                onLoadSampleBook={handleLoadSampleBook}
                onOpenBook={(id) => {
                  const b = state.books[id];
                  if (!b) return;
                  if (curTrack?.id === id && audioRef.current?.src) {
                    setFullPlayerOpen(true);
                    return;
                  }
                  const resumeAt = Math.max(0, b.pos.t - (state.rew || 0));
                  loadTrack(id, b.pos.i, resumeAt, true);
                  setFullPlayerOpen(true);
                }}
                genreFilter={genreFilter}
                onSelectGenreFilter={setGenreFilter}
                onAddGenre={() =>
                  setInputModal({
                    open: true,
                    title: 'New Genre Shelf',
                    placeholder: 'e.g. Cyberpunk, Horror, Classics…',
                    onConfirm: (val) => {
                      const clean = val.trim();
                      if (clean && !state.genres.includes(clean)) {
                        commitState((prev) => ({
                          ...prev,
                          genres: [...prev.genres, clean],
                        }), true);
                      }
                    },
                  })
                }
                onOpenSheet={(title, options) => setSheetData({ open: true, title, options })}
                onOpenInput={(opts) =>
                  setInputModal({
                    open: true,
                    title: opts.title,
                    initialValue: opts.initialValue,
                    placeholder: opts.placeholder,
                    onConfirm: opts.onConfirm,
                  })
                }
                onUpdateBook={(id, fn) => {
                  commitState((prev) => {
                    const existing = prev.books[id];
                    if (!existing) return prev;
                    const nextBook = fn(existing);
                    const nextBooks = { ...prev.books };
                    if (nextBook === null) {
                      delete nextBooks[id];
                      if (curTrackRef.current?.id === id && audioRef.current) {
                        audioRef.current.pause();
                        audioRef.current.removeAttribute('src');
                        setCurTrack(null);
                      }
                      return {
                        ...prev,
                        books: nextBooks,
                        marks: prev.marks.filter((m) => m.b !== id),
                        hist: prev.hist.filter((h) => h.id !== id),
                      };
                    }
                    nextBooks[id] = nextBook;
                    return { ...prev, books: nextBooks };
                  }, true);
                }}
                onJump={(id, idx, time) => {
                  if (curTrack?.id === id && curTrack.i === idx && audioRef.current?.src) {
                    audioRef.current.currentTime = time;
                    audioRef.current.play().catch(() => {});
                  } else {
                    loadTrack(id, idx, time, true);
                  }
                  setFullPlayerOpen(true);
                }}
                onDeleteMark={(bookId, ts) => {
                  commitState(
                    (prev) => ({
                      ...prev,
                      marks: prev.marks.filter((m) => !(m.b === bookId && m.ts === ts)),
                    }),
                    true
                  );
                  showToast('Bookmark deleted');
                }}
                onPickWallpaper={handlePickSingleWallpaper}
                onRandomWallpaper={handleRandomWallpaper}
                onOpenFullPlayer={() => setFullPlayerOpen(true)}
              />
            </div>
          </div>

          {/* ROOM 1: PDF */}
          <div className="h-full w-1/3 overflow-y-auto px-4 pt-2 pb-40">
            <div className="mx-auto max-w-6xl">
              <PdfView
                state={state}
                listFilter={listFilter}
                sortBy={sortBy}
                onSavePdfMeta={(id, entry: PdfEntry | null) => {
                  commitState((prev) => {
                    const nextPdfs = { ...prev.pdfs };
                    if (entry === null) delete nextPdfs[id];
                    else nextPdfs[id] = entry;
                    return { ...prev, pdfs: nextPdfs };
                  }, true);
                }}
                onToggleSpread={() =>
                  commitState((prev) => ({
                    ...prev,
                    spread: !(prev.spread === undefined ? window.innerWidth >= 760 : prev.spread),
                  }), true)
                }
                onReadingChange={setIsReadingPdf}
                onToggleRainOnRead={() => {
                  const nextVal = !(state.theme.rainOnRead !== false);
                  commitState(
                    (prev) => ({
                      ...prev,
                      theme: { ...prev.theme, rainOnRead: nextVal },
                    }),
                    true
                  );
                  showToast(nextVal ? 'Reading rain enabled' : 'Reading rain off');
                }}
                onOpenSheet={(title, options) => setSheetData({ open: true, title, options })}
                onOpenInput={(opts) =>
                  setInputModal({
                    open: true,
                    title: opts.title,
                    initialValue: opts.initialValue,
                    placeholder: opts.placeholder,
                    onConfirm: opts.onConfirm,
                  })
                }
                onToast={showToast}
              />
            </div>
          </div>

          {/* ROOM 2: OPEN LINKS */}
          <div className="h-full w-1/3 overflow-y-auto px-4 pt-2 pb-40">
            <div className="mx-auto max-w-6xl">
              <OpenLinksView
                state={state}
                listFilter={listFilter}
                onSaveSite={(url) => {
                  if (state.watch.some((w) => w.url === url)) {
                    showToast('Already saved');
                    return;
                  }
                  let title = url;
                  try {
                    title = new URL(url).hostname.replace(/^www\./, '');
                  } catch {
                    // ignore
                  }
                  commitState(
                    (prev) => ({
                      ...prev,
                      watch: [{ url, title, saved: Date.now() }, ...prev.watch],
                    }),
                    true
                  );
                  showToast('Saved link');
                }}
                onRecordVisit={(url) => {
                  let host = url;
                  try {
                    host = new URL(url).hostname.replace(/^www\./, '');
                  } catch {
                    // ignore
                  }
                  commitState((prev) => {
                    const now = Date.now();
                    const idx = prev.webHist.findIndex((h) => h.url === url);
                    const nextHist = [...prev.webHist];
                    if (idx >= 0) {
                      nextHist[idx] = { ...nextHist[idx], visited: now };
                    } else {
                      nextHist.push({ url, title: host, visited: now });
                    }
                    return {
                      ...prev,
                      lastWeb: url,
                      webHist: nextHist.slice(-150),
                    };
                  }, true);
                }}
                onRemoveSaved={(idx) => {
                  commitState((prev) => {
                    const nextWatch = [...prev.watch];
                    nextWatch.splice(idx, 1);
                    return { ...prev, watch: nextWatch };
                  }, true);
                }}
                onRenameSaved={(idx, title) => {
                  commitState((prev) => {
                    const nextWatch = [...prev.watch];
                    if (nextWatch[idx]) nextWatch[idx] = { ...nextWatch[idx], title };
                    return { ...prev, watch: nextWatch };
                  }, true);
                }}
                onOpenSheet={(title, options) => setSheetData({ open: true, title, options })}
                onOpenInput={(opts) =>
                  setInputModal({
                    open: true,
                    title: opts.title,
                    initialValue: opts.initialValue,
                    placeholder: opts.placeholder,
                    onConfirm: opts.onConfirm,
                  })
                }
                onToast={showToast}
              />
            </div>
          </div>
        </div>
      </main>

      {/* PERSISTENT MEDIA PLAYER DOCK (Zero bottom nav buttons — pure media controls + swipe-up to 3D stage) */}
      {!fullPlayerOpen && (
        <PlayerDock
          book={currentBook}
          trackIndex={curTrack?.i || 0}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          volume={state.vol ?? 0.85}
          muted={!!state.muted}
          material={state.theme.material}
          anim3d={state.theme.anim3d}
          depth3d={state.theme.depth3d}
          wallUrl={showPlayerWall ? wallUrl : null}
          wallIsVideo={wallIsVideo}
          bookIcon={vocab.bk}
          onTogglePlay={handleTogglePlay}
          onPrev={handlePrev}
          onNext={handleNext}
          onSeek={(t) => {
            if (!audioRef.current) return;
            audioRef.current.currentTime = t;
            setCurrentTime(t);
          }}
          onVolumeChange={(v) =>
            commitState((prev) => ({ ...prev, vol: v, muted: v === 0 }), true)
          }
          onToggleMute={() =>
            commitState((prev) => ({ ...prev, muted: !prev.muted }), true)
          }
          onExpand={() => setFullPlayerOpen(true)}
          onOpenWallSpot={() => setFullPlayerOpen(true)}
        />
      )}

      {/* FULL 3D NOW PLAYING & 4K/8K WALLPAPER STAGE */}
      <NowPlayingStage
        open={fullPlayerOpen}
        book={currentBook}
        trackIndex={curTrack?.i || 0}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        volume={state.vol ?? 0.85}
        muted={!!state.muted}
        theme={state.theme}
        wallUrl={showPlayerWall ? wallUrl : null}
        wallIsVideo={wallIsVideo}
        wallName={wallName}
        bookIcon={vocab.bk}
        onClose={() => setFullPlayerOpen(false)}
        onTogglePlay={handleTogglePlay}
        onPrev={handlePrev}
        onNext={handleNext}
        onSkipBack30={() => {
          if (!audioRef.current) return;
          const next = Math.max(0, audioRef.current.currentTime - 30);
          audioRef.current.currentTime = next;
          setCurrentTime(next);
        }}
        onSkipFwd30={() => {
          if (!audioRef.current) return;
          const next = Math.min(duration || Infinity, audioRef.current.currentTime + 30);
          audioRef.current.currentTime = next;
          setCurrentTime(next);
        }}
        onSeek={(t) => {
          if (!audioRef.current) return;
          audioRef.current.currentTime = t;
          setCurrentTime(t);
        }}
        onVolumeChange={(v) =>
          commitState((prev) => ({ ...prev, vol: v, muted: v === 0 }), true)
        }
        onToggleMute={() =>
          commitState((prev) => ({ ...prev, muted: !prev.muted }), true)
        }
        onBookmark={() => {
          if (!curTrack) return;
          const time = audioRef.current?.currentTime || 0;
          setInputModal({
            open: true,
            title: `Bookmark at ${Math.floor(time)}s`,
            placeholder: 'Optional bookmark note…',
            onConfirm: (note) => {
              commitState(
                (prev) => ({
                  ...prev,
                  marks: [
                    ...prev.marks,
                    { b: curTrack.id, i: curTrack.i, t: time, ts: Date.now(), note },
                  ],
                }),
                true
              );
              showToast('Bookmark saved');
            },
          });
        }}
        onSpeedSleep={() => {
          setSheetData({
            open: true,
            title: 'Playback Speed & Sleep Timer',
            options: [
              ...[0.8, 1, 1.25, 1.5, 1.75, 2, 2.5].map((r) => ({
                label: `Speed ${r}×`,
                active: state.rate === r,
                onClick: () => {
                  if (audioRef.current) audioRef.current.playbackRate = r;
                  commitState((prev) => ({ ...prev, rate: r }), true);
                },
              })),
              ...[15, 30, 45, 60].map((m) => ({
                label: `Sleep timer: ${m} minutes`,
                onClick: () => {
                  if (sleepTimerRef.current) window.clearTimeout(sleepTimerRef.current);
                  sleepTimerRef.current = window.setTimeout(() => {
                    audioRef.current?.pause();
                  }, m * 60000);
                  showToast(`Sleep timer set for ${m} min`);
                },
              })),
              {
                label: 'Cancel sleep timer',
                onClick: () => {
                  if (sleepTimerRef.current) window.clearTimeout(sleepTimerRef.current);
                  sleepTimerRef.current = null;
                  showToast('Sleep timer cancelled');
                },
              },
              {
                label: `Rewind on resume: ${state.rew || 0}s`,
                onClick: () =>
                  setInputModal({
                    open: true,
                    title: 'Rewind on Resume (seconds)',
                    initialValue: String(state.rew || 0),
                    onConfirm: (v) => {
                      commitState(
                        (prev) => ({ ...prev, rew: Math.max(0, Number(v) || 0) }),
                        true
                      );
                    },
                  }),
              },
            ],
          });
        }}
        onJumpTime={() => {
          setInputModal({
            open: true,
            title: 'Jump to Timestamp (h:mm:ss or mm:ss)',
            placeholder: 'e.g. 12:30',
            onConfirm: (val) => {
              const parts = val.split(':').map(Number).reverse();
              const t = (parts[0] || 0) + (parts[1] || 0) * 60 + (parts[2] || 0) * 3600;
              if (!Number.isNaN(t) && audioRef.current) {
                audioRef.current.currentTime = Math.min(t, duration || t);
                setCurrentTime(audioRef.current.currentTime);
              }
            },
          });
        }}
        onPickWallpaper={handlePickSingleWallpaper}
        onOpenWallLibrary={() => {
          setWheelSection('wallpapers');
          setWheelOpen(true);
        }}
        onRandomWallpaper={handleRandomWallpaper}
        onRemoveWallpaper={handleRemoveWallpaper}
        onToggleWallFit={() =>
          commitState(
            (prev) => ({
              ...prev,
              theme: {
                ...prev.theme,
                wallFit: prev.theme.wallFit === 'contain' ? 'cover' : 'contain',
              },
            }),
            true
          )
        }
      />

      {/* SHARP SETTINGS WHEEL HUB (All Settings Consolidated Here) */}
      <SharpSettingsWheelModal
        open={wheelOpen}
        initialSection={wheelSection}
        state={state}
        rainLoaded={rainLoaded}
        thunderLoaded={thunderLoaded}
        onClose={() => setWheelOpen(false)}
        onUpdateTheme={(patch) =>
          commitState((prev) => ({ ...prev, theme: { ...prev.theme, ...patch } }), true)
        }
        onResetTheme={() =>
          commitState((prev) => ({ ...prev, theme: defaultTheme() }), true)
        }
        onPickSingleWallpaper={handlePickSingleWallpaper}
        onRemoveWallpaper={handleRemoveWallpaper}
        onApplyWallpaperId={handleApplyWallpaperById}
        onRandomWallpaper={handleRandomWallpaper}
        onToggleLaunchShuffle={() => {
          commitState((prev) => ({ ...prev, wshuf: !prev.wshuf }), true);
          showToast(!state.wshuf ? 'Launch shuffle enabled' : 'Launch shuffle off');
        }}
        onPickRainAudio={async (f) => {
          await idbPut('f', 'ambience:rain', f);
          await loadAmbienceFiles();
          showToast('Rain recording saved');
        }}
        onPickThunderAudio={async (f) => {
          await idbPut('f', 'ambience:thunder', f);
          await loadAmbienceFiles();
          showToast('Thunder recording saved');
        }}
        onExportBackup={async () => {
          const filename = `brazils-cave-memory-${new Date().toISOString().slice(0, 10)}.json`;
          const file = new File([JSON.stringify(state)], filename, {
            type: 'application/json',
          });
          const a = document.createElement('a');
          a.href = URL.createObjectURL(file);
          a.download = filename;
          a.click();
          showToast('Backup exported');
        }}
        onImportBackup={async (file) => {
          try {
            const parsed = JSON.parse(await file.text()) as Partial<AppState>;
            commitState((prev) => {
              const nextBooks = { ...prev.books };
              for (const [id, b] of Object.entries(parsed.books || {})) {
                const old = nextBooks[id];
                if (!old || (b.u || 0) > (old.u || 0)) {
                  nextBooks[id] = { ...b, gone: !old || old.gone };
                }
              }
              const hKeys = new Set(prev.hist.map((h) => h.id + h.ts));
              const nextHist = [...prev.hist];
              (parsed.hist || []).forEach((h) => {
                if (!hKeys.has(h.id + h.ts)) nextHist.push(h);
              });
              nextHist.sort((a, b) => a.ts - b.ts);

              const mKeys = new Set(prev.marks.map((m) => m.b + m.ts));
              const nextMarks = [...prev.marks];
              (parsed.marks || []).forEach((m) => {
                if (!mKeys.has(m.b + m.ts)) nextMarks.push(m);
              });

              const genres = Array.from(new Set([...prev.genres, ...(parsed.genres || [])]));
              return {
                ...prev,
                books: nextBooks,
                hist: nextHist,
                marks: nextMarks,
                genres,
                pdfs: { ...(parsed.pdfs || {}), ...prev.pdfs },
              };
            }, true);
            showToast('Memory restored');
          } catch {
            showToast('Invalid backup JSON file');
          }
        }}
        onRequestPersist={async () => {
          if (navigator.storage?.persist) {
            const granted = await navigator.storage.persist();
            showToast(granted ? 'Protected persistent storage granted' : 'Not granted — keep backups');
          } else {
            showToast('Persistent storage API unavailable');
          }
        }}
        onJumpHistory={(id, idx, time) => {
          if (!state.books[id]) {
            showToast('Audiobook no longer in library');
            return;
          }
          setRoomIndex(0);
          loadTrack(id, idx, time, true);
          setFullPlayerOpen(true);
        }}
        onToast={showToast}
      />

      {/* Action Sheet, Input Modal, Toast */}
      <ActionSheet
        open={sheetData.open}
        title={sheetData.title}
        options={sheetData.options}
        material={state.theme.material}
        onClose={() => setSheetData((s) => ({ ...s, open: false }))}
      />
      <InputModal
        open={inputModal.open}
        title={inputModal.title}
        placeholder={inputModal.placeholder}
        initialValue={inputModal.initialValue}
        material={state.theme.material}
        onConfirm={(val) => {
          inputModal.onConfirm(val);
          setInputModal((m) => ({ ...m, open: false }));
        }}
        onCancel={() => setInputModal((m) => ({ ...m, open: false }))}
      />
      <ToastBanner message={toastMsg} />

      {/* Core HTML5 Audio Element */}
      <audio
        ref={audioRef}
        preload="metadata"
        onPlay={() => {
          setIsPlaying(true);
          if (readyRef.current && curTrackRef.current && audioRef.current) {
            sessionRef.current = {
              id: curTrackRef.current.id,
              i: curTrackRef.current.i,
              from: audioRef.current.currentTime,
              start: Date.now(),
            };
          }
        }}
        onPause={() => {
          setIsPlaying(false);
          savePosition(true);
          endSession();
        }}
        onTimeUpdate={() => {
          if (!audioRef.current) return;
          setCurrentTime(audioRef.current.currentTime || 0);
          if (Number.isFinite(audioRef.current.duration)) {
            setDuration(audioRef.current.duration);
          }
          if (Date.now() - lastSaveRef.current > 1000) {
            lastSaveRef.current = Date.now();
            savePosition(false);
          }
        }}
        onEnded={() => {
          endSession();
          const cur = curTrackRef.current;
          if (!cur) return;
          const b = stateRef.current.books[cur.id];
          if (b && cur.i + 1 < b.tracks.length) {
            loadTrack(cur.id, cur.i + 1, 0, true);
          } else {
            setIsPlaying(false);
            commitState((prev) => {
              const book = prev.books[cur.id];
              if (!book) return prev;
              return {
                ...prev,
                books: { ...prev.books, [cur.id]: { ...book, done: true } },
              };
            }, true);
          }
        }}
      />
    </div>
  );
}
