import { AppState, Book, WallpaperMeta } from '../types';
import { defaultTheme } from '../data/themes';

export const fmt = (t: number): string => {
  const sec = Math.max(0, Math.floor(t || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
};

export const hashStr = (s: string): string => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36) + s.length.toString(36);
};

let dbPromise: Promise<IDBDatabase> | null = null;

export function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open('brazils-cave', 2);
    req.onupgradeneeded = () => {
      const d = req.result;
      ['f', 'm', 'w', 'wt', 'wm'].forEach((n) => {
        if (!d.objectStoreNames.contains(n)) d.createObjectStore(n);
      });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

export function idbGet<T = unknown>(store: string, key: string): Promise<T | undefined> {
  return getDB().then(
    (d) =>
      new Promise((res, rej) => {
        const tx = d.transaction(store, 'readonly');
        const q = tx.objectStore(store).get(key);
        tx.oncomplete = () => res(q.result as T | undefined);
        tx.onerror = () => rej(tx.error);
      })
  );
}

export function idbPut(store: string, key: string, val: unknown): Promise<void> {
  return getDB().then(
    (d) =>
      new Promise((res, rej) => {
        const tx = d.transaction(store, 'readwrite');
        tx.objectStore(store).put(val, key);
        tx.oncomplete = () => res();
        tx.onerror = () => rej(tx.error);
      })
  );
}

export function idbDel(store: string, key: string): Promise<void> {
  return getDB().then(
    (d) =>
      new Promise((res, rej) => {
        const tx = d.transaction(store, 'readwrite');
        tx.objectStore(store).delete(key);
        tx.oncomplete = () => res();
        tx.onerror = () => rej(tx.error);
      })
  );
}

export function wlTx<T>(
  stores: string | string[],
  mode: IDBTransactionMode,
  fn: (t: IDBTransaction) => IDBRequest<T> | void
): Promise<T> {
  return getDB().then(
    (d) =>
      new Promise((res, rej) => {
        const t = d.transaction(stores, mode);
        let out: IDBRequest<T> | void;
        try {
          out = fn(t);
        } catch (e) {
          try {
            t.abort();
          } catch {
            // ignore
          }
          rej(e);
          return;
        }
        t.oncomplete = () => res((out && 'result' in out ? out.result : out) as T);
        t.onerror = (ev) =>
          rej(((ev.target as IDBRequest)?.error) || t.error || new Error('Storage error'));
        t.onabort = () => rej(t.error || new Error('Storage full or blocked'));
      })
  );
}

export async function wlGetAllMeta(): Promise<WallpaperMeta[]> {
  try {
    const all = await wlTx<WallpaperMeta[]>('wm', 'readonly', (t) =>
      t.objectStore('wm').getAll()
    );
    return (all || []).sort((a, b) => b.ts - a.ts);
  } catch {
    return [];
  }
}

export async function wlCountMeta(): Promise<number> {
  try {
    return await wlTx<number>('wm', 'readonly', (t) => t.objectStore('wm').count());
  } catch {
    return 0;
  }
}

const WL_THUMB = 280;

export async function makeWallpaperThumb(f: Blob): Promise<Blob | null> {
  try {
    if ((f.type || '').startsWith('video')) {
      const u = URL.createObjectURL(f);
      const v = document.createElement('video');
      v.muted = true;
      v.preload = 'auto';
      v.playsInline = true;
      v.src = u;
      try {
        await new Promise<void>((ok, no) => {
          const to = setTimeout(() => no(new Error('timeout')), 6000);
          v.onloadeddata = () => {
            clearTimeout(to);
            ok();
          };
          v.onerror = () => {
            clearTimeout(to);
            no(new Error('video error'));
          };
        });
        try {
          v.currentTime = Math.min(1, (v.duration || 1) / 4);
          await new Promise<void>((ok) => {
            v.onseeked = () => ok();
            setTimeout(ok, 1500);
          });
        } catch {
          // ignore seek errors
        }
        const s = WL_THUMB / Math.max(v.videoWidth || 1, v.videoHeight || 1);
        const c = document.createElement('canvas');
        c.width = Math.max(1, (v.videoWidth * s) | 0);
        c.height = Math.max(1, (v.videoHeight * s) | 0);
        c.getContext('2d')?.drawImage(v, 0, 0, c.width, c.height);
        return await new Promise<Blob | null>((r) => c.toBlob(r, 'image/jpeg', 0.75));
      } finally {
        URL.revokeObjectURL(u);
        v.removeAttribute('src');
        v.load();
      }
    }

    let bm: ImageBitmap;
    try {
      bm = await createImageBitmap(f, { resizeWidth: WL_THUMB, resizeQuality: 'medium' });
    } catch {
      bm = await createImageBitmap(f);
    }
    const s = Math.min(1, WL_THUMB / Math.max(bm.width, bm.height));
    const c = document.createElement('canvas');
    c.width = Math.max(1, (bm.width * s) | 0);
    c.height = Math.max(1, (bm.height * s) | 0);
    c.getContext('2d')?.drawImage(bm, 0, 0, c.width, c.height);
    bm.close?.();
    return await new Promise<Blob | null>((r) =>
      c.toBlob((b) => (b ? r(b) : c.toBlob(r, 'image/jpeg', 0.75)), 'image/webp', 0.75)
    );
  } catch {
    return null;
  }
}

export function createInitialState(): AppState {
  const base: AppState = {
    books: {},
    hist: [],
    marks: [],
    genres: ['Anime', 'Fantasy', 'Dark Fantasy', 'Sci-Fi', 'Comics'],
    pdfs: {},
    watch: [],
    webHist: [],
    lastWeb: '',
    rate: 1,
    rew: 0,
    vol: 0.85,
    muted: false,
    u: 0,
    theme: defaultTheme(),
    wcur: null,
    wshuf: false,
  };
  try {
    const raw = localStorage.getItem('cave');
    if (raw) {
      const parsed = JSON.parse(raw);
      Object.assign(base, parsed);
      base.theme = { ...defaultTheme(), ...(parsed.theme || {}) };
      if (base.theme.nm === 'THE BRAZILS CAVE') {
        base.theme.nm = 'BILLS CAVE';
      }
    }
  } catch {
    // ignore parse errors
  }
  return base;
}

let lastMirror = 0;

export function persistState(state: AppState, force = false): void {
  state.u = Date.now();
  try {
    localStorage.setItem('cave', JSON.stringify(state));
  } catch {
    // ignore quota errors on localStorage
  }
  if (force || Date.now() - lastMirror > 6000) {
    lastMirror = Date.now();
    idbPut('m', 'S', state).catch(() => {});
  }
}

export function cleanWebURL(v: string): string {
  const trimmed = (v || '').trim();
  if (!trimmed) return '';
  const withProto = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const u = new URL(withProto);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
    return u.href;
  } catch {
    return '';
  }
}

/** Generates a real playable multi-chapter ambient WAV audiobook for instant testing of scrubbing, prev/next & volume */
export async function createSampleAudiobook(): Promise<Book> {
  const makeToneWav = (freqBase: number, durationSec: number): Blob => {
    const sampleRate = 22050;
    const numSamples = Math.floor(sampleRate * durationSec);
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);
    const writeStr = (offset: number, s: string) => {
      for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
    };
    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(36, 'data');
    view.setUint32(40, numSamples * 2, true);

    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const env = Math.min(1, t * 1.5) * Math.min(1, (durationSec - t) * 1.5);
      const chord =
        0.35 * Math.sin(2 * Math.PI * freqBase * t) +
        0.25 * Math.sin(2 * Math.PI * freqBase * 1.25 * t) +
        0.2 * Math.sin(2 * Math.PI * freqBase * 1.5 * t) +
        0.1 * Math.sin(2 * Math.PI * (freqBase * 0.5) * t + Math.sin(t * 2) * 0.5);
      const sample = Math.max(-1, Math.min(1, chord * env * (0.65 + 0.35 * Math.sin(t * 0.8))));
      view.setInt16(44 + i * 2, sample * 32767, true);
    }
    return new Blob([buffer], { type: 'audio/wav' });
  };

  const id = 'demo-cave-chronicles';
  const chapters = [
    { name: 'Chapter 1 · Descent into the Brazils Cave.wav', freq: 146.83, dur: 38 },
    { name: 'Chapter 2 · Echoes of Brushed Steel & Cedar.wav', freq: 174.61, dur: 42 },
    { name: 'Chapter 3 · Rain Against the Crystal Spire.wav', freq: 196.0, dur: 45 },
  ];

  for (let i = 0; i < chapters.length; i++) {
    const blob = makeToneWav(chapters[i].freq, chapters[i].dur);
    await idbPut('f', `${id}:${i}`, blob);
  }

  return {
    id,
    title: 'Chronicles of the Brazils Cave (Sample)',
    genres: ['Fantasy', 'Dark Fantasy'],
    tracks: chapters.map((c) => ({ n: c.name, d: c.dur })),
    pos: { i: 0, t: 0 },
    u: Date.now(),
    added: Date.now(),
    isDemo: true,
  };
}
