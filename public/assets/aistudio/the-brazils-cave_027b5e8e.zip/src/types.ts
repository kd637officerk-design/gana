export type RoomTab = 'lib' | 'pdf' | 'links';

export type MaterialType = 'metal' | 'glass' | 'wood' | 'obsidian';

export type ThemeFontKey = 'sans' | 'serif' | 'classic' | 'fantasy' | 'mono';

export type WeatherEffect = '' | 'rain' | 'storm' | 'embers' | 'magic' | 'snow';

export type SilhouetteType = '' | 'castle' | 'peaks';

export type LogoKey = '' | 'cave' | 'dark' | 'wiz' | 'storm' | 'rain';

export interface ThemeConfig {
  nm: string;
  lg: LogoKey;
  pre: string;
  sk: string;
  bg: string;
  am: string;
  fg: string;
  ft: ThemeFontKey;
  fx: WeatherEffect;
  fxI: number;
  sc: SilhouetteType;
  dim: number;
  blur: number;
  snd: boolean;
  vol: number;
  material: MaterialType;
  anim3d: boolean;
  depth3d: number;
  sheen: number;
  wallSpotMode: 'both' | 'player' | 'backdrop';
  wallFit: 'cover' | 'contain';
  rainOnRead: boolean;
}

export interface Track {
  n: string;
  d: number;
}

export interface Book {
  id: string;
  title: string;
  genres: string[];
  tracks: Track[];
  pos: { i: number; t: number };
  u: number;
  added?: number;
  gone?: boolean;
  done?: boolean;
  isDemo?: boolean;
}

export interface HistoryEntry {
  id: string;
  title: string;
  ts: number;
  i: number;
  n: number;
  from: number;
  to: number;
}

export interface Bookmark {
  b: string;
  i: number;
  t: number;
  ts: number;
  note: string;
}

export interface PdfAnnotation {
  t: 'hl' | 'pen' | 'sig' | 'txt' | 'note';
  x?: number;
  y?: number;
  w?: number;
  h?: number;
  p?: [number, number][];
  s?: string;
}

export interface PdfEntry {
  n: string;
  page: number;
  pages?: number;
  u: number;
  ann?: Record<number, PdfAnnotation[]>;
  log?: number[];
}

export interface WatchItem {
  url: string;
  title: string;
  saved: number;
}

export interface WebHistItem {
  url: string;
  title: string;
  visited: number;
}

export interface WallpaperMeta {
  id: string;
  name: string;
  type: string;
  size: number;
  ts: number;
}

export interface AppState {
  books: Record<string, Book>;
  hist: HistoryEntry[];
  marks: Bookmark[];
  genres: string[];
  pdfs: Record<string, PdfEntry>;
  watch: WatchItem[];
  webHist: WebHistItem[];
  lastWeb: string;
  last?: string;
  rate: number;
  rew: number;
  vol: number;
  muted: boolean;
  u: number;
  theme: ThemeConfig;
  wcur?: string | null;
  wshuf?: boolean;
  spread?: boolean;
}

export interface SheetOption {
  label: string;
  onClick?: () => void;
  active?: boolean;
  danger?: boolean;
}
