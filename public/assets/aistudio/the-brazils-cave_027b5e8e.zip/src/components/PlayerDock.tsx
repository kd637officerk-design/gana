import React, { useRef } from 'react';
import {
  ChevronUp,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Book, MaterialType } from '../types';
import { APP_ICON_COVER } from '../data/themes';
import { fmt } from '../utils/storage';
import { MaterialSurface } from './MaterialSurface';

interface PlayerDockProps {
  book: Book | null;
  trackIndex: number;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  material: MaterialType;
  anim3d: boolean;
  depth3d: number;
  wallUrl: string | null;
  wallIsVideo: boolean;
  bookIcon: string;
  onTogglePlay: () => void;
  onPrev: () => void;
  onNext: () => void;
  onSeek: (time: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
  onExpand: () => void;
  onOpenWallSpot: () => void;
}

export const PlayerDock: React.FC<PlayerDockProps> = ({
  book,
  trackIndex,
  isPlaying,
  currentTime,
  duration,
  volume,
  muted,
  material,
  anim3d,
  depth3d,
  wallUrl,
  wallIsVideo,
  bookIcon,
  onTogglePlay,
  onPrev,
  onNext,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onExpand,
  onOpenWallSpot,
}) => {
  const dragStartY = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    dragStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (dragStartY.current === null) return;
    const dy = e.changedTouches[0].clientY - dragStartY.current;
    dragStartY.current = null;
    if (dy < -42) {
      onExpand();
    }
  };

  const safeDur = duration > 0 ? duration : 1;
  const pct = Math.min(100, Math.max(0, (currentTime / safeDur) * 100));

  return (
    <div
      className="fixed inset-x-0 bottom-0 z-30 px-2.5 pb-[calc(10px+env(safe-area-inset-bottom))] pt-1 pointer-events-none"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      <MaterialSurface
        material={material}
        anim3d={anim3d}
        depth3d={depth3d}
        tiltMax={4}
        className="pointer-events-auto mx-auto max-w-4xl rounded-2xl px-3.5 pt-2 pb-3"
      >
        {/* Swipe-up grab handle */}
        <button
          type="button"
          onClick={onExpand}
          aria-label="Expand full player and 4K/8K wallpaper stage"
          className="mx-auto mb-1.5 flex items-center gap-1.5 px-4 py-0.5 text-[11px] font-medium tracking-wide opacity-75 hover:opacity-100"
          style={{ color: 'var(--am)' }}
        >
          <span className="h-1 w-8 rounded-full bg-current opacity-60" />
          <ChevronUp className="h-3.5 w-3.5" />
        </button>

        {/* Scrubbing Progress Bar */}
        <div className="mb-2 flex items-center gap-2.5">
          <span className="tabular-nums text-[11px] opacity-75 w-12 text-right shrink-0">
            {fmt(currentTime)}
          </span>
          <div className="relative flex-1 flex items-center h-5">
            <div className="pointer-events-none absolute inset-x-0 h-1.5 rounded-full bg-black/45 overflow-hidden">
              <div
                className="h-full rounded-full transition-[width] duration-100"
                style={{
                  width: `${pct}%`,
                  background: 'var(--am)',
                  boxShadow: '0 0 10px color-mix(in srgb, var(--am) 75%, transparent)',
                }}
              />
            </div>
            <input
              type="range"
              aria-label="Audio track progress scrubber"
              min={0}
              max={safeDur}
              step={0.1}
              value={Math.min(currentTime, safeDur)}
              disabled={!book}
              onChange={(e) => onSeek(Number(e.target.value))}
              className="cave-slider relative z-10 w-full opacity-95 disabled:opacity-40"
            />
          </div>
          <span className="tabular-nums text-[11px] opacity-75 w-14 shrink-0">
            -{fmt(Math.max(0, duration - currentTime))}
          </span>
        </div>

        {/* Main Controls Row */}
        <div className="flex items-center justify-between gap-2 sm:gap-3">
          {/* Left: Wallpaper / Track Thumbnail + Title */}
          <div className="flex min-w-0 flex-1 items-center gap-2.5">
            <button
              type="button"
              onClick={onOpenWallSpot}
              title="Open 4K / 8K Wallpaper & GIF Stage"
              className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl border flex items-center justify-center group"
              style={{
                borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
                background: 'color-mix(in srgb, var(--bg) 70%, var(--am) 12%)',
              }}
            >
              {wallUrl ? (
                wallIsVideo ? (
                  <video
                    src={wallUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="h-full w-full object-cover hq-media"
                  />
                ) : (
                  <img
                    src={wallUrl}
                    alt="Player wallpaper"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover hq-media"
                  />
                )
              ) : (
                <img
                  src={APP_ICON_COVER}
                  alt="BILLS CAVE cover"
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover hq-media"
                />
              )}
              <span className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors" />
            </button>

            <button
              type="button"
              onClick={onExpand}
              className="min-w-0 flex-1 text-left"
            >
              <div className="truncate text-sm font-bold" style={{ color: book ? 'var(--fg)' : 'var(--mu)' }}>
                {book ? book.title : 'No audiobook active'}
              </div>
              <div className="truncate text-xs opacity-75">
                {book
                  ? `${book.tracks.length > 1 ? `Part ${trackIndex + 1}/${book.tracks.length} · ` : ''}${
                      book.tracks[trackIndex]?.n || 'Ready'
                    }`
                  : 'Swipe up or tap wallpaper slot for 4K/8K deck'}
              </div>
            </button>
          </div>

          {/* Center: Previous, Play/Pause, Next */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={onPrev}
              disabled={!book}
              aria-label="Previous track or restart"
              className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10 active:scale-95 disabled:opacity-35 transition"
            >
              <SkipBack className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={onTogglePlay}
              disabled={!book}
              aria-label={isPlaying ? 'Pause' : 'Play'}
              className="flex h-12 w-12 items-center justify-center rounded-full font-bold shadow-lg active:scale-95 disabled:opacity-40 transition"
              style={{
                background: 'var(--am)',
                color: 'var(--bg)',
                boxShadow: '0 4px 18px color-mix(in srgb, var(--am) 50%, transparent)',
              }}
            >
              {isPlaying ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 fill-current ml-0.5" />}
            </button>
            <button
              type="button"
              onClick={onNext}
              disabled={!book || trackIndex + 1 >= (book?.tracks.length || 0)}
              aria-label="Next track"
              className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-white/10 active:scale-95 disabled:opacity-35 transition"
            >
              <SkipForward className="h-5 w-5" />
            </button>
          </div>

          {/* Desktop Inline Volume Adjustment */}
          <div className="hidden sm:flex items-center gap-1.5 w-32 shrink-0">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={muted ? 'Unmute audio' : 'Mute audio'}
              className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-white/10 transition shrink-0"
              style={{ color: muted ? '#ff7b7b' : 'var(--am)' }}
            >
              {muted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            <input
              type="range"
              aria-label="Volume adjustment"
              min={0}
              max={1}
              step={0.02}
              value={muted ? 0 : volume}
              onChange={(e) => onVolumeChange(Number(e.target.value))}
              className="cave-slider w-full"
            />
          </div>
        </div>

        {/* Mobile Volume Adjustment Row */}
        <div className="mt-1.5 flex sm:hidden items-center gap-2 border-t border-white/10 pt-1.5">
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'Unmute audio' : 'Mute audio'}
            className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-white/10 transition shrink-0"
            style={{ color: muted ? '#ff7b7b' : 'var(--am)' }}
          >
            {muted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>
          <input
            type="range"
            aria-label="Mobile volume adjustment"
            min={0}
            max={1}
            step={0.02}
            value={muted ? 0 : volume}
            onChange={(e) => onVolumeChange(Number(e.target.value))}
            className="cave-slider flex-1"
          />
          <span className="tabular-nums text-[11px] opacity-75 w-9 text-right">
            {muted ? '0%' : `${Math.round(volume * 100)}%`}
          </span>
        </div>
      </MaterialSurface>
    </div>
  );
};
