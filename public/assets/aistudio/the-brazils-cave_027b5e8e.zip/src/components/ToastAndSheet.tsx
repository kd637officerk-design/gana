import React, { useEffect, useState } from 'react';
import { MaterialType, SheetOption } from '../types';
import { MaterialSurface } from './MaterialSurface';

interface ActionSheetProps {
  open: boolean;
  title: string;
  options: SheetOption[];
  material: MaterialType;
  onClose: () => void;
}

export const ActionSheet: React.FC<ActionSheetProps> = ({
  open,
  title,
  options,
  material,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <MaterialSurface
        material={material}
        anim3d={false}
        className="w-full max-w-xl max-h-[82vh] overflow-y-auto rounded-t-3xl p-4 pb-6 shadow-2xl"
      >
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-white/25" />
        <h3
          className="px-2 pb-3 text-xs font-bold tracking-[0.18em] uppercase border-b"
          style={{
            color: 'var(--am)',
            borderColor: 'color-mix(in srgb, var(--am) 26%, transparent)',
          }}
        >
          {title}
        </h3>
        <div className="mt-2 divide-y divide-white/5">
          {options.map((opt, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                opt.onClick?.();
                onClose();
              }}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-3.5 text-left text-sm font-medium transition-colors active:bg-white/10 hover:bg-white/5"
              style={{
                color: opt.active
                  ? 'var(--am)'
                  : opt.danger
                  ? '#ff6b6b'
                  : 'var(--fg)',
              }}
            >
              <span
                className="h-5 w-1 rounded-full shrink-0"
                style={{
                  background: opt.active
                    ? 'var(--am)'
                    : 'color-mix(in srgb, var(--am) 45%, transparent)',
                }}
              />
              <span className="flex-1">{opt.label}</span>
              {opt.active && <span className="text-xs font-bold">Active</span>}
            </button>
          ))}
        </div>
      </MaterialSurface>
    </div>
  );
};

interface InputModalProps {
  open: boolean;
  title: string;
  placeholder?: string;
  initialValue?: string;
  confirmLabel?: string;
  onConfirm: (value: string) => void;
  onCancel: () => void;
  material: MaterialType;
}

export const InputModal: React.FC<InputModalProps> = ({
  open,
  title,
  placeholder = '',
  initialValue = '',
  confirmLabel = 'Save',
  onConfirm,
  onCancel,
  material,
}) => {
  const [val, setVal] = useState(initialValue);

  useEffect(() => {
    if (open) setVal(initialValue);
  }, [open, initialValue]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onCancel();
      }}
    >
      <MaterialSurface
        material={material}
        anim3d={false}
        className="w-full max-w-md rounded-2xl p-5 shadow-2xl"
      >
        <h3 className="text-base font-bold mb-3" style={{ color: 'var(--am)' }}>
          {title}
        </h3>
        <input
          autoFocus
          type="text"
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') onConfirm(val);
            if (e.key === 'Escape') onCancel();
          }}
          placeholder={placeholder}
          className="w-full rounded-xl px-3.5 py-2.5 text-sm outline-none border"
          style={{
            background: 'color-mix(in srgb, var(--bg) 75%, #000)',
            color: 'var(--fg)',
            borderColor: 'color-mix(in srgb, var(--am) 32%, transparent)',
          }}
        />
        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[44px] rounded-xl px-4 py-2 text-sm font-medium bg-white/10 hover:bg-white/15"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onConfirm(val)}
            className="min-h-[44px] rounded-xl px-5 py-2 text-sm font-bold"
            style={{ background: 'var(--am)', color: 'var(--bg)' }}
          >
            {confirmLabel}
          </button>
        </div>
      </MaterialSurface>
    </div>
  );
};

export const ToastBanner: React.FC<{ message: string | null }> = ({ message }) => {
  if (!message) return null;
  return (
    <div
      role="status"
      className="pointer-events-none fixed left-1/2 bottom-28 z-[70] -translate-x-1/2 rounded-2xl border px-4 py-2.5 text-center text-sm font-medium shadow-2xl backdrop-blur-md max-w-[90vw]"
      style={{
        background: 'color-mix(in srgb, var(--bg) 90%, #000)',
        color: 'var(--fg)',
        borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
      }}
    >
      {message}
    </div>
  );
};
