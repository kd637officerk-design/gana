import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  CloudRain,
  Download,
  Hand,
  History,
  Image as ImageIcon,
  Layers,
  Monitor,
  Palette,
  RotateCcw,
  Shield,
  Shuffle,
  Smartphone,
  Sparkles,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  AppState,
  LogoKey,
  MaterialType,
  SilhouetteType,
  ThemeConfig,
  ThemeFontKey,
  WallpaperMeta,
  WeatherEffect,
} from '../types';
import { defaultTheme, PRESETS, SETTING_WORDS } from '../data/themes';
import {
  fmt,
  idbDel,
  idbPut,
  makeWallpaperThumb,
  wlGetAllMeta,
  wlTx,
} from '../utils/storage';
import { MaterialSurface } from './MaterialSurface';

interface SharpWheelButtonProps {
  open: boolean;
  onClick: () => void;
}

export const SharpWheelButton: React.FC<SharpWheelButtonProps> = ({ open, onClick }) => {
  return (
    <button
      type="button"
      onClick={onClick}
      data-open={open}
      aria-label="Open sharp settings wheel"
      title="Settings Wheel"
      className="sharp-wheel-btn flex h-11 w-11 items-center justify-center rounded-full border transition active:scale-90"
      style={{
        borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
        background: 'color-mix(in srgb, var(--bg) 72%, var(--am) 12%)',
        color: 'var(--am)',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.2), 0 6px 20px rgba(0,0,0,0.5)',
      }}
    >
      {/* Razor-Sharp Machined 12-Tooth Cogwheel SVG */}
      <svg viewBox="0 0 48 48" className="h-6 w-6" aria-hidden="true">
        <path
          fill="currentColor"
          d="M22.2 2h3.6l1.3 5.2a16.5 16.5 0 0 1 3.7 1.5l4.6-2.7 2.5 2.5-2.7 4.6a16.5 16.5 0 0 1 1.5 3.7L42 18.2v3.6l-5.2 1.3a16.5 16.5 0 0 1-1.5 3.7l2.7 4.6-2.5 2.5-4.6-2.7a16.5 16.5 0 0 1-3.7 1.5L25.8 38h-3.6l-1.3-5.2a16.5 16.5 0 0 1-3.7-1.5l-4.6 2.7-2.5-2.5 2.7-4.6a16.5 16.5 0 0 1-1.5-3.7L6 21.8v-3.6l5.2-1.3a16.5 16.5 0 0 1 1.5-3.7L10 8.6l2.5-2.5 4.6 2.7a16.5 16.5 0 0 1 3.7-1.5L22.2 2Z"
          transform="translate(0, 4)"
        />
        <circle cx="24" cy="24" r="9.5" fill="var(--bg)" />
        <circle cx="24" cy="24" r="6" fill="none" stroke="currentColor" strokeWidth="1.8" />
        <circle cx="24" cy="24" r="2.2" fill="currentColor" />
      </svg>
    </button>
  );
};

type WheelSection = 'themes' | 'wallpapers' | 'weather' | 'archive';

interface SharpSettingsWheelModalProps {
  open: boolean;
  initialSection?: WheelSection;
  state: AppState;
  rainLoaded: boolean;
  thunderLoaded: boolean;
  onClose: () => void;
  onUpdateTheme: (patch: Partial<ThemeConfig>) => void;
  onResetTheme: () => void;
  onPickSingleWallpaper: (file: File) => void;
  onRemoveWallpaper: () => void;
  onApplyWallpaperId: (id: string) => void;
  onRandomWallpaper: () => void;
  onToggleLaunchShuffle: () => void;
  onPickRainAudio: (file: File) => void;
  onPickThunderAudio: (file: File) => void;
  onExportBackup: () => void;
  onImportBackup: (file: File) => void;
  onRequestPersist: () => void;
  onJumpHistory: (bookId: string, trackIndex: number, time: number) => void;
  onToast: (msg: string) => void;
}

const WHEEL_TABS: { id: WheelSection; label: string; icon: React.ReactNode; angle: number }[] = [
  { id: 'themes', label: 'DIY Themes & 3D', icon: <Palette className="h-4 w-4" />, angle: 0 },
  { id: 'wallpapers', label: '4K / 8K Vault', icon: <ImageIcon className="h-4 w-4" />, angle: 90 },
  { id: 'weather', label: 'Weather & Sound', icon: <CloudRain className="h-4 w-4" />, angle: 180 },
  { id: 'archive', label: 'Memory & Backup', icon: <History className="h-4 w-4" />, angle: 270 },
];

export const SharpSettingsWheelModal: React.FC<SharpSettingsWheelModalProps> = ({
  open,
  initialSection = 'themes',
  state,
  rainLoaded,
  thunderLoaded,
  onClose,
  onUpdateTheme,
  onResetTheme,
  onPickSingleWallpaper,
  onRemoveWallpaper,
  onApplyWallpaperId,
  onRandomWallpaper,
  onToggleLaunchShuffle,
  onPickRainAudio,
  onPickThunderAudio,
  onExportBackup,
  onImportBackup,
  onRequestPersist,
  onJumpHistory,
  onToast,
}) => {
  const [section, setSection] = useState<WheelSection>(initialSection);
  const [wallList, setWallList] = useState<WallpaperMeta[]>([]);
  const [wallThumbs, setWallThumbs] = useState<Record<string, string>>({});
  const [wallSearch, setWallSearch] = useState('');
  const [selMode, setSelMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [importProgress, setImportProgress] = useState<string | null>(null);

  const wallSingleRef = useRef<HTMLInputElement>(null);
  const wallBatchRef = useRef<HTMLInputElement>(null);
  const rainInputRef = useRef<HTMLInputElement>(null);
  const thunderInputRef = useRef<HTMLInputElement>(null);
  const backupImportRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) setSection(initialSection);
  }, [open, initialSection]);

  const loadWallVault = async () => {
    const metas = await wlGetAllMeta();
    setWallList(metas);
    const newThumbs: Record<string, string> = {};
    for (const m of metas.slice(0, 60)) {
      try {
        const blob = await wlTx<Blob | undefined>('wt', 'readonly', (t) =>
          t.objectStore('wt').get(m.id)
        );
        if (blob) newThumbs[m.id] = URL.createObjectURL(blob);
      } catch {
        // ignore missing thumb
      }
    }
    setWallThumbs((prev) => {
      Object.values(prev).forEach((u) => URL.revokeObjectURL(u));
      return newThumbs;
    });
  };

  useEffect(() => {
    if (open && section === 'wallpapers') {
      loadWallVault();
    }
  }, [open, section]);

  useEffect(() => {
    return () => {
      Object.values(wallThumbs).forEach((u) => URL.revokeObjectURL(u));
    };
  }, []);

  if (!open) return null;

  const T = state.theme;
  const words = SETTING_WORDS[T.sk] || SETTING_WORDS.cave;
  const activeTab = WHEEL_TABS.find((t) => t.id === section) || WHEEL_TABS[0];

  const handleBatchWallImport = async (files: FileList) => {
    const arr = Array.from(files).filter(
      (f) =>
        /^(image|video)\//.test(f.type) ||
        /\.(gif|webp|avif|png|jpe?g|bmp|mp4|webm|mkv|mov)$/i.test(f.name)
    );
    if (!arr.length) return onToast('No images, GIFs, or videos selected');
    const existingIds = new Set(wallList.map((m) => m.id));
    let added = 0;
    for (let idx = 0; idx < arr.length; idx++) {
      const f = arr[idx];
      const id = `${f.name}|${f.size}|${f.lastModified || 0}`;
      setImportProgress(`Importing ${idx + 1} / ${arr.length}…`);
      if (!existingIds.has(id)) {
        try {
          const th = await makeWallpaperThumb(f);
          const meta: WallpaperMeta = {
            id,
            name: f.name,
            type: f.type || '',
            size: f.size,
            ts: Date.now() + idx,
          };
          await wlTx(['w', 'wt', 'wm'], 'readwrite', (t) => {
            t.objectStore('w').put(f, id);
            if (th) t.objectStore('wt').put(th, id);
            t.objectStore('wm').put(meta, id);
          });
          added++;
          if (added === 1) {
            await idbPut('f', 'wall', f);
          }
        } catch {
          onToast('Storage limit reached while importing');
          break;
        }
      }
    }
    setImportProgress(null);
    await loadWallVault();
    onToast(`Added ${added} wallpaper${added === 1 ? '' : 's'} to vault`);
  };

  const handleDeleteSelectedWalls = async () => {
    const ids = Array.from(selectedIds);
    if (!ids.length) return;
    await wlTx(['w', 'wt', 'wm'], 'readwrite', (t) => {
      ids.forEach((id) => {
        t.objectStore('w').delete(id);
        t.objectStore('wt').delete(id);
        t.objectStore('wm').delete(id);
      });
    });
    if (state.wcur && selectedIds.has(state.wcur)) {
      await idbDel('f', 'wall');
      onRemoveWallpaper();
    }
    setSelectedIds(new Set());
    setSelMode(false);
    await loadWallVault();
    onToast(`Removed ${ids.length} wallpaper${ids.length === 1 ? '' : 's'}`);
  };

  const filteredWalls = wallSearch.trim()
    ? wallList.filter((m) => m.name.toLowerCase().includes(wallSearch.trim().toLowerCase()))
    : wallList;

  const MATERIALS: { id: MaterialType; label: string; desc: string }[] = [
    { id: 'metal', label: 'Brushed Metal', desc: 'Anisotropic machined steel & bevel sheen' },
    { id: 'glass', label: 'Crystal Glass', desc: 'Optical frosted refraction & edge rim' },
    { id: 'wood', label: 'Wood Grain', desc: 'Carved walnut rings & satin lacquer' },
    { id: 'obsidian', label: 'Obsidian Matte', desc: 'Forged dark stone & soft contour' },
  ];

  return (
    <div
      role="dialog"
      aria-label="Sharp Settings Wheel Hub"
      className="fixed inset-0 z-50 flex flex-col bg-black/75 backdrop-blur-xl"
    >
      {/* Top Bar with Sharp Rotating Wheel Dial */}
      <div className="mx-auto w-full max-w-5xl px-4 pt-[calc(env(safe-area-inset-top)+12px)] pb-3">
        <MaterialSurface
          material={T.material}
          anim3d={T.anim3d}
          depth3d={T.depth3d}
          tiltMax={3}
          className="rounded-3xl p-4"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {/* Rotating Sharp Wheel Emblem */}
              <div
                className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border transition-transform duration-500"
                style={{
                  borderColor: 'var(--am)',
                  color: 'var(--am)',
                  transform: `rotate(${activeTab.angle}deg)`,
                  background: 'color-mix(in srgb, var(--bg) 75%, var(--am) 12%)',
                }}
              >
                <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M22.2 2h3.6l1.3 5.2a16.5 16.5 0 0 1 3.7 1.5l4.6-2.7 2.5 2.5-2.7 4.6a16.5 16.5 0 0 1 1.5 3.7L42 18.2v3.6l-5.2 1.3a16.5 16.5 0 0 1-1.5 3.7l2.7 4.6-2.5 2.5-4.6-2.7a16.5 16.5 0 0 1-3.7 1.5L25.8 38h-3.6l-1.3-5.2a16.5 16.5 0 0 1-3.7-1.5l-4.6 2.7-2.5-2.5 2.7-4.6a16.5 16.5 0 0 1-1.5-3.7L6 21.8v-3.6l5.2-1.3a16.5 16.5 0 0 1 1.5-3.7L10 8.6l2.5-2.5 4.6 2.7a16.5 16.5 0 0 1 3.7-1.5L22.2 2Z"
                    transform="translate(0, 4)"
                  />
                  <circle cx="24" cy="24" r="9" fill="var(--bg)" />
                  <circle cx="24" cy="24" r="3" fill="currentColor" />
                </svg>
              </div>
              <div className="min-w-0">
                <div
                  className="truncate text-xs font-bold tracking-[0.18em] uppercase"
                  style={{ color: 'var(--am)' }}
                >
                  {words.title}
                </div>
                <div className="text-xs opacity-70">Sharp Settings Wheel · All Controls</div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {section === 'themes' && (
                <button
                  type="button"
                  onClick={onResetTheme}
                  className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-white/10 hover:bg-white/15 px-3 py-1.5 text-xs font-semibold transition"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset</span>
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                aria-label="Close settings wheel"
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* 4-Spoke Gear Wheel Selector */}
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
            {WHEEL_TABS.map((tab) => {
              const active = section === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSection(tab.id)}
                  className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs font-bold transition active:scale-95"
                  style={{
                    background: active ? 'var(--am)' : 'rgba(255,255,255,0.06)',
                    color: active ? 'var(--bg)' : 'var(--fg)',
                  }}
                >
                  {tab.icon}
                  <span className="whitespace-nowrap">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Quick Master Ambience Intensity Slider (Volume + Visual Density) */}
          <div className="mt-3 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 rounded-2xl bg-black/30 border border-white/10 px-3.5 py-2.5">
            <div className="flex items-center gap-2 shrink-0">
              <CloudRain className="h-4 w-4" style={{ color: 'var(--am)' }} />
              <span className="text-xs font-bold tracking-wide">Ambience Intensity</span>
              <span className="text-[11px] opacity-65 hidden md:inline">(Rain/Storm Density &amp; Audio Volume)</span>
            </div>
            <div className="flex flex-1 items-center gap-3">
              <input
                type="range"
                aria-label="Ambience Intensity"
                min={0}
                max={1}
                step={0.02}
                value={Math.round(((T.fxI + T.vol) / 2) * 100) / 100}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  onUpdateTheme({
                    fxI: val,
                    vol: val,
                    ...(val > 0 && !T.fx ? { fx: 'rain' } : {}),
                    ...(val > 0 && !T.snd ? { snd: true } : {}),
                    ...(val === 0 ? { snd: false } : {}),
                  });
                }}
                className="cave-slider flex-1"
              />
              <span className="tabular-nums text-xs font-bold w-11 text-right" style={{ color: 'var(--am)' }}>
                {Math.round(((T.fxI + T.vol) / 2) * 100)}%
              </span>
            </div>
          </div>
        </MaterialSurface>
      </div>

      {/* Scrollable Content */}
      <div className="mx-auto w-full max-w-5xl flex-1 overflow-y-auto px-4 pb-[calc(24px+env(safe-area-inset-bottom))] space-y-5">
        {/* SECTION 1: DIY THEMES & HYPER-REALISTIC 3D MATERIALS */}
        {section === 'themes' && (
          <div className="space-y-5">
            {/* Hyper-Realistic Material Textures */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5">
              <div className="flex items-center gap-2 mb-3">
                <Layers className="h-4 w-4" style={{ color: 'var(--am)' }} />
                <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
                  Hyper-Realistic Surface Material &amp; 3D Animation
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {MATERIALS.map((m) => {
                  const active = T.material === m.id;
                  return (
                    <MaterialSurface
                      key={m.id}
                      material={m.id}
                      anim3d={T.anim3d}
                      depth3d={T.depth3d}
                      tiltMax={8}
                      onClick={() => onUpdateTheme({ material: m.id })}
                      className="cursor-pointer rounded-2xl p-3.5 text-left transition"
                      style={{
                        outline: active ? '2px solid var(--am)' : 'none',
                        outlineOffset: '-2px',
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold">{m.label}</span>
                        {active && <Check className="h-4 w-4" style={{ color: 'var(--am)' }} />}
                      </div>
                      <p className="mt-1 text-[11px] opacity-75">{m.desc}</p>
                    </MaterialSurface>
                  );
                })}
              </div>

              {/* 3D Animation & Specular Sliders */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-white/10">
                <label className="flex items-center justify-between gap-3 text-xs font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                    3D Tilt &amp; Spin Animation
                  </span>
                  <input
                    type="checkbox"
                    checked={T.anim3d}
                    onChange={(e) => onUpdateTheme({ anim3d: e.target.checked })}
                    className="h-5 w-5 accent-amber-400"
                  />
                </label>
                <label className="flex flex-col gap-1 text-xs font-semibold">
                  <div className="flex justify-between">
                    <span>3D Perspective Depth</span>
                    <span className="tabular-nums opacity-75">{Math.round(T.depth3d * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={T.depth3d}
                    onChange={(e) => onUpdateTheme({ depth3d: Number(e.target.value) })}
                    className="cave-slider"
                  />
                </label>
                <label className="flex flex-col gap-1 text-xs font-semibold">
                  <div className="flex justify-between">
                    <span>Surface Specular Sheen</span>
                    <span className="tabular-nums opacity-75">{Math.round(T.sheen * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={1}
                    step={0.05}
                    value={T.sheen}
                    onChange={(e) => onUpdateTheme({ sheen: Number(e.target.value) })}
                    className="cave-slider"
                  />
                </label>
              </div>
            </MaterialSurface>

            {/* All 23 Color Worlds */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5">
              <h3 className="text-xs font-bold tracking-[0.16em] uppercase mb-3" style={{ color: 'var(--am)' }}>
                All {PRESETS.length} Hyper-Realistic Color Worlds &amp; Cinematic Realms
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-[340px] overflow-y-auto pr-1">
                {PRESETS.map((p) => {
                  const active = T.pre === p.key;
                  return (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() =>
                        onUpdateTheme({
                          pre: p.key,
                          sk: p.key,
                          nm: p.nm,
                          lg: p.lg,
                          bg: p.bg,
                          am: p.am,
                          fg: p.fg,
                          ft: p.ft,
                          fx: p.fx,
                          fxI: p.fxI,
                          sc: p.sc,
                          dim: p.dim,
                          blur: p.blur,
                          material: p.material,
                        })
                      }
                      className="flex items-center gap-3 rounded-xl border p-2.5 text-left transition active:scale-98"
                      style={{
                        background: p.bg,
                        color: p.fg,
                        borderColor: active ? p.am : 'rgba(255,255,255,0.12)',
                        boxShadow: active ? `0 0 18px ${p.am}44` : undefined,
                      }}
                    >
                      <span
                        className="h-7 w-7 rounded-lg shrink-0 border border-white/20"
                        style={{ background: p.am }}
                      />
                      <span className="min-w-0 flex-1 truncate text-xs font-bold">{p.label}</span>
                      {active && <Check className="h-4 w-4 shrink-0" style={{ color: p.am }} />}
                    </button>
                  );
                })}
              </div>

              {/* Custom Color Pickers */}
              <div className="mt-4 grid grid-cols-3 gap-3 pt-4 border-t border-white/10">
                <label className="flex flex-col gap-1.5 text-xs font-semibold">
                  <span>Accent</span>
                  <input
                    type="color"
                    value={T.am}
                    onChange={(e) => onUpdateTheme({ am: e.target.value, pre: 'custom' })}
                    className="h-11 w-full cursor-pointer rounded-xl border border-white/20 bg-transparent"
                  />
                </label>
                <label className="flex flex-col gap-1.5 text-xs font-semibold">
                  <span>Background</span>
                  <input
                    type="color"
                    value={T.bg}
                    onChange={(e) => onUpdateTheme({ bg: e.target.value, pre: 'custom' })}
                    className="h-11 w-full cursor-pointer rounded-xl border border-white/20 bg-transparent"
                  />
                </label>
                <label className="flex flex-col gap-1.5 text-xs font-semibold">
                  <span>Text</span>
                  <input
                    type="color"
                    value={T.fg}
                    onChange={(e) => onUpdateTheme({ fg: e.target.value, pre: 'custom' })}
                    className="h-11 w-full cursor-pointer rounded-xl border border-white/20 bg-transparent"
                  />
                </label>
              </div>
            </MaterialSurface>

            {/* Identity, Font, Logo & Silhouette */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <span>Player Name</span>
                <input
                  type="text"
                  maxLength={40}
                  value={T.nm}
                  onChange={(e) => onUpdateTheme({ nm: e.target.value, pre: 'custom' })}
                  className="rounded-xl bg-black/35 px-3 py-2.5 text-sm outline-none border border-white/15"
                />
              </label>
              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <span>Crest Logo</span>
                <select
                  value={T.lg}
                  onChange={(e) => onUpdateTheme({ lg: e.target.value as LogoKey, pre: 'custom' })}
                  className="rounded-xl bg-black/35 px-3 py-2.5 text-sm outline-none border border-white/15"
                >
                  <option value="">None</option>
                  <option value="cave">Cave Arch</option>
                  <option value="dark">Moon &amp; Sword</option>
                  <option value="wiz">Magic Castle Crest</option>
                  <option value="storm">Storm Cloud</option>
                  <option value="rain">Rain Cloud</option>
                </select>
              </label>
              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <span>Typography</span>
                <select
                  value={T.ft}
                  onChange={(e) => onUpdateTheme({ ft: e.target.value as ThemeFontKey, pre: 'custom' })}
                  className="rounded-xl bg-black/35 px-3 py-2.5 text-sm outline-none border border-white/15"
                >
                  <option value="serif">Serif (Georgia)</option>
                  <option value="classic">Classic (Palatino)</option>
                  <option value="fantasy">Fantasy Display</option>
                  <option value="sans">Clean Sans</option>
                  <option value="mono">Monospace</option>
                </select>
              </label>
              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <span>Horizon Silhouette</span>
                <select
                  value={T.sc}
                  onChange={(e) => onUpdateTheme({ sc: e.target.value as SilhouetteType, pre: 'custom' })}
                  className="rounded-xl bg-black/35 px-3 py-2.5 text-sm outline-none border border-white/15"
                >
                  <option value="">None</option>
                  <option value="castle">Castle Towers</option>
                  <option value="peaks">Dark Peaks</option>
                </select>
              </label>
            </MaterialSurface>
          </div>
        )}

        {/* SECTION 2: 4K / 8K WALLPAPERS & GIF VAULT */}
        {section === 'wallpapers' && (
          <div className="space-y-4">
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
                    4K / 8K Wallpaper &amp; GIF Controls
                  </h3>
                  <p className="text-xs opacity-70">
                    Load high-res images, animated GIFs, WebP, or looping videos right into the player
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => wallSingleRef.current?.click()}
                    className="min-h-[40px] rounded-xl px-3.5 py-2 text-xs font-bold"
                    style={{ background: 'var(--am)', color: 'var(--bg)' }}
                  >
                    Set Active Wallpaper / GIF
                  </button>
                  <button
                    type="button"
                    onClick={onRemoveWallpaper}
                    className="min-h-[40px] rounded-xl bg-white/10 hover:bg-white/15 px-3.5 py-2 text-xs font-semibold"
                  >
                    Clear Active
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-white/10">
                <label className="flex flex-col gap-1 text-xs font-semibold">
                  <span>Display Location</span>
                  <select
                    value={T.wallSpotMode}
                    onChange={(e) =>
                      onUpdateTheme({ wallSpotMode: e.target.value as ThemeConfig['wallSpotMode'] })
                    }
                    className="rounded-xl bg-black/35 px-3 py-2 text-xs outline-none border border-white/15"
                  >
                    <option value="both">Player Spot + Full Backdrop</option>
                    <option value="player">Player Spot Only (Sharp)</option>
                    <option value="backdrop">Full Backdrop Only</option>
                  </select>
                </label>
                <label className="flex flex-col gap-1 text-xs font-semibold">
                  <span>Player Frame Fit</span>
                  <select
                    value={T.wallFit}
                    onChange={(e) =>
                      onUpdateTheme({ wallFit: e.target.value as ThemeConfig['wallFit'] })
                    }
                    className="rounded-xl bg-black/35 px-3 py-2 text-xs outline-none border border-white/15"
                  >
                    <option value="cover">Fill Frame (Cover)</option>
                    <option value="contain">Show Full Art (Contain)</option>
                  </select>
                </label>
                <label className="flex flex-col gap-1 text-xs font-semibold">
                  <div className="flex justify-between">
                    <span>Backdrop Dim</span>
                    <span className="tabular-nums opacity-70">{Math.round(T.dim * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.95}
                    step={0.05}
                    value={T.dim}
                    onChange={(e) => onUpdateTheme({ dim: Number(e.target.value) })}
                    className="cave-slider"
                  />
                </label>
                <label className="flex flex-col gap-1 text-xs font-semibold">
                  <div className="flex justify-between">
                    <span>Backdrop Blur</span>
                    <span className="tabular-nums opacity-70">{T.blur}px</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={20}
                    step={1}
                    value={T.blur}
                    onChange={(e) => onUpdateTheme({ blur: Number(e.target.value) })}
                    className="cave-slider"
                  />
                </label>
              </div>
            </MaterialSurface>

            {/* Vault Library */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs font-bold tracking-wider uppercase" style={{ color: 'var(--am)' }}>
                  Saved Vault ({wallList.length})
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => wallBatchRef.current?.click()}
                    className="min-h-[38px] rounded-xl px-3 py-1.5 text-xs font-bold"
                    style={{ background: 'var(--am)', color: 'var(--bg)' }}
                  >
                    + Add Many to Vault
                  </button>
                  <button
                    type="button"
                    onClick={onRandomWallpaper}
                    className="min-h-[38px] flex items-center gap-1 rounded-xl bg-white/10 px-3 py-1.5 text-xs font-semibold"
                  >
                    <Shuffle className="h-3.5 w-3.5" />
                    <span>Random</span>
                  </button>
                  <button
                    type="button"
                    onClick={onToggleLaunchShuffle}
                    className="min-h-[38px] rounded-xl bg-white/10 px-3 py-1.5 text-xs font-semibold"
                    style={{ color: state.wshuf ? 'var(--am)' : 'var(--fg)' }}
                  >
                    Launch Shuffle: {state.wshuf ? 'ON' : 'OFF'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelMode((s) => !s);
                      setSelectedIds(new Set());
                    }}
                    className="min-h-[38px] rounded-xl bg-white/10 px-3 py-1.5 text-xs font-semibold"
                  >
                    {selMode ? 'Cancel Select' : 'Select'}
                  </button>
                </div>
              </div>

              {importProgress && (
                <div className="rounded-xl bg-black/40 px-3 py-2 text-xs font-semibold" style={{ color: 'var(--am)' }}>
                  {importProgress}
                </div>
              )}

              <input
                type="text"
                value={wallSearch}
                onChange={(e) => setWallSearch(e.target.value)}
                placeholder="Filter wallpapers by filename…"
                className="w-full rounded-xl bg-black/35 px-3 py-2 text-xs outline-none border border-white/15"
              />

              {selMode && selectedIds.size > 0 && (
                <div className="flex items-center justify-between rounded-xl bg-red-950/50 border border-red-500/40 px-3 py-2">
                  <span className="text-xs font-semibold">{selectedIds.size} selected</span>
                  <button
                    type="button"
                    onClick={handleDeleteSelectedWalls}
                    className="flex items-center gap-1 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-bold text-white"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete Selected</span>
                  </button>
                </div>
              )}

              {filteredWalls.length ? (
                <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-2 max-h-80 overflow-y-auto pr-1">
                  {filteredWalls.map((m) => {
                    const isCur = state.wcur === m.id;
                    const isSel = selectedIds.has(m.id);
                    const thumb = wallThumbs[m.id];
                    const isGif = /gif/i.test(m.type) || /\.gif$/i.test(m.name);
                    const isVid = m.type.startsWith('video');
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          if (selMode) {
                            setSelectedIds((prev) => {
                              const next = new Set(prev);
                              if (next.has(m.id)) next.delete(m.id);
                              else next.add(m.id);
                              return next;
                            });
                          } else {
                            onApplyWallpaperId(m.id);
                          }
                        }}
                        className="relative aspect-[9/14] overflow-hidden rounded-xl bg-black/50 border transition"
                        style={{
                          borderColor: isCur ? 'var(--am)' : 'rgba(255,255,255,0.12)',
                          boxShadow: isCur ? '0 0 0 2px var(--am)' : undefined,
                        }}
                      >
                        {thumb ? (
                          <img
                            src={thumb}
                            alt={m.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <span className="text-xl">{isVid ? '🎞' : '🖼'}</span>
                        )}
                        {(isGif || isVid) && (
                          <span className="absolute left-1.5 bottom-1 rounded bg-black/70 px-1.5 py-0.5 text-[9px] font-bold text-white">
                            {isVid ? 'VIDEO' : 'GIF'}
                          </span>
                        )}
                        {isSel && (
                          <span className="absolute inset-0 flex items-center justify-center bg-amber-500/45 text-white font-bold">
                            <Check className="h-6 w-6" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="py-8 text-center text-xs opacity-70">
                  No saved wallpapers in vault yet. Add single or batch 4K/8K images, GIFs, or videos!
                </div>
              )}
            </MaterialSurface>

            <input
              ref={wallSingleRef}
              type="file"
              accept="image/*,video/*,.gif,.webp,.avif,.mp4,.webm,.mkv,.mov"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (f) onPickSingleWallpaper(f);
              }}
            />
            <input
              ref={wallBatchRef}
              type="file"
              multiple
              accept="image/*,video/*,.gif,.webp,.avif,.mp4,.webm,.mkv,.mov"
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.length) handleBatchWallImport(e.target.files);
                e.target.value = '';
              }}
            />
          </div>
        )}

        {/* SECTION 3: WEATHER & REAL AMBIENCE */}
        {section === 'weather' && (
          <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 space-y-4">
            <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
              3D Atmospheric Weather &amp; Ambience
            </h3>

            {/* Unified Ambience Intensity Control */}
            <div className="rounded-2xl bg-black/30 border border-white/10 p-4 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-bold" style={{ color: 'var(--am)' }}>
                    Ambience Intensity
                  </div>
                  <div className="text-[11px] opacity-70">
                    Controls both rain/storm audio volume and visual particle density together
                  </div>
                </div>
                <span className="tabular-nums text-base font-bold" style={{ color: 'var(--am)' }}>
                  {Math.round(((T.fxI + T.vol) / 2) * 100)}%
                </span>
              </div>
              <input
                type="range"
                aria-label="Master Ambience Intensity"
                min={0}
                max={1}
                step={0.02}
                value={Math.round(((T.fxI + T.vol) / 2) * 100) / 100}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  onUpdateTheme({
                    fxI: val,
                    vol: val,
                    ...(val > 0 && !T.fx ? { fx: 'rain' } : {}),
                    ...(val > 0 && !T.snd ? { snd: true } : {}),
                    ...(val === 0 ? { snd: false } : {}),
                  });
                }}
                className="cave-slider w-full"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <span>Weather Effect</span>
                <select
                  value={T.fx}
                  onChange={(e) => onUpdateTheme({ fx: e.target.value as WeatherEffect })}
                  className="rounded-xl bg-black/35 px-3 py-2.5 text-sm outline-none border border-white/15"
                >
                  <option value="">None</option>
                  <option value="rain">Rain</option>
                  <option value="storm">Storm + Lightning</option>
                  <option value="snow">Christmas Snowfall</option>
                  <option value="embers">Dark Embers</option>
                  <option value="magic">Floating Candles &amp; Sparks</option>
                </select>
              </label>

              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <div className="flex justify-between">
                  <span>Visual Particle Density</span>
                  <span className="tabular-nums opacity-75">{Math.round(T.fxI * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={T.fxI}
                  onChange={(e) => onUpdateTheme({ fxI: Number(e.target.value) })}
                  className="cave-slider mt-2"
                />
              </label>

              <label className="flex items-center justify-between gap-3 rounded-xl bg-black/25 px-3.5 py-3 text-xs font-semibold">
                <span>Enable Ambient Rain &amp; Thunder Audio</span>
                <input
                  type="checkbox"
                  checked={T.snd}
                  onChange={(e) => onUpdateTheme({ snd: e.target.checked })}
                  className="h-5 w-5 accent-amber-400"
                />
              </label>

              <label className="flex items-center justify-between gap-3 rounded-xl bg-black/25 px-3.5 py-3 text-xs font-semibold">
                <span>Rain in Background When Reading PDFs</span>
                <input
                  type="checkbox"
                  checked={T.rainOnRead !== false}
                  onChange={(e) => onUpdateTheme({ rainOnRead: e.target.checked })}
                  className="h-5 w-5 accent-amber-400"
                />
              </label>

              <label className="flex flex-col gap-1.5 text-xs font-semibold">
                <div className="flex justify-between">
                  <span>Ambient Sound Volume</span>
                  <span className="tabular-nums opacity-75">{Math.round(T.vol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={T.vol}
                  onChange={(e) => onUpdateTheme({ vol: Number(e.target.value) })}
                  className="cave-slider"
                />
              </label>
            </div>

            <div className="pt-3 border-t border-white/10 space-y-2.5">
              <div className="text-xs font-semibold opacity-80">
                Real Rain &amp; Thunder Recordings (stored locally in device IndexedDB)
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => rainInputRef.current?.click()}
                  className="min-h-[40px] rounded-xl px-4 py-2 text-xs font-bold"
                  style={{ background: 'var(--am)', color: 'var(--bg)' }}
                >
                  {rainLoaded ? 'Replace Rain Audio' : 'Choose Rain Recording'}
                </button>
                <button
                  type="button"
                  onClick={() => thunderInputRef.current?.click()}
                  className="min-h-[40px] rounded-xl bg-white/10 hover:bg-white/15 px-4 py-2 text-xs font-semibold"
                >
                  {thunderLoaded ? 'Replace Thunder Audio' : 'Choose Thunder Recording'}
                </button>
              </div>
              <p className="text-[11px] opacity-65">
                {rainLoaded ? 'Rain recording loaded' : 'Rain recording not set'} ·{' '}
                {thunderLoaded ? 'Thunder recording loaded' : 'Using synthesized thunder fallback'}
              </p>
            </div>

            <input
              ref={rainInputRef}
              type="file"
              accept="audio/*,.mp3,.wav,.ogg,.m4a,.flac"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (f) onPickRainAudio(f);
              }}
            />
            <input
              ref={thunderInputRef}
              type="file"
              accept="audio/*,.mp3,.wav,.ogg,.m4a,.flac"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (f) onPickThunderAudio(f);
              }}
            />
          </MaterialSurface>
        )}

        {/* SECTION 4: ARCHIVE, MEMORY TIMELINE, BACKUP & GESTURE GUIDE */}
        {section === 'archive' && (
          <div className="space-y-4">
            {/* GitHub Ready ZIP Packages: PC Version & Android Version */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 space-y-3">
              <div>
                <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
                  BILLS CAVE · GitHub App Packages (PC &amp; Android)
                </h3>
                <p className="mt-1 text-xs opacity-75">
                  Download ready-to-push GitHub repositories with the BILLS CAVE icon cover, workflows, and native wrappers.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href="/downloads/BILLS-CAVE-PC-GitHub.zip"
                  download="BILLS-CAVE-PC-GitHub.zip"
                  className="flex items-center gap-3 rounded-2xl border p-3.5 transition hover:bg-white/10 active:scale-98"
                  style={{
                    borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
                    background: 'color-mix(in srgb, var(--bg) 70%, var(--am) 12%)',
                  }}
                >
                  <div
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                    style={{ background: 'var(--am)', color: 'var(--bg)' }}
                  >
                    <Monitor className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-bold">PC Version (.zip)</div>
                    <div className="text-[11px] opacity-75 truncate">
                      Electron Desktop + GitHub Actions
                    </div>
                  </div>
                  <Download className="h-4 w-4 shrink-0" style={{ color: 'var(--am)' }} />
                </a>

                <a
                  href="/downloads/BILLS-CAVE-Android-GitHub.zip"
                  download="BILLS-CAVE-Android-GitHub.zip"
                  className="flex items-center gap-3 rounded-2xl border p-3.5 transition hover:bg-white/10 active:scale-98"
                  style={{
                    borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
                    background: 'color-mix(in srgb, var(--bg) 70%, var(--am) 12%)',
                  }}
                >
                  <div
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                    style={{ background: 'var(--am)', color: 'var(--bg)' }}
                  >
                    <Smartphone className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-bold">Android Version (.zip)</div>
                    <div className="text-[11px] opacity-75 truncate">
                      Capacitor APK + GitHub Actions
                    </div>
                  </div>
                  <Download className="h-4 w-4 shrink-0" style={{ color: 'var(--am)' }} />
                </a>
              </div>
            </MaterialSurface>

            {/* Gesture Navigation Guide */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5">
              <div className="flex items-center gap-2 mb-3">
                <Hand className="h-4 w-4" style={{ color: 'var(--am)' }} />
                <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
                  Finger Gesture Navigation Guide
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                <div className="rounded-xl bg-black/25 p-3">
                  <div className="font-bold">Swipe Left / Right</div>
                  <div className="opacity-70 mt-0.5">
                    Glide between Audiobooks, PDFs, and Open Links without bottom buttons
                  </div>
                </div>
                <div className="rounded-xl bg-black/25 p-3">
                  <div className="font-bold">Swipe Up on Player Dock</div>
                  <div className="opacity-70 mt-0.5">
                    Expand the full 3D Now Playing &amp; 4K/8K Wallpaper Stage
                  </div>
                </div>
                <div className="rounded-xl bg-black/25 p-3">
                  <div className="font-bold">Swipe Down on Full Stage</div>
                  <div className="opacity-70 mt-0.5">Collapse smoothly back to your active room</div>
                </div>
                <div className="rounded-xl bg-black/25 p-3">
                  <div className="font-bold">Two-Finger Tap</div>
                  <div className="opacity-70 mt-0.5">Quick-summon this Sharp Settings Wheel</div>
                </div>
              </div>
            </MaterialSurface>

            {/* Backup & Persistent Storage */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 space-y-3">
              <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
                Backup &amp; Device Storage
              </h3>
              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={onExportBackup}
                  className="min-h-[42px] flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold"
                  style={{ background: 'var(--am)', color: 'var(--bg)' }}
                >
                  <Download className="h-4 w-4" />
                  <span>{words.export}</span>
                </button>
                <button
                  type="button"
                  onClick={() => backupImportRef.current?.click()}
                  className="min-h-[42px] flex items-center gap-2 rounded-xl bg-white/10 hover:bg-white/15 px-4 py-2 text-xs font-semibold"
                >
                  <Upload className="h-4 w-4" />
                  <span>{words.import}</span>
                </button>
                <button
                  type="button"
                  onClick={onRequestPersist}
                  className="min-h-[42px] flex items-center gap-2 rounded-xl bg-white/10 hover:bg-white/15 px-4 py-2 text-xs font-semibold"
                >
                  <Shield className="h-4 w-4" />
                  <span>{words.keep}</span>
                </button>
              </div>
              <input
                ref={backupImportRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  e.target.value = '';
                  if (f) onImportBackup(f);
                }}
              />
            </MaterialSurface>

            {/* Listening Memory Timeline */}
            <MaterialSurface material={T.material} anim3d={false} className="rounded-3xl p-4 sm:p-5 space-y-2.5">
              <h3 className="text-xs font-bold tracking-[0.16em] uppercase" style={{ color: 'var(--am)' }}>
                Listening Memory Timeline ({state.hist.length})
              </h3>
              {state.hist.length ? (
                <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
                  {[...state.hist].reverse().map((h, idx) => (
                    <button
                      key={`${h.id}-${h.ts}-${idx}`}
                      type="button"
                      onClick={() => {
                        onJumpHistory(h.id, h.i, h.to);
                        onClose();
                      }}
                      className="flex w-full items-center justify-between gap-3 rounded-xl bg-black/25 hover:bg-black/40 p-3 text-left transition"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-bold">{h.title}</div>
                        <div className="text-[11px] opacity-65">
                          {new Date(h.ts).toLocaleString([], {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })}
                        </div>
                      </div>
                      <div className="tabular-nums text-xs font-semibold shrink-0" style={{ color: 'var(--am)' }}>
                        {fmt(h.from)} → {fmt(h.to)}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-xs opacity-70">
                  No listening history recorded yet. Every listening session is logged automatically.
                </p>
              )}
            </MaterialSurface>
          </div>
        )}
      </div>
    </div>
  );
};
