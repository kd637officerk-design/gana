import React, { useRef, useState } from 'react';
import {
  Bookmark,
  ChevronDown,
  Clock,
  Disc3,
  ImagePlus,
  Library,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  RotateCw,
  Shuffle,
  SkipBack,
  SkipForward,
  SlidersHorizontal,
  Trash2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Book, MaterialType, ThemeConfig } from '../types';
import { fmt } from '../utils/storage';
import { MaterialSurface } from './MaterialSurface';

interface NowPlayingStageProps {
  open: boolean;
  book: Book | null;
  trackIndex: number;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  theme: ThemeConfig;
  wallUrl: string | null;
  wallIsVideo: boolean;
  wallName?: string;
  bookIcon: string;
  onClose: () => void;
  onTogglePlay: () => void;
  onPrev: () => void;
  onNext: () => void;
  onSkipBack30: () => void;
  onSkipFwd30: () => void;
  onSeek: (t: number) => void;
  onVolumeChange: (v: number) => void;
  onToggleMute: () => void;
  onBookmark: () => void;
  onSpeedSleep: () => void;
  onJumpTime: () => void;
  onPickWallpaper: (file: File) => void;
  onOpenWallLibrary: () => void;
  onRandomWallpaper: () => void;
  onRemoveWallpaper: () => void;
  onToggleWallFit: () => void;
}

export const NowPlayingStage: React.FC<NowPlayingStageProps> = ({
  open,
  book,
  trackIndex,
  isPlaying,
  currentTime,
  duration,
  volume,
  muted,
  theme,
  wallUrl,
  wallIsVideo,
  wallName,
  bookIcon,
  onClose,
  onTogglePlay,
  onPrev,
  onNext,
  onSkipBack30,
  onSkipFwd30,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onBookmark,
  onSpeedSleep,
  onJumpTime,
  onPickWallpaper,
  onOpenWallLibrary,
  onRandomWallpaper,
  onRemoveWallpaper,
  onToggleWallFit,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const swipeStartY = useRef<number | null>(null);
  const [dragOver, setDragOver] = useState(false);

  if (!open) return null;

  const safeDur = duration > 0 ? duration : 1;
  const pct = Math.min(100, Math.max(0, (currentTime / safeDur) * 100));
  const mat: MaterialType = theme.material;

  return (
    <section
      aria-label="Full 3D Media Player and 4K/8K Wallpaper Stage"
      className="fixed inset-0 z-40 flex flex-col overflow-y-auto px-4 pt-[calc(env(safe-area-inset-top)+12px)] pb-[calc(env(safe-area-inset-bottom)+18px)] backdrop-blur-xl"
      style={{
        background: 'color-mix(in srgb, var(--bg) 78%, transparent)',
      }}
      onTouchStart={(e) => {
        swipeStartY.current = e.touches[0].clientY;
      }}
      onTouchEnd={(e) => {
        if (swipeStartY.current === null) return;
        const dy = e.changedTouches[0].clientY - swipeStartY.current;
        swipeStartY.current = null;
        if (dy > 95) onClose();
      }}
    >
      {/* Top Bar */}
      <div className="mx-auto flex w-full max-w-4xl items-center justify-between gap-3 pb-3">
        <button
          type="button"
          onClick={onClose}
          aria-label="Minimize player"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-white/5 hover:bg-white/10 transition"
          style={{ color: 'var(--am)' }}
        >
          <ChevronDown className="h-6 w-6" />
        </button>
        <div className="text-center">
          <div className="text-[11px] font-semibold tracking-[0.2em] uppercase opacity-70">
            Now Playing · 3D Stage
          </div>
          <div className="text-xs opacity-60">Swipe down to return</div>
        </div>
        <button
          type="button"
          onClick={onOpenWallLibrary}
          aria-label="Open wallpaper library"
          className="flex h-11 items-center gap-1.5 rounded-full border px-3.5 text-xs font-semibold hover:bg-white/10 transition"
          style={{
            borderColor: 'color-mix(in srgb, var(--am) 35%, transparent)',
            color: 'var(--am)',
          }}
        >
          <Library className="h-4 w-4" />
          <span className="hidden sm:inline">Wallpaper Vault</span>
        </button>
      </div>

      {/* Main 2-column 3D Layout: Left = 4K/8K Wallpaper & GIF Spot, Right = Media Deck & Controls */}
      <div className="mx-auto my-auto grid w-full max-w-5xl grid-cols-1 gap-6 lg:grid-cols-12 items-stretch">
        {/* DEDICATED 4K / 8K WALLPAPER & GIF SPOT IN THE PLAYER */}
        <div className="lg:col-span-7 flex flex-col">
          <MaterialSurface
            material={mat}
            anim3d={theme.anim3d}
            depth3d={theme.depth3d}
            tiltMax={8}
            className={`relative flex-1 min-h-[260px] sm:min-h-[360px] rounded-3xl overflow-hidden flex flex-col justify-between p-4 ${
              dragOver ? 'ring-2 ring-amber-400' : ''
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const f = e.dataTransfer.files?.[0];
              if (f) onPickWallpaper(f);
            }}
          >
            {/* Actual Crisp 4K / 8K Wallpaper / GIF / Video Display */}
            {wallUrl ? (
              <div className="absolute inset-0 z-0 overflow-hidden rounded-3xl bg-black/50">
                {wallIsVideo ? (
                  <video
                    src={wallUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className={`h-full w-full hq-media ${
                      theme.wallFit === 'contain' ? 'object-contain' : 'object-cover'
                    }`}
                  />
                ) : (
                  <img
                    src={wallUrl}
                    alt={wallName || '4K / 8K Player Wallpaper'}
                    referrerPolicy="no-referrer"
                    className={`h-full w-full hq-media ${
                      theme.wallFit === 'contain' ? 'object-contain' : 'object-cover'
                    }`}
                  />
                )}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/35" />
              </div>
            ) : (
              <div className="relative z-10 my-auto flex flex-col items-center justify-center text-center px-6 py-8">
                <img
                  src="/assets/aistudio/1794798316811_13f5c3b0.jpg"
                  alt="BILLS CAVE app cover"
                  referrerPolicy="no-referrer"
                  className="mb-4 h-28 w-28 rounded-3xl object-cover border shadow-2xl"
                  style={{
                    borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
                  }}
                />
                <h3 className="text-lg font-bold" style={{ color: 'var(--am)' }}>
                  4K / 8K Wallpaper &amp; GIF Spot
                </h3>
                <p className="mt-1.5 max-w-sm text-xs opacity-80 leading-relaxed">
                  Drop or choose any 4K / 8K image, animated GIF, WebP, or looping video to display
                  right inside your player stage.
                </p>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-4 min-h-[44px] flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold shadow-lg active:scale-95 transition"
                  style={{ background: 'var(--am)', color: 'var(--bg)' }}
                >
                  <ImagePlus className="h-4 w-4" />
                  Load Wallpaper / GIF
                </button>
              </div>
            )}

            {/* Top Wallpaper Spot Toolbar */}
            <div className="relative z-10 flex items-center justify-between gap-2">
              <span className="rounded-lg bg-black/55 backdrop-blur-md px-2.5 py-1 text-[11px] font-semibold tracking-wider uppercase text-white/90">
                {wallUrl ? '4K / 8K Stage Active' : 'Player Media Frame'}
              </span>
              {theme.anim3d && (
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-full bg-black/55 backdrop-blur-md border border-white/15 ${
                    isPlaying ? 'anim-3d-spin' : ''
                  }`}
                  style={{ color: 'var(--am)' }}
                  title="3D Audio Emblem"
                >
                  <Disc3 className="h-5 w-5" />
                </div>
              )}
            </div>

            {/* Bottom Wallpaper Spot Controls */}
            <div className="relative z-10 mt-auto flex flex-wrap items-center justify-between gap-2 pt-3">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-black/60 hover:bg-black/80 backdrop-blur-md px-3 py-1.5 text-xs font-semibold text-white transition"
                >
                  <ImagePlus className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                  <span>Add 4K/8K/GIF</span>
                </button>
                <button
                  type="button"
                  onClick={onRandomWallpaper}
                  title="Random wallpaper from vault"
                  className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-black/60 hover:bg-black/80 backdrop-blur-md px-3 py-1.5 text-xs font-semibold text-white transition"
                >
                  <Shuffle className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                  <span>Random</span>
                </button>
              </div>
              {wallUrl && (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onToggleWallFit}
                    title={theme.wallFit === 'contain' ? 'Switch to Cover fill' : 'Switch to Full Contain'}
                    className="flex h-10 w-10 items-center justify-center rounded-xl bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition"
                  >
                    {theme.wallFit === 'contain' ? (
                      <Maximize2 className="h-4 w-4" />
                    ) : (
                      <Minimize2 className="h-4 w-4" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={onRemoveWallpaper}
                    title="Clear player wallpaper"
                    className="flex h-10 w-10 items-center justify-center rounded-xl bg-black/60 hover:bg-red-900/70 backdrop-blur-md text-white transition"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*,.gif,.webp,.avif,.mp4,.webm,.mkv,.mov"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (f) onPickWallpaper(f);
              }}
            />
          </MaterialSurface>
        </div>

        {/* RIGHT: 3D AUDIO DECK & MEDIA CONTROLS */}
        <div className="lg:col-span-5 flex flex-col">
          <MaterialSurface
            material={mat}
            anim3d={theme.anim3d}
            depth3d={theme.depth3d}
            tiltMax={6}
            className="flex-1 rounded-3xl p-5 sm:p-6 flex flex-col justify-between gap-5"
          >
            {/* Title & Track Info */}
            <div>
              <div className="flex items-center justify-between gap-2 text-xs opacity-70">
                <span>
                  {bookIcon} {book?.genres.join(' · ') || 'Audio Deck'}
                </span>
                {book && book.tracks.length > 1 && (
                  <span className="tabular-nums font-semibold" style={{ color: 'var(--am)' }}>
                    Part {trackIndex + 1} / {book.tracks.length}
                  </span>
                )}
              </div>
              <h2
                className="mt-1.5 text-xl sm:text-2xl font-bold leading-snug break-words"
                style={{ color: 'var(--am)' }}
              >
                {book ? book.title : 'Ready to Play'}
              </h2>
              <p className="mt-1 truncate text-xs opacity-75">
                {book
                  ? book.tracks[trackIndex]?.n
                  : 'Add an audiobook or sample track from the Library room'}
              </p>
            </div>

            {/* Big Monospace Time Readout + Scrubbing Bar */}
            <div>
              <div className="tabular-nums text-center font-mono text-3xl sm:text-4xl font-bold tracking-tight">
                {fmt(currentTime)}
              </div>
              <div className="mt-2 flex items-center justify-between text-xs tabular-nums opacity-70">
                <span>{fmt(currentTime)}</span>
                <span>-{fmt(Math.max(0, duration - currentTime))}</span>
              </div>
              <div className="relative mt-1.5 flex items-center h-6">
                <div className="pointer-events-none absolute inset-x-0 h-2 rounded-full bg-black/45 overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${pct}%`,
                      background: 'var(--am)',
                      boxShadow: '0 0 12px color-mix(in srgb, var(--am) 75%, transparent)',
                    }}
                  />
                </div>
                <input
                  type="range"
                  aria-label="Scrub audio position"
                  min={0}
                  max={safeDur}
                  step={0.1}
                  value={Math.min(currentTime, safeDur)}
                  disabled={!book}
                  onChange={(e) => onSeek(Number(e.target.value))}
                  className="cave-slider relative z-10 w-full"
                />
              </div>
            </div>

            {/* Primary Transport Controls: Prev, -30, Play/Pause, +30, Next */}
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={onPrev}
                disabled={!book}
                aria-label="Previous track"
                className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 disabled:opacity-35 transition"
              >
                <SkipBack className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={onSkipBack30}
                disabled={!book}
                aria-label="Rewind 30 seconds"
                className="flex h-12 w-12 flex-col items-center justify-center rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 disabled:opacity-35 transition"
              >
                <RotateCcw className="h-4 w-4" />
                <span className="text-[10px] font-bold">30</span>
              </button>
              <button
                type="button"
                onClick={onTogglePlay}
                disabled={!book}
                aria-label={isPlaying ? 'Pause' : 'Play'}
                className="flex h-16 w-16 items-center justify-center rounded-full shadow-2xl active:scale-95 disabled:opacity-40 transition"
                style={{
                  background: 'var(--am)',
                  color: 'var(--bg)',
                  boxShadow: '0 8px 28px color-mix(in srgb, var(--am) 55%, transparent)',
                }}
              >
                {isPlaying ? (
                  <Pause className="h-7 w-7 fill-current" />
                ) : (
                  <Play className="h-7 w-7 fill-current ml-0.5" />
                )}
              </button>
              <button
                type="button"
                onClick={onSkipFwd30}
                disabled={!book}
                aria-label="Forward 30 seconds"
                className="flex h-12 w-12 flex-col items-center justify-center rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 disabled:opacity-35 transition"
              >
                <RotateCw className="h-4 w-4" />
                <span className="text-[10px] font-bold">30</span>
              </button>
              <button
                type="button"
                onClick={onNext}
                disabled={!book || trackIndex + 1 >= (book?.tracks.length || 0)}
                aria-label="Next track"
                className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 disabled:opacity-35 transition"
              >
                <SkipForward className="h-5 w-5" />
              </button>
            </div>

            {/* Volume Control Strip */}
            <div className="flex items-center gap-3 rounded-2xl bg-black/25 px-3.5 py-2.5 border border-white/10">
              <button
                type="button"
                onClick={onToggleMute}
                aria-label={muted ? 'Unmute' : 'Mute'}
                className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/10 transition shrink-0"
                style={{ color: muted ? '#ff7b7b' : 'var(--am)' }}
              >
                {muted || volume === 0 ? (
                  <VolumeX className="h-5 w-5" />
                ) : (
                  <Volume2 className="h-5 w-5" />
                )}
              </button>
              <input
                type="range"
                aria-label="Master volume"
                min={0}
                max={1}
                step={0.01}
                value={muted ? 0 : volume}
                onChange={(e) => onVolumeChange(Number(e.target.value))}
                className="cave-slider flex-1"
              />
              <span className="tabular-nums text-xs font-semibold w-10 text-right opacity-80">
                {muted ? '0%' : `${Math.round(volume * 100)}%`}
              </span>
            </div>

            {/* Utility Row: Bookmark, Speed/Sleep, Go To */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={onBookmark}
                disabled={!book}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-white/5 hover:bg-white/10 px-2 py-2 text-xs font-semibold disabled:opacity-40 transition"
              >
                <Bookmark className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                <span>Bookmark</span>
              </button>
              <button
                type="button"
                onClick={onSpeedSleep}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-white/5 hover:bg-white/10 px-2 py-2 text-xs font-semibold transition"
              >
                <SlidersHorizontal className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                <span>Speed / Sleep</span>
              </button>
              <button
                type="button"
                onClick={onJumpTime}
                disabled={!book}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-white/5 hover:bg-white/10 px-2 py-2 text-xs font-semibold disabled:opacity-40 transition"
              >
                <Clock className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                <span>Go to…</span>
              </button>
            </div>
          </MaterialSurface>
        </div>
      </div>
    </section>
  );
};
