import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import {
  ArrowLeft,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  CloudRain,
  Droplets,
  FileText,
  Highlighter,
  MessageSquare,
  Moon,
  PenTool,
  Plus,
  RotateCw,
  Search,
  Share2,
  Trash2,
  Type,
  Undo2,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { AppState, PdfAnnotation, PdfEntry, SheetOption } from '../types';
import { VOCAB } from '../data/themes';
import { hashStr, idbDel, idbGet, idbPut } from '../utils/storage';
import { MaterialSurface } from './MaterialSurface';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

interface PdfViewProps {
  state: AppState;
  listFilter?: string;
  sortBy?: 'recent' | 'title' | 'progress';
  onSavePdfMeta: (id: string, entry: PdfEntry | null) => void;
  onToggleSpread: () => void;
  onReadingChange?: (reading: boolean) => void;
  onToggleRainOnRead?: () => void;
  onOpenSheet: (title: string, options: SheetOption[]) => void;
  onOpenInput: (opts: {
    title: string;
    initialValue?: string;
    placeholder?: string;
    onConfirm: (val: string) => void;
  }) => void;
  onToast: (msg: string) => void;
}

type ToolMode = null | 'hl' | 'pen' | 'sig' | 'note' | 'txt';

export const PdfView: React.FC<PdfViewProps> = ({
  state,
  listFilter = '',
  sortBy = 'recent',
  onSavePdfMeta,
  onToggleSpread,
  onReadingChange,
  onToggleRainOnRead,
  onOpenSheet,
  onOpenInput,
  onToast,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [viewerId, setViewerId] = useState<string | null>(null);
  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [pageNum, setPageNum] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [nightMode, setNightMode] = useState(false);
  const [liquidMode, setLiquidMode] = useState(false);
  const [liquidText, setLiquidText] = useState('');
  const [ttsActive, setTtsActive] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [tool, setTool] = useState<ToolMode>(null);

  const canvasLeftRef = useRef<HTMLCanvasElement>(null);
  const canvasRightRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const bookRef = useRef<HTMLDivElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  const scaleRef = useRef(1);
  const fitRef = useRef(true);
  const fitDirtyRef = useRef(true);
  const busyRef = useRef(false);
  const touchStartXRef = useRef<number | null>(null);
  const drawStateRef = useRef<{
    canvas: HTMLCanvasElement;
    page: number;
    rect: DOMRect;
    pts: [number, number][];
  } | null>(null);

  const vocab = VOCAB[state.theme.sk] || VOCAB.cave;

  const isSpread = useCallback(() => {
    return state.spread === undefined ? window.innerWidth >= 760 : state.spread;
  }, [state.spread]);

  const getLR = useCallback(
    (n: number): [number, number] => {
      if (!isSpread()) return [n, 0];
      const L = n === 1 ? 0 : n % 2 ? n - 1 : n;
      return [L, L + 1];
    },
    [isSpread]
  );

  const drawAnnotations = useCallback(
    (canvas: HTMLCanvasElement, n: number) => {
      if (rotation !== 0 || !viewerId) return;
      const anns = state.pdfs[viewerId]?.ann?.[n];
      if (!anns?.length) return;
      const g = canvas.getContext('2d');
      if (!g) return;
      const W = canvas.width;
      const H = canvas.height;
      g.save();
      for (const a of anns) {
        if (a.t === 'hl' && a.x !== undefined && a.y !== undefined && a.w && a.h) {
          g.globalCompositeOperation = 'multiply';
          g.fillStyle = '#ffe600';
          g.fillRect(a.x * W, a.y * H, a.w * W, a.h * H);
          g.globalCompositeOperation = 'source-over';
        } else if ((a.t === 'pen' || a.t === 'sig') && a.p?.length) {
          g.strokeStyle = a.t === 'pen' ? '#e53935' : '#1e4bd8';
          g.lineWidth = W * 0.004;
          g.lineCap = 'round';
          g.lineJoin = 'round';
          g.beginPath();
          a.p.forEach(([x, y], i) => (i === 0 ? g.moveTo(x * W, y * H) : g.lineTo(x * W, y * H)));
          g.stroke();
        } else if (a.t === 'txt' && a.s && a.x !== undefined && a.y !== undefined) {
          g.fillStyle = '#111111';
          g.font = `${W * 0.03}px sans-serif`;
          g.textBaseline = 'top';
          a.s.split('\n').forEach((line, idx) => {
            g.fillText(line, a.x! * W, a.y! * H + idx * W * 0.036);
          });
        } else if (a.t === 'note' && a.x !== undefined && a.y !== undefined) {
          const z = W * 0.04;
          g.fillStyle = '#ffd54a';
          g.strokeStyle = '#8a6d00';
          g.lineWidth = 2;
          g.fillRect(a.x * W, a.y * H, z, z);
          g.strokeRect(a.x * W, a.y * H, z, z);
          g.fillStyle = '#4a3800';
          g.font = `${z * 0.8}px sans-serif`;
          g.textBaseline = 'middle';
          g.fillText('≡', a.x * W + z * 0.2, a.y * H + z / 2);
        }
      }
      g.restore();
    },
    [rotation, state.pdfs, viewerId]
  );

  const paintPage = useCallback(
    async (
      doc: pdfjsLib.PDFDocumentProxy,
      n: number,
      canvas: HTMLCanvasElement,
      refCanvas?: HTMLCanvasElement | null
    ) => {
      const dpr = window.devicePixelRatio || 1;
      if (!n || n > doc.numPages) {
        canvas.width = refCanvas ? refCanvas.width : 10;
        canvas.height = refCanvas ? refCanvas.height : 10;
        canvas.style.width = refCanvas ? refCanvas.style.width : '10px';
        canvas.style.height = refCanvas ? refCanvas.style.height : '10px';
        canvas.style.visibility = 'hidden';
        return;
      }
      canvas.style.visibility = '';
      const pg = await doc.getPage(n);
      const vp = pg.getViewport({ scale: scaleRef.current * dpr, rotation });
      canvas.width = vp.width;
      canvas.height = vp.height;
      canvas.style.width = `${vp.width / dpr}px`;
      canvas.style.height = `${vp.height / dpr}px`;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        await pg.render({ canvasContext: ctx, viewport: vp, canvas }).promise;
        drawAnnotations(canvas, n);
      }
    },
    [drawAnnotations, rotation]
  );

  const calcScale = useCallback(
    async (doc: pdfjsLib.PDFDocumentProxy, n: number) => {
      const sp = isSpread();
      const [L, R] = getLR(n);
      const pg = await doc.getPage(L || R || n);
      const vp = pg.getViewport({ scale: 1, rotation });
      if (fitRef.current && fitDirtyRef.current && wrapRef.current) {
        fitDirtyRef.current = false;
        const cw = Math.max(260, wrapRef.current.clientWidth - 16);
        const ch = Math.max(260, wrapRef.current.clientHeight - 16);
        let sc = cw / (sp ? 2 : 1) / vp.width;
        if (sp) sc = Math.min(sc, ch / vp.height);
        scaleRef.current = sc;
      }
    },
    [getLR, isSpread, rotation]
  );

  const getPageText = useCallback(
    async (doc: pdfjsLib.PDFDocumentProxy, n: number) => {
      const pg = await doc.getPage(n);
      const tc = await pg.getTextContent();
      return tc.items
        .map((item) => ('str' in item ? `${item.str}${item.hasEOL ? '\n' : ' '}` : ''))
        .join('');
    },
    []
  );

  const buildLiquid = useCallback(
    async (doc: pdfjsLib.PDFDocumentProxy, n: number) => {
      let text = '';
      for (const p of getLR(n)) {
        if (p && p <= doc.numPages) {
          text += `— Page ${p} —\n${(await getPageText(doc, p)).replace(/\n(?=[a-z])/g, ' ')}\n\n`;
        }
      }
      setLiquidText(text || 'No selectable text detected on this page.');
    },
    [getLR, getPageText]
  );

  const speakPage = useCallback(
    async (doc: pdfjsLib.PDFDocumentProxy, n: number) => {
      window.speechSynthesis.cancel();
      let text = '';
      for (const p of getLR(n)) {
        if (p && p <= doc.numPages) text += `${await getPageText(doc, p)}\n`;
      }
      if (!text.trim()) return;
      const chunks = text.match(/[\s\S]{1,2200}(\s|$)/g) || [];
      chunks.forEach((chunk) => {
        const utt = new SpeechSynthesisUtterance(chunk);
        window.speechSynthesis.speak(utt);
      });
    },
    [getLR, getPageText]
  );

  const drawCurrent = useCallback(
    async (docOverride?: pdfjsLib.PDFDocumentProxy, pageOverride?: number) => {
      const doc = docOverride || pdfDoc;
      if (!doc || busyRef.current) return;
      busyRef.current = true;
      try {
        const target = Math.max(1, Math.min(pageOverride ?? pageNum, doc.numPages));
        await calcScale(doc, target);
        const [L, R] = getLR(target);
        const sp = isSpread();
        const cl = canvasLeftRef.current;
        const cr = canvasRightRef.current;
        if (cl && cr) {
          cr.style.display = sp ? '' : 'none';
          if (sp) {
            if (L) await paintPage(doc, L, cl);
            if (R <= doc.numPages) await paintPage(doc, R, cr, L ? cl : null);
            if (!L) await paintPage(doc, 0, cl, cr);
            if (R > doc.numPages) await paintPage(doc, 0, cr, cl);
          } else {
            await paintPage(doc, L, cl);
          }
        }
        if (wrapRef.current) wrapRef.current.scrollTop = 0;
        if (viewerId && state.pdfs[viewerId]) {
          onSavePdfMeta(viewerId, { ...state.pdfs[viewerId], page: L || R, u: Date.now() });
        }
        if (liquidMode) buildLiquid(doc, target);
        if (ttsActive) speakPage(doc, target);
      } finally {
        busyRef.current = false;
      }
    },
    [
      buildLiquid,
      calcScale,
      getLR,
      isSpread,
      liquidMode,
      onSavePdfMeta,
      pageNum,
      paintPage,
      pdfDoc,
      speakPage,
      state.pdfs,
      ttsActive,
      viewerId,
    ]
  );

  useEffect(() => {
    const reading = !!(viewerId && pdfDoc);
    onReadingChange?.(reading);
    return () => onReadingChange?.(false);
  }, [viewerId, pdfDoc, onReadingChange]);

  useEffect(() => {
    if (pdfDoc && viewerId) {
      drawCurrent(pdfDoc, pageNum);
    }
  }, [pageNum, rotation, state.spread, pdfDoc, viewerId]);

  const turn3D = async (dir: 1 | -1) => {
    if (!pdfDoc || busyRef.current) return;
    const sp = isSpread();
    const [L, R] = getLR(pageNum);
    const nextP = dir > 0 ? (sp ? R : pageNum) + 1 : sp ? L - 1 : pageNum - 1;
    if (nextP < 1 || nextP > pdfDoc.numPages) return;

    const cl = canvasLeftRef.current;
    const cr = canvasRightRef.current;
    const bk = bookRef.current;
    if (!cl || !cr || !bk) {
      setPageNum(nextP);
      return;
    }

    busyRef.current = true;
    try {
      const [nL, nR] = getLR(nextP);
      const tL = document.createElement('canvas');
      const tR = document.createElement('canvas');
      await calcScale(pdfDoc, nextP);
      if (sp) {
        if (nL) await paintPage(pdfDoc, nL, tL);
        if (nR <= pdfDoc.numPages) await paintPage(pdfDoc, nR, tR, nL ? tL : null);
        if (!nL) await paintPage(pdfDoc, 0, tL, tR);
        if (nR > pdfDoc.numPages) await paintPage(pdfDoc, 0, tR, tL);
      } else {
        await paintPage(pdfDoc, nL, tL);
      }

      const cpy = (dest: HTMLCanvasElement, src: HTMLCanvasElement) => {
        dest.width = src.width;
        dest.height = src.height;
        dest.style.width = src.style.width;
        dest.style.height = src.style.height;
        dest.style.visibility = src.style.visibility;
        dest.getContext('2d')?.drawImage(src, 0, 0);
      };

      const old = dir > 0 && sp ? cr : cl;
      const front = document.createElement('canvas');
      cpy(front, old);
      front.style.cssText = '';

      let back: HTMLCanvasElement;
      if (sp) {
        back = dir > 0 ? tL : tR;
      } else {
        back = document.createElement('canvas');
        back.width = front.width;
        back.height = front.height;
        const g = back.getContext('2d');
        if (g) {
          g.fillStyle = '#f8f5ef';
          g.fillRect(0, 0, back.width, back.height);
        }
      }
      back.style.cssText = '';
      back.className = 'pdf-back';

      if (sp) {
        if (dir > 0) cpy(cr, tR);
        else cpy(cl, tL);
      } else {
        cpy(cl, tL);
      }

      const el = dir > 0 && sp ? cr : cl;
      const leaf = document.createElement('div');
      leaf.className = 'pdf-leaf';
      leaf.append(front, back);
      leaf.style.left = `${el.offsetLeft}px`;
      leaf.style.top = `${el.offsetTop}px`;
      leaf.style.width = `${el.offsetWidth}px`;
      leaf.style.height = `${el.offsetHeight}px`;
      leaf.style.transformOrigin = `${dir > 0 ? 'left' : 'right'} center`;
      bk.append(leaf);
      void leaf.offsetWidth;
      leaf.style.transform = `rotateY(${dir > 0 ? -180 : 180}deg)`;
      await new Promise((r) => setTimeout(r, 860));
      if (sp) {
        if (dir > 0) cpy(cl, tL);
        else cpy(cr, tR);
      }
      leaf.remove();
      setPageNum(nextP);
    } finally {
      busyRef.current = false;
    }
  };

  const handleAddPdfs = async (files: FileList) => {
    let firstId: string | null = null;
    for (const f of Array.from(files)) {
      const id = hashStr(f.name + f.size);
      if (!firstId) firstId = id;
      await idbPut('f', `pdf:${id}`, f);
      const existing = state.pdfs[id];
      onSavePdfMeta(id, {
        ...(existing || {}),
        n: f.name,
        page: existing?.page || 1,
        u: Date.now(),
      });
    }
    if (firstId) openPdfById(firstId);
  };

  const openPdfById = async (id: string) => {
    try {
      onToast('Opening PDF…');
      const blob = await idbGet<Blob>('f', `pdf:${id}`);
      if (!blob) {
        onToast('PDF file missing — re-add it to open');
        return;
      }
      const doc = await pdfjsLib.getDocument({ data: await blob.arrayBuffer() }).promise;
      const entry = state.pdfs[id];
      const targetPage = Math.min(entry?.page || 1, doc.numPages);
      fitRef.current = true;
      fitDirtyRef.current = true;
      setRotation(0);
      setNumPages(doc.numPages);
      setViewerId(id);
      setPdfDoc(doc);
      setPageNum(targetPage);
      onSavePdfMeta(id, {
        ...entry,
        pages: doc.numPages,
        page: targetPage,
        u: Date.now(),
      });
    } catch {
      onToast('Could not open PDF file');
    }
  };

  const handleSearch = async () => {
    const q = searchQuery.trim().toLowerCase();
    if (!q || !pdfDoc) return;
    onToast('Searching document…');
    for (let k = 0; k < pdfDoc.numPages; k++) {
      const n = ((pageNum + k) % pdfDoc.numPages) + 1;
      const txt = (await getPageText(pdfDoc, n)).toLowerCase();
      if (txt.includes(q)) {
        onToast(`Found on page ${n}`);
        setPageNum(n);
        return;
      }
    }
    onToast('Text not found');
  };

  const handleOverlayPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!tool || !bookRef.current || !overlayRef.current) return;
    const ov = overlayRef.current;
    if (ov.width !== bookRef.current.offsetWidth || ov.height !== bookRef.current.offsetHeight) {
      ov.width = bookRef.current.offsetWidth;
      ov.height = bookRef.current.offsetHeight;
    }
    const [L, R] = getLR(pageNum);
    const candidates: [HTMLCanvasElement | null, number][] = [
      [canvasLeftRef.current, L],
      [canvasRightRef.current, R],
    ];
    const hit = candidates.find(([c]) => {
      if (!c || c.style.visibility === 'hidden' || c.style.display === 'none') return false;
      const r = c.getBoundingClientRect();
      return e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
    });
    if (!hit || !hit[0]) return;
    const rect = hit[0].getBoundingClientRect();
    const nx = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    const ny = Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height));
    drawStateRef.current = { canvas: hit[0], page: hit[1], rect, pts: [[nx, ny]] };
    ov.setPointerCapture(e.pointerId);
  };

  const handleOverlayPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const ds = drawStateRef.current;
    const ov = overlayRef.current;
    const bk = bookRef.current;
    if (!ds || !ov || !bk) return;
    const nx = Math.min(1, Math.max(0, (e.clientX - ds.rect.left) / ds.rect.width));
    const ny = Math.min(1, Math.max(0, (e.clientY - ds.rect.top) / ds.rect.height));
    ds.pts.push([nx, ny]);
    const bRect = bk.getBoundingClientRect();
    const ox = ds.rect.left - bRect.left;
    const oy = ds.rect.top - bRect.top;
    const W = ds.rect.width;
    const H = ds.rect.height;
    const cx = ov.getContext('2d');
    if (!cx) return;
    cx.clearRect(0, 0, ov.width, ov.height);
    if (tool === 'hl') {
      const a = ds.pts[0];
      const z = ds.pts[ds.pts.length - 1];
      cx.fillStyle = 'rgba(255, 230, 0, 0.45)';
      cx.fillRect(
        ox + Math.min(a[0], z[0]) * W,
        oy + Math.min(a[1], z[1]) * H,
        Math.abs(z[0] - a[0]) * W,
        Math.max(Math.abs(z[1] - a[1]) * H, 0.015 * H)
      );
    } else if (tool === 'pen' || tool === 'sig') {
      cx.strokeStyle = tool === 'pen' ? '#e53935' : '#1e4bd8';
      cx.lineWidth = 3;
      cx.lineCap = 'round';
      cx.lineJoin = 'round';
      cx.beginPath();
      ds.pts.forEach(([x, y], i) => (i === 0 ? cx.moveTo(ox + x * W, oy + y * H) : cx.lineTo(ox + x * W, oy + y * H)));
      cx.stroke();
    }
  };

  const handleOverlayPointerUp = () => {
    const ds = drawStateRef.current;
    const ov = overlayRef.current;
    drawStateRef.current = null;
    if (ov) ov.getContext('2d')?.clearRect(0, 0, ov.width, ov.height);
    if (!ds || !viewerId || !state.pdfs[viewerId]) return;

    const a = ds.pts[0];
    const z = ds.pts[ds.pts.length - 1];
    const entry = state.pdfs[viewerId];

    const commitAnnotation = (ann: PdfAnnotation) => {
      const prevAnn = entry.ann || {};
      const pageList = [...(prevAnn[ds.page] || []), ann];
      onSavePdfMeta(viewerId, {
        ...entry,
        ann: { ...prevAnn, [ds.page]: pageList },
        log: [...(entry.log || []), ds.page],
      });
      if (pdfDoc) paintPage(pdfDoc, ds.page, ds.canvas);
    };

    if (tool === 'hl') {
      const w = Math.abs(z[0] - a[0]);
      if (w < 0.01) return;
      commitAnnotation({
        t: 'hl',
        x: Math.min(a[0], z[0]),
        y: Math.min(a[1], z[1]),
        w,
        h: Math.max(Math.abs(z[1] - a[1]), 0.015),
      });
    } else if (tool === 'pen' || tool === 'sig') {
      if (ds.pts.length < 2) return;
      commitAnnotation({ t: tool, p: ds.pts });
    } else if (tool === 'note') {
      onOpenInput({
        title: 'Add PDF Comment',
        placeholder: 'Write comment…',
        onConfirm: (s) => {
          if (s.trim()) commitAnnotation({ t: 'note', x: a[0], y: a[1], s: s.trim() });
        },
      });
    } else if (tool === 'txt') {
      onOpenInput({
        title: 'Place Text on Page',
        placeholder: 'Text or date…',
        onConfirm: (s) => {
          if (s.trim()) commitAnnotation({ t: 'txt', x: a[0], y: a[1], s: s.trim() });
        },
      });
    }
  };

  const q = listFilter.trim().toLowerCase();
  const pdfList = Object.entries(state.pdfs)
    .filter(([, p]) => !q || p.n.toLowerCase().includes(q))
    .sort((a, b) => {
      if (sortBy === 'title') return a[1].n.localeCompare(b[1].n);
      if (sortBy === 'progress') {
        const pa = (a[1].page || 1) / Math.max(1, a[1].pages || 1);
        const pb = (b[1].page || 1) / Math.max(1, b[1].pages || 1);
        return pb - pa;
      }
      return (b[1].u || 0) - (a[1].u || 0);
    });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold tracking-wide" style={{ color: 'var(--am)' }}>
            PDF &amp; Tome Library
          </h2>
          <p className="text-xs opacity-70">3D page turns, markup tools, search &amp; page memory</p>
        </div>
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="min-h-[44px] flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold shadow-lg active:scale-95 transition"
          style={{ background: 'var(--am)', color: 'var(--bg)' }}
        >
          <Plus className="h-4 w-4" />
          <span>{vocab.pd}</span>
        </button>
      </div>

      {pdfList.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {pdfList.map(([id, p]) => (
            <MaterialSurface
              key={id}
              material={state.theme.material}
              anim3d={state.theme.anim3d}
              depth3d={state.theme.depth3d}
              tiltMax={4}
              onClick={() => openPdfById(id)}
              className="cursor-pointer rounded-2xl p-3.5 flex items-center gap-3"
            >
              <div
                className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border"
                style={{
                  borderColor: 'color-mix(in srgb, var(--am) 32%, transparent)',
                  color: 'var(--am)',
                }}
              >
                <FileText className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-bold">{p.n}</div>
                <div className="tabular-nums text-xs opacity-70">
                  Page {p.page || 1}
                  {p.pages ? ` / ${p.pages}` : ''}
                </div>
              </div>
              <button
                type="button"
                aria-label={`Remove ${p.n}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenSheet(p.n, [
                    { label: 'Open PDF', onClick: () => openPdfById(id) },
                    {
                      label: 'Delete PDF from Cave',
                      danger: true,
                      onClick: async () => {
                        await idbDel('f', `pdf:${id}`);
                        onSavePdfMeta(id, null);
                      },
                    },
                  ]);
                }}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl hover:bg-red-500/15 text-white/70 hover:text-red-400 transition"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </MaterialSurface>
          ))}
        </div>
      ) : (
        <MaterialSurface
          material={state.theme.material}
          anim3d={state.theme.anim3d}
          depth3d={state.theme.depth3d}
          className="rounded-3xl px-6 py-10 text-center"
        >
          <FileText className="mx-auto mb-3 h-9 w-9 opacity-80" style={{ color: 'var(--am)' }} />
          <p className="text-base font-semibold">No PDFs loaded yet</p>
          <p className="mt-1 text-xs opacity-75">
            Open comics, art books, or manuals. Your exact page and markup annotations stay saved.
          </p>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="mt-4 min-h-[44px] inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold shadow-lg"
            style={{ background: 'var(--am)', color: 'var(--bg)' }}
          >
            <Plus className="h-4 w-4" />
            <span>{vocab.pd}</span>
          </button>
        </MaterialSurface>
      )}

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".pdf,application/pdf"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) handleAddPdfs(e.target.files);
          e.target.value = '';
        }}
      />

      {/* FULL PDF READER MODAL — Translucent over live Rain & Atmospheric Background */}
      {viewerId && pdfDoc && (
        <section
          aria-label="PDF Reader"
          className={`fixed inset-0 z-40 flex flex-col bg-black/35 backdrop-blur-[1px] text-white ${
            nightMode ? 'pdf-night' : ''
          }`}
        >
          {/* Top Bar */}
          <div className="flex items-center gap-1.5 bg-black/65 backdrop-blur-md px-2 py-2 pt-[calc(env(safe-area-inset-top)+6px)] border-b border-white/10">
            <button
              type="button"
              onClick={() => {
                setViewerId(null);
                setPdfDoc(null);
                setTtsActive(false);
                setTool(null);
                window.speechSynthesis.cancel();
              }}
              aria-label="Close PDF"
              className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="min-w-0 flex-1 truncate text-xs font-semibold opacity-85">
              {state.pdfs[viewerId]?.n}
            </div>
            <button
              type="button"
              onClick={onToggleRainOnRead}
              title={state.theme.rainOnRead ? 'Rain in background: ON' : 'Rain in background: OFF'}
              className="flex h-10 items-center gap-1 rounded-xl px-2.5 text-xs font-semibold hover:bg-white/10"
              style={{ color: state.theme.rainOnRead ? 'var(--am)' : '#aaa' }}
            >
              <CloudRain className="h-4 w-4" />
              <span className="hidden sm:inline">Rain</span>
            </button>
            <button
              type="button"
              onClick={() => {
                const next = !ttsActive;
                setTtsActive(next);
                if (next) speakPage(pdfDoc, pageNum);
                else window.speechSynthesis.cancel();
              }}
              title="Read aloud"
              className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/10"
              style={{ color: ttsActive ? 'var(--am)' : '#fff' }}
            >
              {ttsActive ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
            </button>
            <button
              type="button"
              onClick={() => {
                const next = !liquidMode;
                setLiquidMode(next);
                if (next) buildLiquid(pdfDoc, pageNum);
              }}
              title="Reflow text mode"
              className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/10"
              style={{ color: liquidMode ? 'var(--am)' : '#fff' }}
            >
              <Droplets className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => setSearchOpen((s) => !s)}
              title="Search PDF"
              className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/10"
            >
              <Search className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={async () => {
                const b = await idbGet<Blob>('f', `pdf:${viewerId}`);
                if (!b) return;
                try {
                  await navigator.share({
                    files: [new File([b], state.pdfs[viewerId]?.n || 'doc.pdf', { type: 'application/pdf' })],
                  });
                } catch {
                  onToast('Sharing is not supported in this browser');
                }
              }}
              title="Share PDF"
              className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-white/10"
            >
              <Share2 className="h-5 w-5" />
            </button>
          </div>

          {searchOpen && (
            <div className="flex items-center gap-2 bg-[#232323] px-3 py-2 border-b border-white/10">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearch();
                }}
                placeholder="Search text in PDF…"
                className="min-w-0 flex-1 rounded-xl bg-black/40 px-3 py-1.5 text-sm outline-none"
              />
              <button
                type="button"
                onClick={handleSearch}
                className="rounded-xl px-3.5 py-1.5 text-xs font-bold"
                style={{ background: 'var(--am)', color: 'var(--bg)' }}
              >
                Find
              </button>
            </div>
          )}

          {/* Stage */}
          <div className="relative flex flex-1 min-h-0">
            <div
              ref={wrapRef}
              onTouchStart={(e) => {
                touchStartXRef.current = e.changedTouches[0].clientX;
              }}
              onTouchEnd={(e) => {
                if (tool || !fitRef.current || touchStartXRef.current === null) return;
                const dx = e.changedTouches[0].clientX - touchStartXRef.current;
                touchStartXRef.current = null;
                if (Math.abs(dx) > 75) turn3D(dx < 0 ? 1 : -1);
              }}
              className="relative flex-1 overflow-auto p-2 text-center"
            >
              <div ref={bookRef} className="pdf-book">
                <canvas ref={canvasLeftRef} className="block bg-white shadow-2xl" />
                <canvas ref={canvasRightRef} className="block bg-white shadow-2xl" />
                <canvas
                  ref={overlayRef}
                  onPointerDown={handleOverlayPointerDown}
                  onPointerMove={handleOverlayPointerMove}
                  onPointerUp={handleOverlayPointerUp}
                  className="absolute inset-0 z-10 touch-none"
                  style={{ pointerEvents: tool ? 'auto' : 'none' }}
                />
              </div>
            </div>

            {liquidMode && (
              <div className="absolute inset-0 z-20 overflow-y-auto bg-black/60 backdrop-blur-[2px] p-5 sm:p-8 text-base leading-relaxed whitespace-pre-wrap text-neutral-100">
                <div className="mx-auto max-w-3xl">{liquidText}</div>
              </div>
            )}

            {/* Page Pill */}
            <div className="absolute bottom-3 left-1/2 z-30 -translate-x-1/2 flex items-center gap-1 rounded-full bg-black/80 px-2.5 py-1 backdrop-blur-md">
              <button
                type="button"
                onClick={() => turn3D(-1)}
                className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <input
                type="number"
                min={1}
                max={numPages}
                value={pageNum}
                onChange={(e) => setPageNum(Math.max(1, Math.min(numPages, Number(e.target.value) || 1)))}
                className="w-12 bg-transparent text-center text-sm font-semibold tabular-nums outline-none"
              />
              <span className="text-xs opacity-70 pr-1 tabular-nums">/ {numPages}</span>
              <button
                type="button"
                onClick={() => turn3D(1)}
                className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Bottom PDF Tools */}
          <div className="flex items-center justify-around bg-[#1b1b1b] px-1 py-2 pb-[calc(8px+env(safe-area-inset-bottom))] border-t border-white/10">
            <button
              type="button"
              onClick={() => setTool((t) => (t === 'hl' ? null : 'hl'))}
              className="flex flex-col items-center gap-1 px-2 py-1 text-[11px]"
              style={{ color: tool === 'hl' ? 'var(--am)' : '#ddd' }}
            >
              <Highlighter className="h-5 w-5" />
              <span>Highlight</span>
            </button>
            <button
              type="button"
              onClick={() => setTool((t) => (t === 'pen' ? null : 'pen'))}
              className="flex flex-col items-center gap-1 px-2 py-1 text-[11px]"
              style={{ color: tool === 'pen' ? 'var(--am)' : '#ddd' }}
            >
              <PenTool className="h-5 w-5" />
              <span>Draw</span>
            </button>
            <button
              type="button"
              onClick={() => setTool((t) => (t === 'note' ? null : 'note'))}
              className="flex flex-col items-center gap-1 px-2 py-1 text-[11px]"
              style={{ color: tool === 'note' ? 'var(--am)' : '#ddd' }}
            >
              <MessageSquare className="h-5 w-5" />
              <span>Comment</span>
            </button>
            <button
              type="button"
              onClick={() => setTool((t) => (t === 'txt' ? null : 'txt'))}
              className="flex flex-col items-center gap-1 px-2 py-1 text-[11px]"
              style={{ color: tool === 'txt' ? 'var(--am)' : '#ddd' }}
            >
              <Type className="h-5 w-5" />
              <span>Text</span>
            </button>
            <button
              type="button"
              onClick={() => {
                const entry = state.pdfs[viewerId];
                const lastPage = entry?.log?.[entry.log.length - 1];
                if (!lastPage || !entry?.ann?.[lastPage]?.length) {
                  onToast('Nothing to undo');
                  return;
                }
                const updatedList = entry.ann[lastPage].slice(0, -1);
                onSavePdfMeta(viewerId, {
                  ...entry,
                  ann: { ...entry.ann, [lastPage]: updatedList },
                  log: entry.log!.slice(0, -1),
                });
                drawCurrent();
              }}
              className="flex flex-col items-center gap-1 px-2 py-1 text-[11px] text-neutral-300"
            >
              <Undo2 className="h-5 w-5" />
              <span>Undo</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onOpenSheet('PDF View Tools', [
                  {
                    label: 'Zoom In',
                    onClick: () => {
                      fitRef.current = false;
                      scaleRef.current *= 1.25;
                      drawCurrent();
                    },
                  },
                  {
                    label: 'Zoom Out',
                    onClick: () => {
                      fitRef.current = false;
                      scaleRef.current /= 1.25;
                      drawCurrent();
                    },
                  },
                  {
                    label: 'Fit to Screen',
                    onClick: () => {
                      fitRef.current = true;
                      fitDirtyRef.current = true;
                      drawCurrent();
                    },
                  },
                  {
                    label: isSpread() ? 'Switch to Single Page' : 'Switch to Two-Page Spread',
                    onClick: () => {
                      fitDirtyRef.current = true;
                      onToggleSpread();
                    },
                  },
                  {
                    label: 'Rotate 90°',
                    onClick: () => {
                      fitDirtyRef.current = true;
                      setRotation((r) => (r + 90) % 360);
                    },
                  },
                  {
                    label: nightMode ? 'Disable Night Invert' : 'Enable Night Invert',
                    onClick: () => setNightMode((n) => !n),
                  },
                ])
              }
              className="flex flex-col items-center gap-1 px-2 py-1 text-[11px] text-neutral-300"
            >
              <div className="flex gap-0.5">
                <ZoomIn className="h-4 w-4" />
                <ZoomOut className="h-4 w-4" />
              </div>
              <span>View</span>
            </button>
            <button
              type="button"
              onClick={() => {
                fitDirtyRef.current = true;
                onToggleSpread();
              }}
              className="hidden sm:flex flex-col items-center gap-1 px-2 py-1 text-[11px] text-neutral-300"
            >
              <BookOpen className="h-5 w-5" />
              <span>{isSpread() ? 'Spread' : 'Single'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                fitDirtyRef.current = true;
                setRotation((r) => (r + 90) % 360);
              }}
              className="hidden sm:flex flex-col items-center gap-1 px-2 py-1 text-[11px] text-neutral-300"
            >
              <RotateCw className="h-5 w-5" />
              <span>Rotate</span>
            </button>
            <button
              type="button"
              onClick={() => setNightMode((n) => !n)}
              className="hidden sm:flex flex-col items-center gap-1 px-2 py-1 text-[11px]"
              style={{ color: nightMode ? 'var(--am)' : '#ddd' }}
            >
              <Moon className="h-5 w-5" />
              <span>Night</span>
            </button>
          </div>
        </section>
      )}
    </div>
  );
};
