import React, { useEffect, useRef } from 'react';
import { SILHOUETTES } from '../data/themes';
import { SilhouetteType, WeatherEffect } from '../types';

interface WeatherCanvasProps {
  fx: WeatherEffect;
  intensity: number;
  silhouette: SilhouetteType;
  universe?: string;
  onThunder?: () => void;
}

interface Particle {
  x: number;
  y: number;
  z: number;
  l: number;
  v: number;
  r: number;
  p: number;
  a: number;
}

interface Bat {
  x: number;
  y: number;
  vx: number;
  scale: number;
  phase: number;
}

interface CyberStream {
  x: number;
  y: number;
  speed: number;
  len: number;
  chars: string[];
  alpha: number;
}

interface Candle {
  xFrac: number;
  yFrac: number;
  scale: number;
  phase: number;
}

interface Gear {
  xFrac: number;
  yFrac: number;
  radius: number;
  teeth: number;
  speed: number;
  alpha: number;
}

interface FloatingShard {
  x: number;
  y: number;
  size: number;
  vy: number;
  rot: number;
  vr: number;
  hue: string;
  alpha: number;
}

const MATRIX_GLYPHS = '0123456789ABCDEFアイウエオカキクケコサシスセソタチツテト'.split('');

export const WeatherCanvas: React.FC<WeatherCanvasProps> = ({
  fx,
  intensity,
  silhouette,
  universe = 'cave',
  onThunder,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const thunderRef = useRef(onThunder);
  thunderRef.current = onThunder;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let particles: Particle[] = [];
    let bats: Bat[] = [];
    let cyberStreams: CyberStream[] = [];
    let candles: Candle[] = [];
    let gears: Gear[] = [];
    let shards: FloatingShard[] = [];
    let flash = 0;
    let nextLightning = performance.now() + 2200;
    let bolt: [number, number][] = [];

    const initUniverseEntities = (w: number, h: number) => {
      bats = [];
      cyberStreams = [];
      candles = [];
      gears = [];
      shards = [];

      if (universe === 'castlevania' || universe === 'halloween') {
        bats = Array.from({ length: 9 }, (_, i) => ({
          x: Math.random() * w,
          y: h * (0.08 + Math.random() * 0.34),
          vx: (0.7 + Math.random() * 1.1) * (i % 2 === 0 ? 1 : -1),
          scale: 0.55 + Math.random() * 0.75,
          phase: Math.random() * Math.PI * 2,
        }));
      }

      if (universe === 'ghostintheshell') {
        const cols = Math.max(12, Math.floor(w / 48));
        cyberStreams = Array.from({ length: cols }, (_, idx) => {
          const len = 6 + Math.floor(Math.random() * 10);
          return {
            x: (idx + 0.5) * (w / cols) + (Math.random() - 0.5) * 18,
            y: Math.random() * h,
            speed: 0.9 + Math.random() * 1.8,
            len,
            chars: Array.from(
              { length: len },
              () => MATRIX_GLYPHS[Math.floor(Math.random() * MATRIX_GLYPHS.length)]
            ),
            alpha: 0.14 + Math.random() * 0.24,
          };
        });
      }

      if (universe === 'wiz' || universe === 'potter') {
        candles = Array.from({ length: 14 }, (_, i) => ({
          xFrac: 0.06 + (i / 13) * 0.88 + (Math.random() - 0.5) * 0.04,
          yFrac: 0.12 + (i % 3) * 0.11 + Math.random() * 0.08,
          scale: 0.65 + (i % 4) * 0.15,
          phase: Math.random() * Math.PI * 2,
        }));
      }

      if (universe === 'steampunk') {
        gears = [
          { xFrac: 0.85, yFrac: 0.2, radius: 92, teeth: 14, speed: 0.14, alpha: 0.13 },
          { xFrac: 0.74, yFrac: 0.31, radius: 56, teeth: 10, speed: -0.23, alpha: 0.11 },
          { xFrac: 0.14, yFrac: 0.76, radius: 110, teeth: 16, speed: 0.1, alpha: 0.1 },
          { xFrac: 0.24, yFrac: 0.64, radius: 60, teeth: 11, speed: -0.19, alpha: 0.09 },
        ];
      }

      if (universe === 'readyplayerone') {
        const hues = ['56, 189, 248', '168, 85, 247', '250, 204, 21', '236, 72, 153'];
        shards = Array.from({ length: 24 }, (_, i) => ({
          x: Math.random() * w,
          y: Math.random() * h,
          size: 5 + Math.random() * 11,
          vy: -(0.35 + Math.random() * 0.8),
          rot: Math.random() * Math.PI * 2,
          vr: (Math.random() - 0.5) * 0.025,
          hue: hues[i % hues.length],
          alpha: 0.2 + Math.random() * 0.32,
        }));
      }
    };

    const spawn = (init: boolean): Particle => {
      const w = canvas.width;
      const h = canvas.height;
      const z = 0.4 + Math.random() * 0.9;
      if (fx === 'rain' || fx === 'storm') {
        const boost = 0.75 + intensity * 0.55;
        return {
          x: Math.random() * (w + 220) - 110,
          y: init ? Math.random() * h : -30,
          z,
          l: (11 + Math.random() * 19) * z * boost,
          v: ((fx === 'storm' ? 21 : 14) + Math.random() * 10) * z,
          r: 1,
          p: 0,
          a: (0.2 + z * 0.25) * Math.max(0.2, intensity),
        };
      }
      if (fx === 'snow') {
        return {
          x: Math.random() * (w + 100) - 50,
          y: init ? Math.random() * h : -16,
          z,
          l: 0,
          v: (0.55 + Math.random() * 1.35) * z,
          r: (1.2 + Math.random() * 2.6) * z,
          p: Math.random() * Math.PI * 2,
          a: (0.35 + Math.random() * 0.55) * Math.max(0.2, intensity),
        };
      }
      return {
        x: Math.random() * w,
        y: init ? Math.random() * h : h + 14,
        z,
        l: 0,
        v: (0.35 + Math.random() * 1.15) * z,
        r: (1.1 + Math.random() * 2.4) * z,
        p: Math.random() * Math.PI * 2,
        a: (0.4 + Math.random() * 0.55) * Math.max(0.25, intensity),
      };
    };

    const rebuild = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const countMap: Record<string, number> = {
        rain: 260,
        storm: 400,
        snow: 170,
        embers: 85,
        magic: 105,
      };
      const base = countMap[fx] || 0;
      const clampedI = Math.max(0, Math.min(1, intensity));
      const target = clampedI <= 0.01 ? 0 : Math.max(6, Math.round(base * clampedI * 1.45));
      particles = Array.from({ length: target }, () => spawn(true));
      initUniverseEntities(canvas.width, canvas.height);
    };

    rebuild();
    window.addEventListener('resize', rebuild);

    const drawGear = (
      cx: number,
      cy: number,
      r: number,
      teeth: number,
      angle: number,
      alpha: number
    ) => {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle);
      ctx.strokeStyle = `rgba(225, 168, 78, ${alpha})`;
      ctx.fillStyle = `rgba(180, 118, 40, ${alpha * 0.35})`;
      ctx.lineWidth = 2;

      ctx.beginPath();
      const outerR = r + 10;
      const innerR = r - 4;
      for (let i = 0; i < teeth; i++) {
        const a0 = (i / teeth) * Math.PI * 2;
        const a1 = ((i + 0.35) / teeth) * Math.PI * 2;
        const a2 = ((i + 0.5) / teeth) * Math.PI * 2;
        const a3 = ((i + 0.85) / teeth) * Math.PI * 2;
        if (i === 0) ctx.moveTo(Math.cos(a0) * innerR, Math.sin(a0) * innerR);
        ctx.lineTo(Math.cos(a1) * outerR, Math.sin(a1) * outerR);
        ctx.lineTo(Math.cos(a2) * outerR, Math.sin(a2) * outerR);
        ctx.lineTo(Math.cos(a3) * innerR, Math.sin(a3) * innerR);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, r * 0.45, 0, Math.PI * 2);
      ctx.stroke();

      for (let s = 0; s < 4; s++) {
        const sa = (s / 4) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(sa) * r * 0.15, Math.sin(sa) * r * 0.15);
        ctx.lineTo(Math.cos(sa) * innerR, Math.sin(sa) * innerR);
        ctx.stroke();
      }
      ctx.restore();
    };

    const drawSearchlight = (
      ox: number,
      oy: number,
      angle: number,
      length: number,
      spread: number,
      colorRgb: string,
      alpha: number
    ) => {
      ctx.save();
      ctx.translate(ox, oy);
      ctx.rotate(angle);
      const grad = ctx.createLinearGradient(0, 0, length, 0);
      grad.addColorStop(0, `rgba(${colorRgb}, ${alpha})`);
      grad.addColorStop(0.55, `rgba(${colorRgb}, ${alpha * 0.35})`);
      grad.addColorStop(1, `rgba(${colorRgb}, 0)`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(length, -Math.tan(spread) * length);
      ctx.lineTo(length, Math.tan(spread) * length);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const drawFogBand = (
      yBase: number,
      amp: number,
      t: number,
      speed: number,
      colorRgb: string,
      alpha: number,
      w: number,
      h: number
    ) => {
      ctx.save();
      const grad = ctx.createLinearGradient(0, yBase - 120, 0, h);
      grad.addColorStop(0, `rgba(${colorRgb}, 0)`);
      grad.addColorStop(0.45, `rgba(${colorRgb}, ${alpha})`);
      grad.addColorStop(1, `rgba(${colorRgb}, ${alpha * 1.4})`);
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (let x = 0; x <= w; x += 48) {
        const wave =
          Math.sin(x * 0.004 + t * speed) * amp +
          Math.cos(x * 0.009 - t * speed * 0.7) * (amp * 0.5);
        ctx.lineTo(x, yBase + wave);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const renderUniverseEffects = (t: number, w: number, h: number, uIntensity: number) => {
      const m = Math.max(0.18, uIntensity);

      switch (universe) {
        case 'bladerunner': {
          // Volumetric Spinner Searchlights + Hologram Neon Puddle Glow
          const a1 = -0.75 + Math.sin(t * 0.35) * 0.35;
          const a2 = -2.35 + Math.cos(t * 0.28) * 0.32;
          drawSearchlight(w * 0.14, h * 0.92, a1, Math.max(w, h) * 0.95, 0.14, '0, 229, 255', 0.16 * m);
          drawSearchlight(w * 0.86, h * 0.95, a2, Math.max(w, h) * 0.9, 0.16, '255, 138, 40', 0.14 * m);

          // Neon puddle reflections
          for (let i = 0; i < 6; i++) {
            const rx = w * (0.12 + i * 0.15) + Math.sin(t * 0.5 + i) * 18;
            const ry = h * 0.89 + (i % 2) * 18;
            const rgb = i % 2 === 0 ? '0, 229, 255' : '255, 110, 40';
            const pulse = 0.08 + 0.06 * Math.sin(t * 1.8 + i * 1.3);
            const g = ctx.createRadialGradient(rx, ry, 2, rx, ry, 95);
            g.addColorStop(0, `rgba(${rgb}, ${pulse * m})`);
            g.addColorStop(1, `rgba(${rgb}, 0)`);
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.ellipse(rx, ry, 95, 18, 0, 0, Math.PI * 2);
            ctx.fill();
          }
          break;
        }

        case 'readyplayerone': {
          // OASIS 3D Horizon Synth Grid
          ctx.save();
          const horizonY = h * 0.58;
          const vanishX = w * 0.5 + Math.sin(t * 0.3) * (w * 0.04);
          ctx.strokeStyle = `rgba(56, 189, 248, ${0.18 * m})`;
          ctx.lineWidth = 1;
          for (let i = -12; i <= 12; i++) {
            ctx.beginPath();
            ctx.moveTo(vanishX + i * 14, horizonY);
            ctx.lineTo(vanishX + i * (w * 0.14), h);
            ctx.stroke();
          }
          const scroll = (t * 0.25) % 1;
          for (let r = 0; r < 10; r++) {
            const prog = (r + scroll) / 10;
            const y = horizonY + Math.pow(prog, 2.2) * (h - horizonY);
            ctx.strokeStyle = `rgba(168, 85, 247, ${(0.08 + prog * 0.2) * m})`;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
          }
          ctx.restore();

          // Floating holographic voxel shards
          for (const s of shards) {
            s.y += s.vy * m;
            s.rot += s.vr;
            if (s.y < -24) {
              s.y = h + 24;
              s.x = Math.random() * w;
            }
            ctx.save();
            ctx.translate(s.x, s.y);
            ctx.rotate(s.rot);
            ctx.strokeStyle = `rgba(${s.hue}, ${s.alpha * m})`;
            ctx.fillStyle = `rgba(${s.hue}, ${s.alpha * 0.22 * m})`;
            ctx.lineWidth = 1.4;
            ctx.fillRect(-s.size / 2, -s.size / 2, s.size, s.size);
            ctx.strokeRect(-s.size / 2, -s.size / 2, s.size, s.size);
            ctx.restore();
          }
          break;
        }

        case 'castlevania': {
          // Towering Blood Moon + Flapping Nocturnal Bats + Crimson Mist
          const mx = w * 0.78;
          const my = h * 0.22;
          const mr = Math.min(w, h) * 0.13;
          const halo = ctx.createRadialGradient(mx, my, mr * 0.6, mx, my, mr * 3.1);
          halo.addColorStop(0, `rgba(220, 38, 38, ${0.38 * m})`);
          halo.addColorStop(0.5, `rgba(127, 29, 29, ${0.15 * m})`);
          halo.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = halo;
          ctx.beginPath();
          ctx.arc(mx, my, mr * 3.1, 0, Math.PI * 2);
          ctx.fill();

          const moonGrad = ctx.createRadialGradient(mx - mr * 0.2, my - mr * 0.2, mr * 0.1, mx, my, mr);
          moonGrad.addColorStop(0, `rgba(254, 202, 202, ${0.75 * m})`);
          moonGrad.addColorStop(0.6, `rgba(220, 38, 38, ${0.7 * m})`);
          moonGrad.addColorStop(1, `rgba(127, 29, 29, ${0.45 * m})`);
          ctx.fillStyle = moonGrad;
          ctx.beginPath();
          ctx.arc(mx, my, mr, 0, Math.PI * 2);
          ctx.fill();

          drawFogBand(h * 0.82, 22, t, 0.35, '120, 20, 34', 0.18 * m, w, h);

          // Gliding bats
          for (const b of bats) {
            b.x += b.vx;
            b.phase += 0.16;
            b.y += Math.sin(b.phase * 0.5) * 0.4;
            if (b.x > w + 40) b.x = -40;
            if (b.x < -40) b.x = w + 40;
            const wing = Math.sin(b.phase) * 9 * b.scale;
            ctx.save();
            ctx.translate(b.x, b.y);
            ctx.fillStyle = `rgba(10, 4, 8, ${0.78 * m})`;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(-9 * b.scale, -8 * b.scale + wing, -16 * b.scale, wing);
            ctx.quadraticCurveTo(-7 * b.scale, 3 * b.scale, 0, 4 * b.scale);
            ctx.quadraticCurveTo(7 * b.scale, 3 * b.scale, 16 * b.scale, wing);
            ctx.quadraticCurveTo(9 * b.scale, -8 * b.scale + wing, 0, 0);
            ctx.fill();
            ctx.restore();
          }
          break;
        }

        case 'berserk': {
          // The Eclipse Sun: pitch-black sun with pulsing blood corona
          const ex = w * 0.5;
          const ey = h * 0.25;
          const er = Math.min(w, h) * 0.11;
          const pulse = 1 + Math.sin(t * 1.4) * 0.08;
          const corona = ctx.createRadialGradient(ex, ey, er * 0.9, ex, ey, er * 3.4 * pulse);
          corona.addColorStop(0, `rgba(225, 29, 46, ${0.55 * m})`);
          corona.addColorStop(0.3, `rgba(165, 30, 43, ${0.28 * m})`);
          corona.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = corona;
          ctx.beginPath();
          ctx.arc(ex, ey, er * 3.4 * pulse, 0, Math.PI * 2);
          ctx.fill();

          // Eclipse blazing rim + black core
          ctx.fillStyle = '#060305';
          ctx.beginPath();
          ctx.arc(ex, ey, er, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = `rgba(255, 70, 82, ${0.8 * m})`;
          ctx.lineWidth = 2.5;
          ctx.stroke();

          drawFogBand(h * 0.8, 28, t, 0.42, '145, 20, 32', 0.2 * m, w, h);
          break;
        }

        case 'ghostintheshell': {
          // Cascading Section-9 Cyber Matrix Streams + Neural Scanline
          ctx.save();
          ctx.font = '12px ui-monospace, monospace';
          for (const st of cyberStreams) {
            st.y += st.speed * m;
            if (st.y - st.len * 16 > h) {
              st.y = -20;
            }
            for (let i = 0; i < st.len; i++) {
              const cy = st.y - i * 16;
              if (cy < -16 || cy > h + 16) continue;
              const fade = (1 - i / st.len) * st.alpha * m;
              ctx.fillStyle =
                i === 0 ? `rgba(204, 251, 241, ${fade * 1.6})` : `rgba(45, 212, 191, ${fade})`;
              ctx.fillText(st.chars[i], st.x, cy);
            }
          }
          // Neural optical scan sweep
          const scanY = ((t * 55) % (h + 120)) - 60;
          const sg = ctx.createLinearGradient(0, scanY - 30, 0, scanY + 30);
          sg.addColorStop(0, 'rgba(45, 212, 191, 0)');
          sg.addColorStop(0.5, `rgba(45, 212, 191, ${0.14 * m})`);
          sg.addColorStop(1, 'rgba(45, 212, 191, 0)');
          ctx.fillStyle = sg;
          ctx.fillRect(0, scanY - 30, w, 60);
          ctx.restore();
          break;
        }

        case 'witcher': {
          // Rolling pale forest/swamp mist + Igni & Aard sign motes
          drawFogBand(h * 0.78, 24, t, 0.26, '158, 178, 165', 0.14 * m, w, h);
          drawFogBand(h * 0.87, 16, t, -0.2, '120, 145, 138', 0.16 * m, w, h);
          for (let i = 0; i < 10; i++) {
            const x = ((w * (0.1 + i * 0.09)) + Math.sin(t * 0.5 + i * 2) * 45) % w;
            const y = h * (0.3 + (i % 4) * 0.14) + Math.cos(t * 0.7 + i) * 24;
            const rgb = i % 2 === 0 ? '251, 146, 60' : '165, 243, 252';
            const g = ctx.createRadialGradient(x, y, 0, x, y, 16);
            g.addColorStop(0, `rgba(${rgb}, ${0.42 * m})`);
            g.addColorStop(1, `rgba(${rgb}, 0)`);
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.arc(x, y, 16, 0, Math.PI * 2);
            ctx.fill();
          }
          break;
        }

        case 'christmas': {
          // Warm Hearth & Festive Tree Bokeh Orbs + Golden Starlight Halo
          const starX = w * 0.5;
          const starY = h * 0.16;
          const sg = ctx.createRadialGradient(starX, starY, 2, starX, starY, 170);
          sg.addColorStop(0, `rgba(254, 240, 138, ${0.35 * m})`);
          sg.addColorStop(0.5, `rgba(251, 191, 36, ${0.12 * m})`);
          sg.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = sg;
          ctx.beginPath();
          ctx.arc(starX, starY, 170, 0, Math.PI * 2);
          ctx.fill();

          const bokehColors = ['225, 29, 72', '251, 191, 36', '34, 197, 94', '254, 243, 199'];
          for (let i = 0; i < 14; i++) {
            const bx = w * ((i + 0.5) / 14) + Math.sin(t * 0.4 + i) * 16;
            const by = h * (0.76 + (i % 3) * 0.06) + Math.cos(t * 0.6 + i) * 10;
            const r = 18 + (i % 4) * 9;
            const blink = 0.45 + 0.55 * Math.sin(t * 1.9 + i * 1.4);
            const col = bokehColors[i % bokehColors.length];
            const g = ctx.createRadialGradient(bx, by, 1, bx, by, r);
            g.addColorStop(0, `rgba(${col}, ${0.22 * blink * m})`);
            g.addColorStop(1, `rgba(${col}, 0)`);
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.arc(bx, by, r, 0, Math.PI * 2);
            ctx.fill();
          }
          break;
        }

        case 'steampunk': {
          // Rotating Brass Clockwork Gears + Rising Steam Plumes
          for (const g of gears) {
            drawGear(w * g.xFrac, h * g.yFrac, g.radius, g.teeth, t * g.speed, g.alpha * m * 1.4);
          }
          drawFogBand(h * 0.85, 20, t, 0.3, '245, 215, 175', 0.1 * m, w, h);
          break;
        }

        case 'thecreator': {
          // NOMAD Orbital Laser Scan Beam descending from orbit + warm horizon mist
          const sweepX = w * (0.5 + Math.sin(t * 0.26) * 0.34);
          drawSearchlight(sweepX, -20, Math.PI * 0.5 + Math.sin(t * 0.26) * 0.14, h * 1.1, 0.09, '56, 189, 248', 0.2 * m);
          drawFogBand(h * 0.82, 18, t, 0.22, '249, 115, 22', 0.1 * m, w, h);
          break;
        }

        case 'halloween': {
          // Full Harvest Moon + Spectral Will-o'-the-Wisps + Fog + Bats
          const hx = w * 0.22;
          const hy = h * 0.22;
          const hr = Math.min(w, h) * 0.11;
          const hg = ctx.createRadialGradient(hx, hy, hr * 0.4, hx, hy, hr * 2.8);
          hg.addColorStop(0, `rgba(255, 160, 60, ${0.42 * m})`);
          hg.addColorStop(0.5, `rgba(147, 51, 234, ${0.14 * m})`);
          hg.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = hg;
          ctx.beginPath();
          ctx.arc(hx, hy, hr * 2.8, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = `rgba(255, 210, 140, ${0.58 * m})`;
          ctx.beginPath();
          ctx.arc(hx, hy, hr, 0, Math.PI * 2);
          ctx.fill();

          drawFogBand(h * 0.84, 24, t, 0.28, '126, 34, 206', 0.16 * m, w, h);

          // Spectral orange-amber wisps
          for (let i = 0; i < 8; i++) {
            const wx = w * (0.1 + i * 0.11) + Math.sin(t * 0.8 + i * 1.7) * 26;
            const wy = h * 0.68 + Math.sin(t * 1.3 + i) * 28;
            const wg = ctx.createRadialGradient(wx, wy, 0, wx, wy, 20);
            wg.addColorStop(0, `rgba(255, 130, 24, ${0.45 * m})`);
            wg.addColorStop(1, 'rgba(255, 117, 24, 0)');
            ctx.fillStyle = wg;
            ctx.beginPath();
            ctx.arc(wx, wy, 20, 0, Math.PI * 2);
            ctx.fill();
          }

          for (const b of bats) {
            b.x += b.vx;
            b.phase += 0.16;
            if (b.x > w + 40) b.x = -40;
            if (b.x < -40) b.x = w + 40;
            const wing = Math.sin(b.phase) * 9 * b.scale;
            ctx.save();
            ctx.translate(b.x, b.y);
            ctx.fillStyle = `rgba(14, 7, 18, ${0.78 * m})`;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(-9 * b.scale, -8 * b.scale + wing, -16 * b.scale, wing);
            ctx.quadraticCurveTo(-7 * b.scale, 3 * b.scale, 0, 4 * b.scale);
            ctx.quadraticCurveTo(7 * b.scale, 3 * b.scale, 16 * b.scale, wing);
            ctx.quadraticCurveTo(9 * b.scale, -8 * b.scale + wing, 0, 0);
            ctx.fill();
            ctx.restore();
          }
          break;
        }

        case 'batman2022': {
          // Gotham Crimson Beacon Searchlight + Rain Cloud Flare
          const ba = -1.15 + Math.sin(t * 0.25) * 0.35;
          drawSearchlight(w * 0.22, h * 0.96, ba, Math.max(w, h), 0.13, '220, 38, 38', 0.2 * m);
          drawFogBand(h * 0.84, 22, t, 0.32, '140, 20, 28', 0.16 * m, w, h);
          break;
        }

        case 'medieval_beautiful': {
          // Sunlit Cathedral / Forest Canopy Volumetric God-Rays + Golden Pollen
          for (let i = 0; i < 4; i++) {
            const angle = 0.68 + i * 0.12 + Math.sin(t * 0.2 + i) * 0.03;
            drawSearchlight(
              w * (0.12 + i * 0.18),
              -40,
              angle,
              Math.max(w, h) * 1.1,
              0.08,
              '250, 204, 100',
              0.11 * m
            );
          }
          break;
        }

        case 'medieval_scary': {
          // Creeping Plague Mist + Distant Flickering Torchlight Haze
          drawFogBand(h * 0.78, 26, t, 0.34, '90, 50, 46', 0.2 * m, w, h);
          const flicker = 0.65 + 0.35 * Math.sin(t * 7.2) * Math.cos(t * 3.1);
          const tg = ctx.createRadialGradient(w * 0.5, h * 0.88, 10, w * 0.5, h * 0.88, w * 0.45);
          tg.addColorStop(0, `rgba(190, 45, 30, ${0.22 * flicker * m})`);
          tg.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = tg;
          ctx.fillRect(0, h * 0.45, w, h * 0.55);
          break;
        }

        case 'wiz':
        case 'potter': {
          // Floating Enchanted Great Hall Candles
          for (const c of candles) {
            const cx = w * c.xFrac;
            const cy = h * c.yFrac + Math.sin(t * 1.2 + c.phase) * 9;
            const fFlicker = 0.8 + 0.2 * Math.sin(t * 9 + c.phase);
            const ch = 18 * c.scale;
            const cw = 5 * c.scale;

            const halo = ctx.createRadialGradient(cx, cy - ch * 0.65, 1, cx, cy - ch * 0.65, 26 * c.scale * fFlicker);
            halo.addColorStop(0, `rgba(255, 224, 145, ${0.52 * m})`);
            halo.addColorStop(1, 'rgba(255, 190, 80, 0)');
            ctx.fillStyle = halo;
            ctx.beginPath();
            ctx.arc(cx, cy - ch * 0.65, 26 * c.scale * fFlicker, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = `rgba(245, 236, 214, ${0.72 * m})`;
            ctx.fillRect(cx - cw / 2, cy - ch * 0.5, cw, ch);

            ctx.fillStyle = `rgba(255, 215, 110, ${0.9 * m})`;
            ctx.beginPath();
            ctx.ellipse(cx, cy - ch * 0.65, 2.2 * c.scale, 4.4 * c.scale * fFlicker, 0, 0, Math.PI * 2);
            ctx.fill();
          }
          break;
        }

        case 'asoiaf': {
          // Winter Frost Blizzard Mist
          drawFogBand(h * 0.78, 24, t, 0.48, '180, 210, 232', 0.16 * m, w, h);
          break;
        }

        case 'darksun': {
          // Blazing Crimson Dark Sun Disc & Heat Haze
          const sx = w * 0.5;
          const sy = h * 0.2;
          const sr = Math.min(w, h) * 0.11;
          const sg = ctx.createRadialGradient(sx, sy, sr * 0.3, sx, sy, sr * 3);
          sg.addColorStop(0, `rgba(255, 140, 40, ${0.55 * m})`);
          sg.addColorStop(0.5, `rgba(180, 40, 10, ${0.24 * m})`);
          sg.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = sg;
          ctx.beginPath();
          ctx.arc(sx, sy, sr * 3, 0, Math.PI * 2);
          ctx.fill();
          break;
        }

        case 'vox': {
          // Arcane Leyline Aurora Ribbons
          drawFogBand(h * 0.3, 35, t, 0.32, '183, 122, 214', 0.1 * m, w, h * 0.45);
          break;
        }

        case 'cave':
        case 'conan':
        case 'dark': {
          // Organic Pulsing Hearth / Bonfire Glow along bottom cavern floor
          const flicker = 0.78 + 0.22 * Math.sin(t * 4.5) * Math.cos(t * 2.3);
          const rgb = universe === 'dark' ? '212, 32, 47' : '255, 148, 46';
          const fg = ctx.createRadialGradient(w * 0.5, h * 1.02, 10, w * 0.5, h * 0.96, w * 0.55);
          fg.addColorStop(0, `rgba(${rgb}, ${0.22 * flicker * m})`);
          fg.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = fg;
          ctx.fillRect(0, h * 0.45, w, h * 0.55);
          break;
        }

        default: {
          // Gentle wet-glass bokeh shimmer for Rainy Night / Storm Night
          for (let i = 0; i < 6; i++) {
            const bx = w * (0.14 + i * 0.14) + Math.sin(t * 0.3 + i) * 14;
            const by = h * (0.78 + (i % 2) * 0.08);
            const g = ctx.createRadialGradient(bx, by, 0, bx, by, 60);
            g.addColorStop(0, `rgba(140, 210, 200, ${0.09 * m})`);
            g.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.arc(bx, by, 60, 0, Math.PI * 2);
            ctx.fill();
          }
          break;
        }
      }
    };

    const loop = () => {
      rafId = requestAnimationFrame(loop);
      const w = canvas.width;
      const h = canvas.height;
      const now = performance.now();
      const t = now * 0.001;
      ctx.clearRect(0, 0, w, h);

      const clampedI = Math.max(0, Math.min(1, intensity));

      // Always render subtle hyper-realistic universe atmosphere (scaled cleanly with Ambience Intensity)
      renderUniverseEffects(t, w, h, clampedI);

      if (!fx || clampedI <= 0.01) return;

      if (fx === 'rain' || fx === 'storm') {
        const strokeAlpha = 0.14 + clampedI * (fx === 'storm' ? 0.52 : 0.44);
        ctx.lineWidth = fx === 'storm' ? 1.25 : 1.05;
        let rainColor = `rgba(185, 212, 255, ${strokeAlpha.toFixed(3)})`;
        if (universe === 'bladerunner') {
          rainColor = `rgba(120, 235, 255, ${strokeAlpha.toFixed(3)})`;
        } else if (universe === 'ghostintheshell') {
          rainColor = `rgba(125, 240, 220, ${strokeAlpha.toFixed(3)})`;
        } else if (universe === 'batman2022') {
          rainColor = `rgba(220, 175, 180, ${strokeAlpha.toFixed(3)})`;
        }
        ctx.strokeStyle = rainColor;
        ctx.beginPath();
        for (const p of particles) {
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.l * 0.24, p.y + p.l);
          p.y += p.v;
          p.x -= p.v * 0.24;
          if (p.y > h + 20) Object.assign(p, spawn(false));
        }
        ctx.stroke();
      }

      if (fx === 'storm') {
        if (now > nextLightning) {
          flash = 0.55 + clampedI * 0.45;
          nextLightning = now + 2400 + Math.random() * (8500 - clampedI * 3500);
          bolt = [];
          let bx = Math.random() * w;
          let by = 0;
          while (by < h * 0.65) {
            bolt.push([bx, by]);
            bx += (Math.random() - 0.5) * 75;
            by += 18 + Math.random() * 32;
          }
          thunderRef.current?.();
        }
        if (flash > 0) {
          const isCrimsonStorm =
            universe === 'castlevania' || universe === 'batman2022' || universe === 'medieval_scary';
          const flashRgb = isCrimsonStorm ? '255, 165, 175' : '205, 224, 255';
          ctx.fillStyle = `rgba(${flashRgb}, ${flash * (0.22 + clampedI * 0.26) * (Math.random() > 0.3 ? 1 : 0.4)})`;
          ctx.fillRect(0, 0, w, h);
          if (flash > 0.35 && bolt.length > 1) {
            ctx.save();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2.5;
            ctx.shadowBlur = 24;
            ctx.shadowColor = isCrimsonStorm ? '#ff4d6d' : '#88ccff';
            ctx.beginPath();
            bolt.forEach(([x, y], i) => (i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)));
            ctx.stroke();
            ctx.restore();
          }
          flash -= 0.04;
        }
      }

      if (fx === 'snow') {
        for (const p of particles) {
          p.y += p.v;
          p.p += 0.02;
          p.x += Math.sin(p.p) * 0.65 * p.z + 0.18 * p.z;
          if (p.y > h + 16 || p.x > w + 30) Object.assign(p, spawn(false));
          const alpha = p.a * (0.65 + 0.35 * Math.sin(p.p * 2));
          const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 2.4);
          grad.addColorStop(0, `rgba(245, 250, 255, ${alpha})`);
          grad.addColorStop(1, 'rgba(245, 250, 255, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 2.4, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (fx === 'embers' || fx === 'magic') {
        const isEmbers = fx === 'embers';
        for (const p of particles) {
          p.y -= p.v;
          p.p += 0.032;
          p.x += Math.sin(p.p) * 0.55 * p.z;
          if (p.y < -18) Object.assign(p, spawn(false));
          const alpha = p.a * (0.6 + 0.4 * Math.sin(p.p * 3));
          let rgb = isEmbers
            ? `255, ${Math.min(180, 75 + Math.round(p.r * 28))}, 22`
            : '255, 224, 145';
          if (universe === 'vox') rgb = '216, 140, 255';
          else if (universe === 'readyplayerone') rgb = '56, 210, 255';
          else if (universe === 'berserk') rgb = '235, 42, 62';
          const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4.2);
          grad.addColorStop(0, `rgba(${rgb}, ${alpha})`);
          grad.addColorStop(1, `rgba(${rgb}, 0)`);
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 4.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };

    rafId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', rebuild);
    };
  }, [fx, intensity, universe]);

  const silUrl =
    silhouette && SILHOUETTES[silhouette]
      ? `url("data:image/svg+xml,${encodeURIComponent(SILHOUETTES[silhouette])}")`
      : 'none';

  return (
    <>
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 bottom-0 h-[42vh] -z-20 bg-no-repeat"
        style={{ backgroundImage: silUrl, backgroundSize: '100% 100%' }}
      />
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 h-full w-full -z-10"
      />
    </>
  );
};
