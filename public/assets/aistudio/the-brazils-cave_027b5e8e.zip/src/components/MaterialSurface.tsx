import React, { useRef, useState } from 'react';
import { MaterialType } from '../types';

interface MaterialSurfaceProps extends React.HTMLAttributes<HTMLDivElement> {
  material: MaterialType;
  anim3d?: boolean;
  depth3d?: number;
  tiltMax?: number;
  children: React.ReactNode;
}

export const MaterialSurface: React.FC<MaterialSurfaceProps> = ({
  material,
  anim3d = true,
  depth3d = 0.75,
  tiltMax = 7,
  className = '',
  style,
  children,
  onPointerMove,
  onPointerLeave,
  ...rest
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0, mx: 50, my: 25, hover: false });

  const matClass =
    material === 'metal'
      ? 'mat-metal'
      : material === 'glass'
      ? 'mat-glass'
      : material === 'wood'
      ? 'mat-wood'
      : 'mat-obsidian';

  const handleMove = (e: React.PointerEvent<HTMLDivElement>) => {
    onPointerMove?.(e);
    if (!anim3d || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const px = Math.max(0, Math.min(1, (e.clientX - rect.left) / (rect.width || 1)));
    const py = Math.max(0, Math.min(1, (e.clientY - rect.top) / (rect.height || 1)));
    const mult = tiltMax * Math.max(0.25, depth3d);
    setTilt({
      rx: (0.5 - py) * mult * 2,
      ry: (px - 0.5) * mult * 2,
      mx: px * 100,
      my: py * 100,
      hover: true,
    });
  };

  const handleLeave = (e: React.PointerEvent<HTMLDivElement>) => {
    onPointerLeave?.(e);
    setTilt((prev) => ({ ...prev, rx: 0, ry: 0, hover: false }));
  };

  return (
    <div
      ref={ref}
      onPointerMove={handleMove}
      onPointerLeave={handleLeave}
      className={`mat-surface ${matClass} ${className}`}
      style={{
        ...style,
        ['--mx' as string]: `${tilt.mx}%`,
        ['--my' as string]: `${tilt.my}%`,
        transform:
          anim3d && tilt.hover
            ? `perspective(1100px) rotateX(${tilt.rx.toFixed(2)}deg) rotateY(${tilt.ry.toFixed(
                2
              )}deg) translateZ(${Math.round(8 * depth3d)}px)`
            : undefined,
      }}
      {...rest}
    >
      <div className="mat-sheen" style={{ opacity: tilt.hover ? 1 : 0.45 }} aria-hidden="true" />
      {children}
    </div>
  );
};
