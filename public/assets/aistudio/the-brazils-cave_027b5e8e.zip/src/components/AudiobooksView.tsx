import React, { useMemo, useRef, useState } from 'react';
import {
  Disc3,
  ImagePlus,
  MoreHorizontal,
  Play,
  Plus,
  Search,
  Shuffle,
  Sparkles,
  X,
} from 'lucide-react';
import { AppState, Book, SheetOption } from '../types';
import { APP_ICON_COVER, VOCAB } from '../data/themes';
import { fmt } from '../utils/storage';
import { MaterialSurface } from './MaterialSurface';

interface AudiobooksViewProps {
  state: AppState;
  currentBookId: string | null;
  isPlaying: boolean;
  wallUrl: string | null;
  wallIsVideo: boolean;
  listFilter?: string;
  onListFilterChange?: (val: string) => void;
  sortBy?: 'recent' | 'title' | 'progress';
  onAddAudiobooks: (files: FileList) => void;
  onLoadSampleBook: () => void;
  onOpenBook: (id: string) => void;
  onSelectGenreFilter: (genre: string | null) => void;
  genreFilter: string | null;
  onAddGenre: () => void;
  onOpenSheet: (title: string, options: SheetOption[]) => void;
  onOpenInput: (opts: {
    title: string;
    initialValue?: string;
    placeholder?: string;
    onConfirm: (val: string) => void;
  }) => void;
  onUpdateBook: (id: string, fn: (b: Book) => Book | null) => void;
  onJump: (id: string, trackIndex: number, time: number) => void;
  onDeleteMark: (bookId: string, ts: number) => void;
  onPickWallpaper: (file: File) => void;
  onRandomWallpaper: () => void;
  onOpenFullPlayer: () => void;
}

export const AudiobooksView: React.FC<AudiobooksViewProps> = ({
  state,
  currentBookId,
  isPlaying,
  wallUrl,
  wallIsVideo,
  listFilter = '',
  onListFilterChange,
  sortBy = 'recent',
  onAddAudiobooks,
  onLoadSampleBook,
  onOpenBook,
  onSelectGenreFilter,
  genreFilter,
  onAddGenre,
  onOpenSheet,
  onOpenInput,
  onUpdateBook,
  onJump,
  onDeleteMark,
  onPickWallpaper,
  onRandomWallpaper,
  onOpenFullPlayer,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const wallInputRef = useRef<HTMLInputElement>(null);
  const [dragOverWall, setDragOverWall] = useState(false);

  const vocab = VOCAB[state.theme.sk] || VOCAB.cave;

  const calcProgress = (b: Book) => {
    const total = b.tracks.reduce((sum, t) => sum + (t.d || 0), 0);
    const allKnown = b.tracks.every((t) => t.d > 0);
    if (allKnown && total > 0) {
      const elapsed =
        b.tracks.slice(0, b.pos.i).reduce((sum, t) => sum + (t.d || 0), 0) + b.pos.t;
      return Math.min(1, Math.max(0, elapsed / total));
    }
    return Math.min(1, (b.pos.i + (b.pos.t > 0 ? 0.5 : 0)) / Math.max(1, b.tracks.length));
  };

  const filteredBooks = useMemo(() => {
    const q = listFilter.trim().toLowerCase();
    return Object.values(state.books)
      .filter((b) => {
        if (q && !b.title.toLowerCase().includes(q) && !b.genres.join(' ').toLowerCase().includes(q)) {
          return false;
        }
        if (!genreFilter) return true;
        if (genreFilter === 'Unsorted') return !b.genres.length;
        return b.genres.includes(genreFilter);
      })
      .sort((a, b) => {
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        if (sortBy === 'progress') return calcProgress(b) - calcProgress(a);
        return (b.u || 0) - (a.u || 0);
      });
  }, [state.books, genreFilter, listFilter, sortBy]);

  const openGenresSheet = (book: Book) => {
    onOpenSheet(
      `Genres · ${book.title}`,
      state.genres.map((g) => ({
        label: `${book.genres.includes(g) ? '✔' : '○'} ${g}`,
        active: book.genres.includes(g),
        onClick: () => {
          onUpdateBook(book.id, (prev) => {
            const exists = prev.genres.includes(g);
            return {
              ...prev,
              genres: exists ? prev.genres.filter((x) => x !== g) : [...prev.genres, g],
            };
          });
        },
      }))
    );
  };

  const openBookmarksSheet = (book: Book) => {
    const marks = state.marks.filter((m) => m.b === book.id);
    if (!marks.length) {
      onOpenSheet('Bookmarks', [{ label: 'No bookmarks saved yet' }]);
      return;
    }
    onOpenSheet(
      `Bookmarks · ${book.title}`,
      marks.map((m) => ({
        label: `Jump to ${fmt(m.t)}${book.tracks.length > 1 ? ` (Part ${m.i + 1})` : ''}${
          m.note ? ` — ${m.note}` : ''
        }`,
        onClick: () => onJump(book.id, m.i, m.t),
      }))
    );
  };

  const openBookMenu = (book: Book) => {
    const markCount = state.marks.filter((m) => m.b === book.id).length;
    onOpenSheet(book.title, [
      {
        label: 'Assign Genres',
        onClick: () => setTimeout(() => openGenresSheet(book), 40),
      },
      {
        label: `Bookmarks (${markCount})`,
        onClick: () => setTimeout(() => openBookmarksSheet(book), 40),
      },
      ...(markCount > 0
        ? [
            {
              label: 'Delete Latest Bookmark',
              onClick: () => {
                const last = state.marks.filter((m) => m.b === book.id).pop();
                if (last) onDeleteMark(book.id, last.ts);
              },
            },
          ]
        : []),
      {
        label: 'Rename Audiobook',
        onClick: () =>
          onOpenInput({
            title: 'Rename Audiobook',
            initialValue: book.title,
            onConfirm: (val) => {
              if (val.trim()) {
                onUpdateBook(book.id, (b) => ({ ...b, title: val.trim() }));
              }
            },
          }),
      },
      {
        label: 'Reset Position to 0:00:00',
        onClick: () =>
          onUpdateBook(book.id, (b) => ({ ...b, pos: { i: 0, t: 0 }, done: false })),
      },
      {
        label: 'Forget Book & Remove Data',
        danger: true,
        onClick: () => onUpdateBook(book.id, () => null),
      },
    ]);
  };

  const genreChips = ['All', ...state.genres, 'Unsorted'];
  const activeBook = currentBookId ? state.books[currentBookId] : null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
      {/* LEFT/CENTER: ORDERED LARK-STYLE PLAYLIST / AUDIOBOOK LIST */}
      <div className="lg:col-span-8 space-y-3 order-2 lg:order-1">
        {/* Ordered Genre Filter Pills + Add Button */}
        <div className="flex items-center justify-between gap-2">
          <div className="no-scrollbar flex flex-1 items-center gap-2 overflow-x-auto py-1">
            {genreChips.map((g) => {
              const active = (genreFilter || 'All') === g;
              return (
                <button
                  key={g}
                  type="button"
                  onClick={() => onSelectGenreFilter(g === 'All' ? null : g)}
                  className="whitespace-nowrap shrink-0 rounded-full px-4 py-1.5 text-xs font-semibold transition border"
                  style={{
                    background: active ? 'var(--am)' : 'rgba(255,255,255,0.06)',
                    color: active ? 'var(--bg)' : 'var(--fg)',
                    borderColor: active ? 'var(--am)' : 'rgba(255,255,255,0.08)',
                  }}
                >
                  {g}
                </button>
              );
            })}
            <button
              type="button"
              onClick={onAddGenre}
              className="whitespace-nowrap shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold bg-white/5 hover:bg-white/10 border border-white/10"
              style={{ color: 'var(--am)' }}
            >
              + Folder
            </button>
          </div>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[40px] flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-full px-4 py-1.5 text-xs font-bold shadow-lg active:scale-95 transition"
            style={{ background: 'var(--am)', color: 'var(--bg)' }}
          >
            <Plus className="h-4 w-4" />
            <span>{vocab.ad}</span>
          </button>
        </div>

        {/* Ordered Translucent Rows over Hyper-Realistic Background */}
        {filteredBooks.length ? (
          <div className="space-y-1.5">
            {filteredBooks.map((b, idx) => {
              const isCurrent = currentBookId === b.id;
              const pct = Math.min(100, calcProgress(b) * 100);
              return (
                <div
                  key={b.id}
                  onClick={() => onOpenBook(b.id)}
                  className="group cursor-pointer rounded-2xl px-3 py-2.5 flex items-center gap-3.5 transition hover:bg-white/[0.08] active:scale-[0.995]"
                  style={{
                    background: isCurrent
                      ? 'color-mix(in srgb, var(--am) 14%, rgba(0,0,0,0.38))'
                      : 'rgba(10, 10, 12, 0.32)',
                    backdropFilter: 'blur(6px)',
                    border: isCurrent
                      ? '1px solid color-mix(in srgb, var(--am) 45%, transparent)'
                      : '1px solid rgba(255,255,255,0.05)',
                  }}
                >
                  {/* Track Index on PC */}
                  <span className="hidden sm:inline-block w-5 text-center text-xs tabular-nums opacity-45 font-mono">
                    {isCurrent && isPlaying ? '▶' : String(idx + 1).padStart(2, '0')}
                  </span>

                  {/* Square Cover Thumbnail (App Icon Cover / Wall Thumbnail) */}
                  <div className="relative h-13 w-13 shrink-0 overflow-hidden rounded-xl border border-white/15 bg-black/50">
                    <img
                      src={APP_ICON_COVER}
                      alt={b.title}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/25 opacity-0 group-hover:opacity-100 transition">
                      <Play className="h-5 w-5 fill-current text-white" />
                    </div>
                  </div>

                  {/* Title & Subtitle */}
                  <div className="min-w-0 flex-1">
                    <div
                      className="truncate text-sm font-bold leading-tight"
                      style={{ color: isCurrent ? 'var(--am)' : 'var(--fg)' }}
                    >
                      {b.title}
                    </div>
                    <div className="mt-1 flex items-center gap-1.5 truncate text-xs opacity-70">
                      <span className="truncate">{b.genres.join(' · ') || 'BILLS CAVE'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums shrink-0">
                        {b.gone
                          ? `Missing — ${fmt(b.pos.t)}`
                          : `${fmt(b.pos.t)}${
                              b.tracks.length > 1 ? ` (${b.pos.i + 1}/${b.tracks.length})` : ''
                            }`}
                      </span>
                    </div>
                    <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${pct}%`, background: 'var(--am)' }}
                      />
                    </div>
                  </div>

                  {/* Duration + Lark-Style Menu */}
                  <div className="flex items-center gap-2 shrink-0">
                    {b.tracks.reduce((sum, t) => sum + (t.d || 0), 0) > 0 && (
                      <span className="tabular-nums text-xs opacity-65">
                        {fmt(b.tracks.reduce((sum, t) => sum + (t.d || 0), 0))}
                      </span>
                    )}
                    <button
                      type="button"
                      aria-label={`Options for ${b.title}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        openBookMenu(b);
                      }}
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition opacity-85 hover:opacity-100"
                      style={{ color: isCurrent ? 'var(--am)' : 'var(--fg)' }}
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Search in this list... bar (matching Lark list footer) */}
            {onListFilterChange && (
              <div className="mt-2 flex items-center gap-2 rounded-2xl bg-black/35 border border-white/10 px-3.5 py-2 backdrop-blur-md">
                <Search className="h-4 w-4 opacity-60 shrink-0" />
                <input
                  type="text"
                  value={listFilter}
                  onChange={(e) => onListFilterChange(e.target.value)}
                  placeholder="Search in this list..."
                  className="w-full bg-transparent text-xs outline-none placeholder:text-white/45"
                />
                {listFilter && (
                  <button
                    type="button"
                    aria-label="Clear list filter"
                    onClick={() => onListFilterChange('')}
                    className="p-1 opacity-70 hover:opacity-100"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            )}
          </div>
        ) : (
          <MaterialSurface
            material={state.theme.material}
            anim3d={state.theme.anim3d}
            depth3d={state.theme.depth3d}
            className="rounded-3xl px-6 py-10 text-center"
          >
            <img
              src={APP_ICON_COVER}
              alt="BILLS CAVE cover"
              referrerPolicy="no-referrer"
              className="mx-auto mb-3 h-16 w-16 rounded-2xl object-cover border border-white/20 shadow-lg"
            />
            <p className="text-base font-semibold">
              {listFilter ? 'No matching audiobooks found' : 'BILLS CAVE Library is ready.'}
            </p>
            <p className="mt-1.5 mx-auto max-w-md text-xs opacity-75 leading-relaxed">
              Add audiobooks (MP3, M4B, M4A, OGG, FLAC, WAV) — every second is saved locally. Or load
              a 3-chapter sample track to test scrubbing, next/previous, volume, and 3D playback right
              now.
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="min-h-[44px] flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold shadow-lg active:scale-95 transition"
                style={{ background: 'var(--am)', color: 'var(--bg)' }}
              >
                <Plus className="h-4 w-4" />
                <span>{vocab.ad}</span>
              </button>
              <button
                type="button"
                onClick={onLoadSampleBook}
                className="min-h-[44px] flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-semibold hover:bg-white/10 active:scale-95 transition"
                style={{
                  borderColor: 'color-mix(in srgb, var(--am) 45%, transparent)',
                  color: 'var(--am)',
                }}
              >
                <Sparkles className="h-4 w-4" />
                <span>Load Sample Audiobook</span>
              </button>
            </div>
          </MaterialSurface>
        )}
      </div>

      {/* RIGHT PC PANEL (TOP ON MOBILE): 4K / 8K WALLPAPER & GIF SPOT IN THE PLAYER */}
      <div className="lg:col-span-4 order-1 lg:order-2 lg:sticky lg:top-2">
        <MaterialSurface
          material={state.theme.material}
          anim3d={state.theme.anim3d}
          depth3d={state.theme.depth3d}
          tiltMax={6}
          className={`relative overflow-hidden rounded-3xl transition ${
            dragOverWall ? 'ring-2 ring-amber-400' : ''
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOverWall(true);
          }}
          onDragLeave={() => setDragOverWall(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOverWall(false);
            const f = e.dataTransfer.files?.[0];
            if (f) onPickWallpaper(f);
          }}
        >
          <div className="relative h-44 sm:h-52 lg:h-72 w-full overflow-hidden">
            {wallUrl ? (
              wallIsVideo ? (
                <video
                  src={wallUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  onClick={onOpenFullPlayer}
                  className={`h-full w-full cursor-pointer hq-media ${
                    state.theme.wallFit === 'contain' ? 'object-contain bg-black/50' : 'object-cover'
                  }`}
                />
              ) : (
                <img
                  src={wallUrl}
                  alt="4K / 8K Wallpaper Stage"
                  referrerPolicy="no-referrer"
                  onClick={onOpenFullPlayer}
                  className={`h-full w-full cursor-pointer hq-media ${
                    state.theme.wallFit === 'contain' ? 'object-contain bg-black/50' : 'object-cover'
                  }`}
                />
              )
            ) : (
              <div
                onClick={() => wallInputRef.current?.click()}
                className="relative flex h-full w-full cursor-pointer flex-col items-center justify-center px-4 text-center"
              >
                <img
                  src={APP_ICON_COVER}
                  alt="BILLS CAVE cover"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 h-full w-full object-cover opacity-40"
                />
                <div className="relative z-10 flex flex-col items-center">
                  <ImagePlus className="h-8 w-8 mb-1.5" style={{ color: 'var(--am)' }} />
                  <div className="text-sm font-bold text-white drop-shadow">
                    4K / 8K Wallpaper &amp; GIF Spot
                  </div>
                  <div className="mt-0.5 text-xs text-white/80 drop-shadow">
                    Drop or click to load 4K/8K art, GIFs, or video
                  </div>
                </div>
              </div>
            )}

            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-transparent" />

            <div className="absolute inset-x-3.5 bottom-3 flex items-end justify-between gap-2">
              <button
                type="button"
                onClick={onOpenFullPlayer}
                className="flex items-center gap-2.5 text-left min-w-0"
              >
                <Disc3
                  className={`h-6 w-6 shrink-0 ${
                    state.theme.anim3d && isPlaying ? 'anim-3d-spin' : ''
                  }`}
                  style={{ color: 'var(--am)' }}
                />
                <div className="min-w-0">
                  <div className="truncate text-xs font-bold text-white">
                    {activeBook ? activeBook.title : 'BILLS CAVE 3D Stage'}
                  </div>
                  <div className="text-[11px] text-white/70">
                    {wallUrl ? '4K / 8K Active · Expand' : 'Tap to Expand 3D Deck'}
                  </div>
                </div>
              </button>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => wallInputRef.current?.click()}
                  className="min-h-[36px] rounded-xl bg-black/70 hover:bg-black/90 backdrop-blur-md px-3 py-1 text-xs font-semibold text-white transition"
                >
                  + 4K/GIF
                </button>
                <button
                  type="button"
                  onClick={onRandomWallpaper}
                  title="Random wallpaper"
                  className="flex h-9 w-9 items-center justify-center rounded-xl bg-black/70 hover:bg-black/90 backdrop-blur-md text-white transition"
                >
                  <Shuffle className="h-3.5 w-3.5" style={{ color: 'var(--am)' }} />
                </button>
              </div>
            </div>
          </div>

          <input
            ref={wallInputRef}
            type="file"
            accept="image/*,video/*,.gif,.webp,.avif,.mp4,.webm,.mkv,.mov"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              e.target.value = '';
              if (f) onPickWallpaper(f);
            }}
          />
        </MaterialSurface>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="audio/*,.m4b,.m4a,.mp3,.ogg,.opus,.flac,.wav,.aac"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) onAddAudiobooks(e.target.files);
          e.target.value = '';
        }}
      />
    </div>
  );
};
