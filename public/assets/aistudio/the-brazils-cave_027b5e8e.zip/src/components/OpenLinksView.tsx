import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ExternalLink,
  Globe,
  History,
  MoreVertical,
  Plus,
  Star,
} from 'lucide-react';
import { AppState, SheetOption, WatchItem } from '../types';
import { cleanWebURL } from '../utils/storage';
import { MaterialSurface } from './MaterialSurface';

interface OpenLinksViewProps {
  state: AppState;
  listFilter?: string;
  onSaveSite: (url: string) => void;
  onRecordVisit: (url: string) => void;
  onRemoveSaved: (index: number) => void;
  onRenameSaved: (index: number, title: string) => void;
  onOpenSheet: (title: string, options: SheetOption[]) => void;
  onOpenInput: (opts: {
    title: string;
    initialValue?: string;
    placeholder?: string;
    onConfirm: (val: string) => void;
  }) => void;
  onToast: (msg: string) => void;
}

const STREAMING_SHORTCUTS = [
  { label: 'YouTube', url: 'https://www.youtube.com' },
  { label: 'Disney+', url: 'https://www.disneyplus.com' },
  { label: 'Netflix', url: 'https://www.netflix.com' },
  { label: 'HBO / Max', url: 'https://www.max.com' },
  { label: 'Prime Video', url: 'https://www.primevideo.com' },
  { label: 'Google', url: 'https://www.google.com' },
];

export const OpenLinksView: React.FC<OpenLinksViewProps> = ({
  state,
  listFilter = '',
  onSaveSite,
  onRecordVisit,
  onRemoveSaved,
  onRenameSaved,
  onOpenSheet,
  onOpenInput,
  onToast,
}) => {
  const [browserOpen, setBrowserOpen] = useState(false);
  const [urlInput, setUrlInput] = useState(state.lastWeb || '');
  const [loadedUrl, setLoadedUrl] = useState('');

  const openBrowser = (target?: string) => {
    const u = target ? cleanWebURL(target) : cleanWebURL(state.lastWeb || '');
    setBrowserOpen(true);
    if (u) {
      setUrlInput(u);
      setLoadedUrl(u);
      onRecordVisit(u);
    } else {
      setUrlInput(target || '');
    }
  };

  const handleGo = (raw?: string) => {
    const cleaned = cleanWebURL(raw ?? urlInput);
    if (!cleaned) {
      onToast('Enter a valid http or https website');
      return;
    }
    setUrlInput(cleaned);
    setLoadedUrl(cleaned);
    onRecordVisit(cleaned);
  };

  const handleOpenExternal = () => {
    const cleaned = cleanWebURL(urlInput || loadedUrl);
    if (!cleaned) {
      onToast('Enter a valid website first');
      return;
    }
    const ua = navigator.userAgent || '';
    const pu = new URL(cleaned);
    if (/Android/i.test(ua)) {
      window.location.href = `intent://${pu.host}${pu.pathname}${pu.search}${pu.hash}#Intent;scheme=${pu.protocol.slice(
        0,
        -1
      )};package=com.brave.browser;S.browser_fallback_url=${encodeURIComponent(cleaned)};end`;
      return;
    }
    window.open(cleaned, '_blank', 'noopener,noreferrer');
  };

  const isSaved = !!loadedUrl && state.watch.some((w) => w.url === loadedUrl);

  const openSavedMenu = (item: WatchItem, idx: number) => {
    onOpenSheet(item.title || item.url, [
      { label: 'Open in Player Viewer', onClick: () => openBrowser(item.url) },
      {
        label: 'Open in External Browser',
        onClick: () => window.open(item.url, '_blank', 'noopener,noreferrer'),
      },
      {
        label: 'Rename Link',
        onClick: () =>
          onOpenInput({
            title: 'Rename Saved Link',
            initialValue: item.title || item.url,
            onConfirm: (val) => {
              if (val.trim()) onRenameSaved(idx, val.trim());
            },
          }),
      },
      { label: 'Remove Saved Link', danger: true, onClick: () => onRemoveSaved(idx) },
    ]);
  };

  const q = listFilter.trim().toLowerCase();
  const savedList = state.watch
    .map((w, idx) => ({ w, idx }))
    .filter(({ w }) => !q || (w.title || '').toLowerCase().includes(q) || w.url.toLowerCase().includes(q));
  const recentList = [...(state.webHist || [])]
    .reverse()
    .filter((item) => !q || (item.title || '').toLowerCase().includes(q) || item.url.toLowerCase().includes(q))
    .slice(0, 24);

  return (
    <div className="space-y-5">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold tracking-wide" style={{ color: 'var(--am)' }}>
            Open Links &amp; Streaming
          </h2>
          <p className="text-xs opacity-70">
            Saved sites, quick streaming portals, and embedded web room
          </p>
        </div>
        <button
          type="button"
          onClick={() => openBrowser()}
          className="min-h-[44px] flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold shadow-lg active:scale-95 transition"
          style={{ background: 'var(--am)', color: 'var(--bg)' }}
        >
          <Plus className="h-4 w-4" />
          <span>Open Link</span>
        </button>
      </div>

      {/* Quick Streaming Portals */}
      <div className="no-scrollbar flex items-center gap-2 overflow-x-auto pb-1">
        {STREAMING_SHORTCUTS.map((s) => (
          <button
            key={s.url}
            type="button"
            onClick={() => openBrowser(s.url)}
            className="whitespace-nowrap shrink-0 rounded-xl border px-3.5 py-2.5 text-xs font-semibold hover:bg-white/10 active:scale-95 transition"
            style={{
              borderColor: 'color-mix(in srgb, var(--am) 32%, transparent)',
              background: 'color-mix(in srgb, var(--bg) 72%, var(--am) 8%)',
            }}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Saved For Later */}
      <div>
        <h3 className="mb-2 text-xs font-bold tracking-wider uppercase opacity-65">
          Saved for Later
        </h3>
        {savedList.length ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {savedList.map(({ w, idx }) => (
              <MaterialSurface
                key={`${w.url}-${idx}`}
                material={state.theme.material}
                anim3d={state.theme.anim3d}
                depth3d={state.theme.depth3d}
                tiltMax={4}
                onClick={() => openBrowser(w.url)}
                className="cursor-pointer rounded-2xl p-3 flex items-center gap-3"
              >
                <div
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border"
                  style={{
                    borderColor: 'color-mix(in srgb, var(--am) 30%, transparent)',
                    color: 'var(--am)',
                  }}
                >
                  <Globe className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold">{w.title || w.url}</div>
                  <div className="truncate text-xs opacity-65">{w.url}</div>
                </div>
                <button
                  type="button"
                  aria-label={`Options for ${w.title}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    openSavedMenu(w, idx);
                  }}
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl hover:bg-white/10"
                  style={{ color: 'var(--am)' }}
                >
                  <MoreVertical className="h-4 w-4" />
                </button>
              </MaterialSurface>
            ))}
          </div>
        ) : (
          <MaterialSurface
            material={state.theme.material}
            anim3d={false}
            className="rounded-2xl p-5 text-center text-xs opacity-75"
          >
            No saved links yet. Tap any portal above or open a URL to bookmark it here.
          </MaterialSurface>
        )}
      </div>

      {/* Recently Visited */}
      {recentList.length > 0 && (
        <div>
          <h3 className="mb-2 text-xs font-bold tracking-wider uppercase opacity-65">
            Recently Visited
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {recentList.map((item, idx) => (
              <MaterialSurface
                key={`${item.url}-${idx}`}
                material={state.theme.material}
                anim3d={false}
                onClick={() => openBrowser(item.url)}
                className="cursor-pointer rounded-xl p-3 flex items-center gap-3"
              >
                <History className="h-4 w-4 shrink-0 opacity-70" style={{ color: 'var(--am)' }} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-bold">{item.title || item.url}</div>
                  <div className="truncate text-[11px] opacity-60">{item.url}</div>
                </div>
              </MaterialSurface>
            ))}
          </div>
        </div>
      )}

      {/* Embedded Web Room Modal */}
      {browserOpen && (
        <section
          aria-label="In-player browser and streaming viewer"
          className="fixed inset-0 z-40 flex flex-col p-2.5 pt-[calc(env(safe-area-inset-top)+8px)] pb-[calc(env(safe-area-inset-bottom)+8px)] backdrop-blur-md"
          style={{ background: 'color-mix(in srgb, var(--bg) 65%, transparent)' }}
        >
          <MaterialSurface
            material={state.theme.material}
            anim3d={false}
            className="mb-2 flex items-center gap-2 rounded-2xl p-2"
          >
            <button
              type="button"
              onClick={() => setBrowserOpen(false)}
              aria-label="Back to links"
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 hover:bg-white/15"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <input
              type="text"
              inputMode="url"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleGo();
              }}
              placeholder="Enter website or paste link…"
              className="min-w-0 flex-1 rounded-xl bg-black/35 px-3 py-2 text-sm outline-none border border-white/10"
            />
            <button
              type="button"
              onClick={() => handleGo()}
              aria-label="Go to URL"
              className="flex h-10 w-10 items-center justify-center rounded-xl font-bold"
              style={{ background: 'var(--am)', color: 'var(--bg)' }}
            >
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                const u = cleanWebURL(urlInput || loadedUrl);
                if (!u) return onToast('Enter a valid URL first');
                onSaveSite(u);
              }}
              aria-label="Save website"
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 hover:bg-white/15"
              style={{ color: 'var(--am)' }}
            >
              <Star className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
            </button>
            <button
              type="button"
              onClick={handleOpenExternal}
              aria-label="Open in external browser"
              title="Open in Brave / Browser"
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 hover:bg-white/15"
            >
              <ExternalLink className="h-4 w-4" />
            </button>
          </MaterialSurface>

          <div className="no-scrollbar mb-2 flex items-center gap-1.5 overflow-x-auto">
            {STREAMING_SHORTCUTS.map((s) => (
              <button
                key={s.url}
                type="button"
                onClick={() => handleGo(s.url)}
                className="whitespace-nowrap shrink-0 rounded-xl bg-black/55 px-3 py-1.5 text-xs font-semibold text-white hover:bg-black/75"
              >
                {s.label}
              </button>
            ))}
          </div>

          <div className="relative flex-1 min-h-0 overflow-hidden rounded-2xl border border-white/15 bg-black/40">
            <iframe
              src={loadedUrl || 'about:blank'}
              title="Website viewer"
              allow="autoplay; encrypted-media; fullscreen; picture-in-picture; clipboard-read; clipboard-write"
              allowFullScreen
              referrerPolicy="strict-origin-when-cross-origin"
              className="h-full w-full border-0"
            />
            {loadedUrl && (
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2 rounded-xl bg-black/80 px-3.5 py-2 text-xs text-white/90">
                <span>If this site blocks embedded viewing, launch it externally.</span>
                <button
                  type="button"
                  onClick={handleOpenExternal}
                  className="shrink-0 font-bold underline"
                  style={{ color: 'var(--am)' }}
                >
                  Open External
                </button>
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
